# Acceso remoto de Ivan (Grok Bot) -- solo mientras esta ventana este abierta.
# OpenSSH (solo 127.0.0.1, solo clave) + Cloudflare quick tunnel.
[CmdletBinding()]
param([switch]$NoConfirm)

$ErrorActionPreference = 'Stop'
$PubKey   = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAINw0yqT4VUMrJ+ywppDCuN1bvIeQ5N8MHzRxGWFiG4ob grokbot-box-acceso-antonio-2026-11-16'
$WorkDir  = Join-Path $env:ProgramData 'AccesoRemotoIvan'
$CfExe    = Join-Path $WorkDir 'cloudflared.exe'
$CfLog    = Join-Path $WorkDir 'cloudflared.log'
$CfUrl    = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe'
$SshdConf = Join-Path $env:ProgramData 'ssh\sshd_config'
$DeskFile = Join-Path ([Environment]::GetFolderPath('Desktop')) 'MANDA-ESTA-FOTO-A-IVAN.txt'
$PubFile  = Join-Path $env:PUBLIC 'MANDA-ESTA-FOTO-A-IVAN.txt'

function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Say 'Usa ABRIR-ACCESO.bat (doble clic).' Red; Start-Sleep 5; exit 1 }

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Start-Transcript -Path (Join-Path $WorkDir ("sesion-{0:yyyyMMdd-HHmmss}.log" -f (Get-Date))) -Append | Out-Null

Clear-Host
Say '==============================================================' Cyan
Say '  ACCESO REMOTO PARA IVAN' Cyan
Say '==============================================================' Cyan
Say 'Preparando... (la primera vez puede tardar unos minutos)'
Say ''

# OpenSSH Server
Say '[1/4] OpenSSH...' White
if (-not (Get-Service sshd -ErrorAction SilentlyContinue)) {
  try {
    Add-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0' | Out-Null
  } catch {
    Say "ERROR instalando OpenSSH: $($_.Exception.Message)" Red
    $err = "ERROR OpenSSH:`n$($_.Exception.Message)`nManda esta foto a Ivan."
    Set-Content -Path $DeskFile -Value $err -Encoding UTF8
    Set-Content -Path $PubFile -Value $err -Encoding UTF8
    Start-Process notepad.exe -ArgumentList $DeskFile
    Start-Sleep 30; Stop-Transcript | Out-Null; exit 2
  }
}
if (-not (Test-Path $SshdConf)) { Start-Service sshd; Start-Sleep 2; Stop-Service sshd }

# Config segura
Say '[2/4] Configurando...' White
$conf = Get-Content $SshdConf -Raw
$block = @"
# --- AccesoRemotoIvan (inicio) ---
ListenAddress 127.0.0.1
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
# --- AccesoRemotoIvan (fin) ---
"@
$conf = [regex]::Replace($conf, '(?s)# --- AccesoRemotoIvan \(inicio\) ---.*?# --- AccesoRemotoIvan \(fin\) ---\r?\n?', '')
Set-Content -Path $SshdConf -Value ($block + "`r`n" + $conf) -Encoding ascii

$adminKeys = Join-Path $env:ProgramData 'ssh\administrators_authorized_keys'
$userKeysDir = Join-Path $env:USERPROFILE '.ssh'
$isAdminGroupMember = (whoami /groups) -match 'S-1-5-32-544'
if ($isAdminGroupMember) {
  if (-not (Test-Path $adminKeys) -or -not (Select-String -Path $adminKeys -SimpleMatch $PubKey -Quiet)) { Add-Content -Path $adminKeys -Value $PubKey -Encoding ascii }
  icacls.exe $adminKeys /inheritance:r /grant 'Administrators:F' /grant 'SYSTEM:F' | Out-Null
} else {
  New-Item -ItemType Directory -Force -Path $userKeysDir | Out-Null
  $uk = Join-Path $userKeysDir 'authorized_keys'
  if (-not (Test-Path $uk) -or -not (Select-String -Path $uk -SimpleMatch $PubKey -Quiet)) { Add-Content -Path $uk -Value $PubKey -Encoding ascii }
}
New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -PropertyType String -Force | Out-Null
Get-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -ErrorAction SilentlyContinue | Disable-NetFirewallRule
Set-Service sshd -StartupType Manual
Restart-Service sshd -Force

# cloudflared
Say '[3/4] Tunel Cloudflare...' White
if (-not (Test-Path $CfExe)) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -Uri $CfUrl -OutFile $CfExe -UseBasicParsing
}
$sig = Get-AuthenticodeSignature $CfExe
if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Cloudflare') {
  Say "Firma de cloudflared no valida. Cancelado." Red
  Remove-Item $CfExe -Force -ErrorAction SilentlyContinue
  Stop-Service sshd -ErrorAction SilentlyContinue
  $err = "ERROR: cloudflared con firma invalida. Manda esta foto a Ivan."
  Set-Content -Path $DeskFile -Value $err -Encoding UTF8
  Start-Process notepad.exe -ArgumentList $DeskFile
  Start-Sleep 30; Stop-Transcript | Out-Null; exit 3
}

# Abrir tunel
Say '[4/4] Abriendo acceso...' White
Remove-Item $CfLog -ErrorAction SilentlyContinue
$p = Start-Process -FilePath $CfExe -ArgumentList @('tunnel','--no-autoupdate','--url','ssh://127.0.0.1:22','--logfile',$CfLog) -NoNewWindow -PassThru -RedirectStandardError (Join-Path $WorkDir 'cloudflared-stderr.log') -RedirectStandardOutput (Join-Path $WorkDir 'cloudflared-stdout.log')
$url = $null
for ($i = 0; $i -lt 60 -and -not $url; $i++) {
  Start-Sleep 1
  if (Test-Path $CfLog) { $m = Select-String -Path $CfLog -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' | Select-Object -First 1; if ($m) { $url = $m.Matches[0].Value } }
  if ($p.HasExited) { break }
}
try {
  if (-not $url) {
    $err = "ERROR: no se pudo abrir el tunel.`nManda a Ivan una foto de esta ventana y del archivo:`n$CfLog"
    Set-Content -Path $DeskFile -Value $err -Encoding UTF8
    Set-Content -Path $PubFile -Value $err -Encoding UTF8
    Start-Process notepad.exe -ArgumentList $DeskFile
    Say $err Red
    Start-Sleep 60
    return
  }
  $hostOnly = $url -replace '^https://',''
  $userName = $env:USERNAME
  $texto = @"
===============================
  MANDA ESTA FOTO A IVAN
===============================

Direccion:
$hostOnly

Usuario:
$userName

(No hace falta escribir nada mas.
Solo una foto de esta ventana.)

===============================
"@
  Set-Content -Path $DeskFile -Value $texto -Encoding UTF8
  Set-Content -Path $PubFile  -Value $texto -Encoding UTF8
  Set-Content -Path (Join-Path $WorkDir 'ultimo-acceso.txt') -Value $texto -Encoding UTF8
  try { Set-Clipboard -Value "$hostOnly`n$userName" } catch {}

  # Abrir Bloc de notas delante, maximizado, para que Antonio solo mande foto
  Start-Process notepad.exe -ArgumentList $DeskFile
  Start-Sleep 1
  # Intentar traer Notepad al frente
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class Win {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
'@
  Get-Process notepad -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.MainWindowHandle -ne [IntPtr]::Zero) {
      [Win]::ShowWindow($_.MainWindowHandle, 3) | Out-Null
      [Win]::SetForegroundWindow($_.MainWindowHandle) | Out-Null
    }
  }

  Clear-Host
  Say '==============================================================' Green
  Say '  LISTO. Se ha abierto el Bloc de notas.' Green
  Say '  Manda a Ivan una FOTO de esa ventana de texto.' Green
  Say '==============================================================' Green
  Say ''
  Say "Direccion: $hostOnly"
  Say "Usuario:   $userName"
  Say ''
  Say 'No cierres ESTA ventana azul (corta el acceso).' Cyan
  Say 'El Bloc de notas si se puede cerrar despues de la foto.'
  Wait-Process -Id $p.Id
} finally {
  if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
  Stop-Service sshd -ErrorAction SilentlyContinue
  Stop-Transcript | Out-Null
}
