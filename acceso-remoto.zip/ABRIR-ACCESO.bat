@echo off
rem Doble clic -> pulsa SI en el aviso de Windows. Listo.
rem Se abre sola una ventana de texto: manda foto de esa ventana a Ivan.
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0acceso-remoto.ps1" -NoConfirm
