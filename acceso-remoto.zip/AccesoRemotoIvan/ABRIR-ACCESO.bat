@echo off
rem Doble clic: pide permiso de administrador (pulsar "Si") y abre el acceso remoto para Ivan.
rem El acceso dura mientras la ventana azul este abierta.
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0acceso-remoto.ps1"
