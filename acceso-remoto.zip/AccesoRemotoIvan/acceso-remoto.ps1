﻿# Acceso remoto de Ivan (Grok Bot) al PC de la gestoria -- solo mientras esta ventana este abierta.
# Metodo: Windows OpenSSH Server (solo escucha en 127.0.0.1) + Cloudflare Tunnel "quick tunnel" (solo conexion saliente).
# Requisitos: Windows 10 1809+ / Windows 11 x64, PowerShell 5.1+. Se ejecuta como administrador (pide UAC).
# Para cortar el acceso: cerrar esta ventana o pulsar Ctrl+C. Tambien: CERRAR-ACCESO.bat
[CmdletBinding()]
param([switch]$NoConfirm)

$ErrorActionPreference = 'Stop'
$PubKey   = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAINw0yqT4VUMrJ+ywppDCuN1bvIeQ5N8MHzRxGWFiG4ob grokbot-box-acceso-antonio-2026-11-16'
$WorkDir  = Join-Path $env:ProgramData 'AccesoRemotoIvan'
$CfExe    = Join-Path $WorkDir 'cloudflared.exe'
$CfLog    = Join-Path $WorkDir 'cloudflared.log'
$CfUrl    = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe'
$SshdConf = Join-Path $env:ProgramData 'ssh\sshd_config'

function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }

# 1. Comprobar administrador
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Say 'Hace falta ejecutar como administrador. Usa ABRIR-ACCESO.bat.' Red; Read-Host 'Pulsa Enter para salir'; exit 1 }

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Start-Transcript -Path (Join-Path $WorkDir ("sesion-{0:yyyyMMdd-HHmmss}.log" -f (Get-Date))) -Append | Out-Null

Clear-Host
Say '==============================================================' Cyan
Say '  ACCESO REMOTO PARA IVAN (Grok Bot)' Cyan
Say '==============================================================' Cyan
Say 'Mientras esta ventana este ABIERTA, Ivan podra ejecutar comandos'
Say 'en este ordenador. Al CERRARLA, el acceso se corta.'
if (-not $NoConfirm) {
  $ans = Read-Host 'Escribe S y pulsa Enter para permitir el acceso (cualquier otra cosa cancela)'
  if ($ans -notmatch '^[sS]') { Say 'Cancelado. No se ha cambiado nada.' Yellow; Stop-Transcript | Out-Null; exit 0 }
}

# 2. OpenSSH Server (componente oficial de Windows)
Say "`n[1/4] Comprobando OpenSSH Server..." White
if (-not (Get-Service sshd -ErrorAction SilentlyContinue)) {
  try {
    Say '      Instalando OpenSSH Server (puede tardar unos minutos)...'
    Add-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0' | Out-Null
  } catch {
    Say "      No se pudo instalar desde Windows Update: $($_.Exception.Message)" Red
    Say '      Avisa a Ivan con una foto de esta ventana.' Red
    Read-Host 'Pulsa Enter para salir'; Stop-Transcript | Out-Null; exit 2
  }
}
if (-not (Test-Path $SshdConf)) { Start-Service sshd; Start-Sleep 2; Stop-Service sshd }

# 3. Configuracion segura: solo localhost, solo clave, sin contrasenas
Say '[2/4] Configurando acceso solo con clave y solo local...' White
$conf = Get-Content $SshdConf -Raw
$block = @"
# --- AccesoRemotoIvan (inicio) ---
ListenAddress 127.0.0.1
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
# --- AccesoRemotoIvan (fin) ---
"@
$conf = [regex]::Replace($conf, '(?s)# --- AccesoRemotoIvan \(inicio\) ---.*?# --- AccesoRemotoIvan \(fin\) ---\r?\n?', '')
Set-Content -Path $SshdConf -Value ($block + "`r`n" + $conf) -Encoding ascii

# Clave publica de Ivan: administradores -> administrators_authorized_keys (doc oficial Microsoft)
$adminKeys = Join-Path $env:ProgramData 'ssh\administrators_authorized_keys'
$userKeysDir = Join-Path $env:USERPROFILE '.ssh'
$isAdminGroupMember = (whoami /groups) -match 'S-1-5-32-544'
if ($isAdminGroupMember) {
  if (-not (Test-Path $adminKeys) -or -not (Select-String -Path $adminKeys -SimpleMatch $PubKey -Quiet)) { Add-Content -Path $adminKeys -Value $PubKey -Encoding ascii }
  icacls.exe $adminKeys /inheritance:r /grant 'Administrators:F' /grant 'SYSTEM:F' | Out-Null
} else {
  New-Item -ItemType Directory -Force -Path $userKeysDir | Out-Null
  $uk = Join-Path $userKeysDir 'authorized_keys'
  if (-not (Test-Path $uk) -or -not (Select-String -Path $uk -SimpleMatch $PubKey -Quiet)) { Add-Content -Path $uk -Value $PubKey -Encoding ascii }
}
# Shell por defecto: PowerShell (doc oficial OpenSSH for Windows)
New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -PropertyType String -Force | Out-Null
# La regla de firewall de entrada no hace falta (sshd solo escucha en 127.0.0.1): se desactiva
Get-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -ErrorAction SilentlyContinue | Disable-NetFirewallRule
Set-Service sshd -StartupType Manual
Restart-Service sshd -Force

# 4. cloudflared oficial (Cloudflare, firmado)
Say '[3/4] Preparando el tunel de Cloudflare...' White
if (-not (Test-Path $CfExe)) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -Uri $CfUrl -OutFile $CfExe -UseBasicParsing
}
$sig = Get-AuthenticodeSignature $CfExe
if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Cloudflare') {
  Say "      La firma de cloudflared.exe no es valida ($($sig.Status)). Se borra y se cancela." Red
  Remove-Item $CfExe -Force; Stop-Service sshd; Read-Host 'Pulsa Enter para salir'; Stop-Transcript | Out-Null; exit 3
}

# 5. Abrir el tunel y mostrar la direccion
Say '[4/4] Abriendo el acceso...' White
Remove-Item $CfLog -ErrorAction SilentlyContinue
$p = Start-Process -FilePath $CfExe -ArgumentList @('tunnel','--no-autoupdate','--url','ssh://127.0.0.1:22','--logfile',$CfLog) -NoNewWindow -PassThru -RedirectStandardError (Join-Path $WorkDir 'cloudflared-stderr.log') -RedirectStandardOutput (Join-Path $WorkDir 'cloudflared-stdout.log')
$url = $null
for ($i = 0; $i -lt 60 -and -not $url; $i++) {
  Start-Sleep 1
  if (Test-Path $CfLog) { $m = Select-String -Path $CfLog -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' | Select-Object -First 1; if ($m) { $url = $m.Matches[0].Value } }
  if ($p.HasExited) { break }
}
try {
  if (-not $url) { Say 'No se pudo abrir el tunel. Manda a Ivan el archivo:' Red; Say "   $CfLog" Red; Read-Host 'Pulsa Enter para salir'; return }
  $hostOnly = $url -replace '^https://',''
  $msg = "Acceso abierto. Direccion: $hostOnly  Usuario: $env:USERNAME"
  Set-Clipboard -Value $msg
  Clear-Host
  Say '==============================================================' Green
  Say '  ACCESO ABIERTO' Green
  Say '==============================================================' Green
  Say ''
  Say "  Direccion:  $hostOnly" Yellow
  Say "  Usuario:    $env:USERNAME" Yellow
  Say ''
  Say '  Ya esta copiado. Pegalo (Ctrl+V) en WhatsApp a Ivan.'
  Say ''
  Say '  Para CORTAR el acceso: cierra esta ventana.' Cyan
  Say '  (Registro de esta sesion en C:\ProgramData\AccesoRemotoIvan)'
  Wait-Process -Id $p.Id
} finally {
  if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
  Stop-Service sshd -ErrorAction SilentlyContinue
  Stop-Transcript | Out-Null
}
