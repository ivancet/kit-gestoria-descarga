@echo off
rem Corta cualquier acceso remoto abierto con ABRIR-ACCESO.bat
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
taskkill /F /IM cloudflared.exe >nul 2>&1
powershell -NoProfile -Command "Stop-Service sshd -ErrorAction SilentlyContinue"
echo Acceso remoto cerrado.
pause
