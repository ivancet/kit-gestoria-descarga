# Toolkit de automatización de la gestoría: v1 (2026-11-14)

Scripts en Python para el despacho de Antonio (Sage Despachos Connected). Funcionan **en local** en un PC Windows,
sin conexión a internet y sin enviar nada. Sage no tiene API pública, así que todo entra en Sage mediante **ficheros de importación**
que Antonio revisa e importa.

| Módulo | Qué hace | Estado |
|---|---|---|
| [`calendario-fiscal/`](calendario-fiscal/README.md) | Plazos AEAT 2026-2027 de 15 modelos, vencimientos por cliente (CSV + `.ics`) y resumen semanal "qué vence" | ✅ 2026 verificado contra la AEAT; 2027 estimado |
| [`extractor-facturas/`](extractor-facturas/README.md) | Carpeta de entrada → texto/OCR → NIF, nº, fecha, IVA, IRPF, total y cuadre → hoja de revisión → fichero para Sage | ✅ probado con PDF, fotos y escaneos sintéticos |
| [`norma43/`](norma43/README.md) | Lector Norma 43 y Excel bancario, conciliación con facturas y reglas → asientos propuestos | ✅ probado |
| [`solicitud-documentos/`](solicitud-documentos/README.md) | Borradores de email (`.eml`) y WhatsApp para pedir la documentación que falta | ✅ probado (solo borradores) |
| `run_all.py` / `run_all.bat` | Ejecuta toda la cadena; pensado para el Programador de tareas | ✅ `--demo` de principio a fin |
| [`INSTALAR_WINDOWS.md`](INSTALAR_WINDOWS.md) | Python, Tesseract, carpetas y tareas programadas | 📄 |

Código común en `comun/` (NIF, importes, asientos, exportación a Sage y reglas) y configuración en `config/`:

- `rutas.toml`: dónde están los datos (o la variable de entorno `GESTORIA_DATOS`).
- `sage_mapping.toml`: **formato de los ficheros para Sage** (columnas configurables; por defecto el Excel `VF_Importacion_Asientos`, con columnas SUPUESTAS).
- `plan_cuentas.toml`: cuentas PGC y subcuentas por NIF.
- `reglas_cuentas.toml`: texto → cuenta (IBERDROLA → 628...).
- `documentos_requeridos.toml`: documentos que se piden por modelo, firma y margen.
- `extractor.toml`: OCR, umbral de confianza y LLM (desactivado).

## Probarlo

```bash
python -m pip install -r requirements.txt
python -m pytest                      # 74 tests con datos sintéticos
python run_all.py --demo --fecha 2027-01-05   # cadena completa con datos inventados (crea ./datos)
```

## Pendiente de los datos reales de Antonio

1. **La plantilla real del Gestor de Importaciones** (`VF_Importacion_Asientos`) y, si existe, la del *Plugin de Facturas*,
   para ajustar `config/sage_mapping.toml`. Hasta entonces, las columnas son supuestas.
2. **Su plan de cuentas** (longitud de las subcuentas y subcuentas de proveedores y clientes) → `config/plan_cuentas.toml`.
3. **10-20 facturas y tickets reales** para calibrar la extracción y el OCR con documentos de verdad.
4. **Un Norma 43 real** de sus bancos (y algún Excel) para confirmar las variantes de cada banco.
5. **La lista de clientes** con el tipo, los modelos y la periodicidad → `datos/clientes/clientes.csv`.
6. Confirmar las reglas de cuentas y los textos de las solicitudes (trato de usted o de tú, firma).

Todo lo que hay en este repositorio son **datos sintéticos**. No contiene datos de clientes.
