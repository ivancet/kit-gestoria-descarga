# Norma 43 y conciliación bancaria

## 1. Lector de extractos (`lector_n43.py`, `excel_banco.py`)

- **Norma 43 / Cuaderno 43 de la AEB** (`.n43`, `.txt`, `.aeb`, `.q43`): registros 11 (cabecera), 22 (movimiento),
  23 (conceptos complementarios), 24 (divisa), 33 (totales) y 88 (fin). Lee ficheros en latin-1 o UTF-8.
  **Comprueba** que los totales de debe y haber y el saldo final del registro 33 cuadran con los movimientos.
  Si no cuadran, avisa (o falla con `estricto=True`).
- **Excel/CSV "sencillo"** de la banca online: localiza la fila de cabecera (Fecha, Concepto, Importe o
  Cargo/Abono, Saldo...) en las 30 primeras filas. Los `.xls` antiguos hay que guardarlos antes como `.xlsx`.

```bat
python lector_n43.py extracto.n43 --salida movimientos.csv
```

Salida normalizada (`;`, decimales con coma): cuenta, titular, fecha_operacion, fecha_valor, importe (negativo = cargo),
concepto, concepto común (con su descripción AEB), documento, referencias, saldo y fichero de origen.

> Para importar el extracto en Sage, el propio **fichero Norma 43 original** se importa en Sage
> (Tesorería → Conciliación Bancaria → Importar ficheros norma 43). Recuerda que Sage exige correlación de saldos
> entre importaciones. Este módulo **no lo sustituye**: sirve para proponer asientos y conciliar con facturas.

## 2. Conciliación (`conciliar.py`)

```bat
python conciliar.py --banco extracto.n43 --facturas ..\datos\facturas\revision\revision.xlsx --salida salida ^
                    --cliente B12345674 --cuenta-banco 57200001
```

Para cada movimiento:
1. **Factura**: el importe tiene que coincidir exactamente con el total, con el signo coherente (cargo ↔ recibida,
   abono ↔ emitida) y la fecha entre 7 días antes y 120 días después de la factura. Suman puntos la proximidad de la fecha
   y que aparezcan en el concepto el **NIF**, el **número de factura** o el **nombre**. Se asigna con un umbral de 60 puntos;
   si hay empate, se marca `AMBIGUO`. Contrapartida: 400 (proveedor) o 430 (cliente).
2. **Regla** (`config/reglas_cuentas.toml`): `IBERDROLA`/`ENDESA`... → 628, `COMISION` → 626, `TGSS` → 642,
   `INTERESES` → 769, `AEAT` → 4750, etc. Admite regex y signo (cargo o abono). Las reglas se editan sin tocar código.
3. **Pendiente**: 555 (partidas pendientes de aplicación) para revisarlo a mano.

Salidas:
- `conciliacion_*.csv`: un movimiento por fila con estado (FACTURA, REGLA o PENDIENTE), cuenta propuesta, confianza y motivo.
- `asientos_banco_*.xlsx`: asientos propuestos (Debe/Haber contra 572) en el perfil Sage por defecto
  (`vf_importacion_asientos`, **columnas supuestas**: ver `extractor-facturas/README.md`).
- `asientos_banco_*_revision.csv`: los mismos asientos en CSV legible.

No se usan las facturas en estado ERROR ni las marcadas `DUPLICADO_POSIBLE`. Si la factura aún no está validada,
se indica en el motivo.

## Datos de prueba

`python generar_n43_prueba.py carpeta` crea un extracto Norma 43 y su versión en Excel. Son sintéticos, con 8 movimientos
que casan con las facturas de prueba del extractor (3 pagos, 1 cobro, comisión, TGSS, intereses y una compra con tarjeta sin justificar).

## Tests

`python -m pytest norma43/tests`. Incluye un extracto escrito a mano con las posiciones del cuaderno.
