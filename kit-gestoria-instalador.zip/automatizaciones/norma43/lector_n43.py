#!/usr/bin/env python3
"""Lector de extractos bancarios AEB Norma 43 (Cuaderno 43, registros de 80 posiciones).

Registros: 11 cabecera de cuenta, 22 movimiento, 23 conceptos complementarios (hasta 5),
24 equivalencia de divisa, 33 final de cuenta (totales y saldo final), 88 fin de fichero.
Valida que los totales del registro 33 coinciden con los movimientos y que
saldo_inicial + haber - debe = saldo_final.

Uso: python norma43.py extracto.n43 [otro.txt ...] --salida movimientos.csv
"""
import argparse
import sys
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from comun.tabla import escribir_csv  # noqa: E402

CONCEPTOS_COMUNES = {
    "01": "Talones - reintegros", "02": "Abonarés - entregas - ingresos",
    "03": "Domiciliados - recibos - letras - pagos por su cuenta", "04": "Giros - transferencias - traspasos - cheques",
    "05": "Amortizaciones préstamos, créditos, etc.", "06": "Remesas efectos",
    "07": "Suscripciones - dividendos pasivos - canjes", "08": "Dividendos - cupones - amortizaciones",
    "09": "Operaciones de bolsa y/o compra-venta valores", "10": "Cheques gasolina",
    "11": "Cajeros automáticos", "12": "Tarjetas de crédito - tarjetas de débito",
    "13": "Operaciones con el extranjero", "14": "Devoluciones e impagados",
    "15": "Nóminas - seguros sociales", "16": "Timbres - corretaje - póliza",
    "17": "Intereses - comisiones - custodia - gastos e impuestos", "98": "Anulaciones - correcciones de asiento",
    "99": "Varios",
}


class ErrorN43(ValueError):
    pass


def _fecha(aammdd):
    a, m, d = int(aammdd[0:2]), int(aammdd[2:4]), int(aammdd[4:6])
    return date(2000 + a, m, d)


def _imp(s):
    return Decimal(int(s)) / 100


@dataclass
class Movimiento:
    fecha_operacion: date
    fecha_valor: date
    concepto_comun: str
    concepto_propio: str
    importe: Decimal  # con signo: negativo = cargo (debe), positivo = abono (haber)
    documento: str
    referencia1: str
    referencia2: str
    conceptos: list = field(default_factory=list)
    oficina_origen: str = ""
    divisa_origen: str = ""
    importe_divisa: Decimal | None = None

    @property
    def concepto(self):
        return " ".join(c for c in self.conceptos if c).strip() or self.referencia2.strip()


@dataclass
class Cuenta:
    banco: str
    oficina: str
    numero: str
    fecha_inicial: date
    fecha_final: date
    saldo_inicial: Decimal
    divisa: str
    titular: str
    movimientos: list = field(default_factory=list)
    saldo_final: Decimal | None = None
    avisos: list = field(default_factory=list)

    @property
    def id(self):
        return f"{self.banco}-{self.oficina}-{self.numero}"


def leer(ruta_o_texto, estricto=False):
    """Devuelve lista de Cuenta. Acepta ruta o el contenido como str."""
    es_ruta = isinstance(ruta_o_texto, Path) or ("\n" not in str(ruta_o_texto) and len(str(ruta_o_texto)) < 500)
    if es_ruta and Path(str(ruta_o_texto)).exists():
        datos = Path(ruta_o_texto).read_bytes()
        try:
            texto = datos.decode("utf-8")
        except UnicodeDecodeError:
            texto = datos.decode("latin-1")
    else:
        texto = str(ruta_o_texto)
    cuentas, cuenta, mov = [], None, None
    fin_fichero = False
    for n, linea in enumerate(texto.splitlines(), 1):
        linea = linea.rstrip("\r\n")
        if not linea.strip():
            continue
        if len(linea) < 80:
            linea = linea.ljust(80)
        tipo = linea[0:2]
        try:
            if tipo == "11":
                cuenta = Cuenta(banco=linea[2:6], oficina=linea[6:10], numero=linea[10:20],
                                fecha_inicial=_fecha(linea[20:26]), fecha_final=_fecha(linea[26:32]),
                                saldo_inicial=_imp(linea[33:47]) * (-1 if linea[32] == "1" else 1),
                                divisa=linea[47:50], titular=linea[51:77].strip())
                cuentas.append(cuenta)
                mov = None
            elif tipo == "22":
                if cuenta is None:
                    raise ErrorN43("movimiento sin cabecera de cuenta")
                signo = -1 if linea[27] == "1" else 1
                mov = Movimiento(fecha_operacion=_fecha(linea[10:16]), fecha_valor=_fecha(linea[16:22]),
                                 concepto_comun=linea[22:24], concepto_propio=linea[24:27],
                                 importe=_imp(linea[28:42]) * signo, documento=linea[42:52].strip(),
                                 referencia1=linea[52:64].strip(), referencia2=linea[64:80].strip(),
                                 oficina_origen=linea[6:10])
                cuenta.movimientos.append(mov)
            elif tipo == "23":
                if mov is None:
                    raise ErrorN43("concepto complementario sin movimiento")
                mov.conceptos += [linea[4:42].strip(), linea[42:80].strip()]
            elif tipo == "24":
                if mov is not None:
                    mov.divisa_origen = linea[4:7]
                    mov.importe_divisa = _imp(linea[7:21])
            elif tipo == "33":
                if cuenta is None:
                    raise ErrorN43("final de cuenta sin cabecera")
                n_debe, t_debe = int(linea[20:25]), _imp(linea[25:39])
                n_haber, t_haber = int(linea[39:44]), _imp(linea[44:58])
                cuenta.saldo_final = _imp(linea[59:73]) * (-1 if linea[58] == "1" else 1)
                debe = [m for m in cuenta.movimientos if m.importe < 0]
                haber = [m for m in cuenta.movimientos if m.importe >= 0]
                if len(debe) != n_debe or -sum(m.importe for m in debe) != t_debe:
                    cuenta.avisos.append(f"Totales DEBE no cuadran ({len(debe)} mov., registro 33: {n_debe})")
                if len(haber) != n_haber or sum(m.importe for m in haber) != t_haber:
                    cuenta.avisos.append(f"Totales HABER no cuadran ({len(haber)} mov., registro 33: {n_haber})")
                if cuenta.saldo_inicial + t_haber - t_debe != cuenta.saldo_final:
                    cuenta.avisos.append("Saldo inicial + haber - debe no coincide con saldo final")
                mov = None
            elif tipo == "88":
                fin_fichero = True
            else:
                raise ErrorN43(f"tipo de registro desconocido '{tipo}'")
        except (ValueError, IndexError) as e:
            raise ErrorN43(f"Línea {n}: {e}") from e
    if not cuentas:
        raise ErrorN43("El fichero no contiene cuentas Norma 43")
    if not fin_fichero:
        cuentas[-1].avisos.append("Falta registro 88 (fin de fichero)")
    for c in cuentas:
        if c.saldo_final is None:
            c.avisos.append("Falta registro 33 (final de cuenta)")
    if estricto and any(c.avisos for c in cuentas):
        raise ErrorN43("; ".join(a for c in cuentas for a in c.avisos))
    return cuentas


COLUMNAS = ["cuenta", "titular", "fecha_operacion", "fecha_valor", "importe", "signo", "concepto",
            "concepto_comun", "concepto_comun_desc", "concepto_propio", "documento", "referencia1", "referencia2",
            "saldo", "origen"]


def a_filas(cuentas, origen=""):
    filas = []
    for c in cuentas:
        saldo = c.saldo_inicial
        for m in c.movimientos:
            saldo += m.importe
            filas.append(dict(cuenta=c.id, titular=c.titular, fecha_operacion=m.fecha_operacion,
                              fecha_valor=m.fecha_valor, importe=m.importe,
                              signo="abono" if m.importe >= 0 else "cargo", concepto=m.concepto,
                              concepto_comun=m.concepto_comun,
                              concepto_comun_desc=CONCEPTOS_COMUNES.get(m.concepto_comun, ""),
                              concepto_propio=m.concepto_propio, documento=m.documento, referencia1=m.referencia1,
                              referencia2=m.referencia2, saldo=saldo, origen=origen))
    return filas


# ------------------------------------------------------------- escritor (para datos de prueba)
def _a(d):
    return d.strftime("%y%m%d")


def _n(v, ancho=14):
    return f"{int(abs(Decimal(v)) * 100):0{ancho}d}"


def escribir(cuenta: Cuenta):
    """Genera texto Norma 43 para una cuenta (usado para crear extractos sintéticos de prueba)."""
    L = []
    si = cuenta.saldo_inicial
    L.append(f"11{cuenta.banco:>4}{cuenta.oficina:>4}{cuenta.numero:>10}{_a(cuenta.fecha_inicial)}"
             f"{_a(cuenta.fecha_final)}{'1' if si < 0 else '2'}{_n(si)}{cuenta.divisa}3{cuenta.titular[:26]:<26}   ")
    debe = haber = Decimal("0")
    nd = nh = 0
    for m in cuenta.movimientos:
        clave = "1" if m.importe < 0 else "2"
        if m.importe < 0:
            debe += -m.importe
            nd += 1
        else:
            haber += m.importe
            nh += 1
        L.append(f"22    {cuenta.oficina:>4}{_a(m.fecha_operacion)}{_a(m.fecha_valor)}{m.concepto_comun:>2}"
                 f"{m.concepto_propio:>3}{clave}{_n(m.importe)}{m.documento[:10]:>10}{m.referencia1[:12]:<12}"
                 f"{m.referencia2[:16]:<16}")
        conc = list(m.conceptos)
        for i in range(0, len(conc), 2):
            a, b = conc[i], conc[i + 1] if i + 1 < len(conc) else ""
            L.append(f"23{(i // 2 + 1):02d}{a[:38]:<38}{b[:38]:<38}")
    sf = si + haber - debe
    L.append(f"33{cuenta.banco:>4}{cuenta.oficina:>4}{cuenta.numero:>10}{nd:05d}{_n(debe)}{nh:05d}{_n(haber)}"
             f"{'1' if sf < 0 else '2'}{_n(sf)}{cuenta.divisa}    ")
    L.append(f"88{'9' * 18}{len(L):06d}".ljust(80))
    assert all(len(x) == 80 for x in L), [len(x) for x in L]
    return "\r\n".join(L) + "\r\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ficheros", nargs="+")
    ap.add_argument("--salida", required=True)
    a = ap.parse_args(argv)
    filas = []
    for f in a.ficheros:
        cuentas = leer(f)
        for c in cuentas:
            print(f"{Path(f).name}: cuenta {c.id} {c.titular}: {len(c.movimientos)} movimientos, "
                  f"saldo {c.saldo_inicial} -> {c.saldo_final}")
            for av in c.avisos:
                print("  AVISO:", av)
        filas += a_filas(cuentas, Path(f).name)
    escribir_csv(a.salida, filas, COLUMNAS)
    print(f"{len(filas)} movimientos -> {a.salida}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
