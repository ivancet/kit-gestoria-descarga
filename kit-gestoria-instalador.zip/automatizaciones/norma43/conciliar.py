#!/usr/bin/env python3
"""Conciliación bancaria asistida: movimientos (Norma 43 / Excel) <-> facturas extraídas.

Para cada movimiento propone:
  1) la factura que casa (importe exacto + fecha cercana + NIF / nº factura / nombre en el concepto), o
  2) una cuenta según config/reglas_cuentas.toml (p. ej. 'IBERDROLA' -> 628), o
  3) la cuenta de partidas pendientes de aplicación (555) marcada como PENDIENTE.
Genera conciliacion.csv (para revisar) y un fichero de asientos propuestos para Sage
(perfil por defecto de config/sage_mapping.toml) más una copia CSV legible.

Uso:
  python conciliar.py --banco extracto.n43 [--banco otro.xlsx] --facturas revision.xlsx --salida carpeta
                      [--cliente NIF] [--cuenta-banco 57200001] [--perfil vf_importacion_asientos]
"""
import argparse
import re
import sys
import unicodedata
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "extractor-facturas"))

from comun.asientos import PlanCuentas, asiento_movimiento, cuadra  # noqa: E402
from comun.config import cargar_toml  # noqa: E402
from comun.importes import parse_importe, r2  # noqa: E402
from comun.reglas import Reglas  # noqa: E402
from comun.sage_export import exportar  # noqa: E402
from comun.tabla import leer_tabla, escribir_csv  # noqa: E402
import lector_n43 as norma43  # noqa: E402
import excel_banco  # noqa: E402

UMBRAL = 60
GENERICAS = {"SL", "SA", "SLU", "SOCIEDAD", "LIMITADA", "ANONIMA", "COMERCIALIZADORA", "SERVICIOS", "DEL", "LOS",
             "LAS", "CIA", "GRUPO", "ESPANA", "FICTICIA", "FICTICIO"}


def _n(s):
    s = unicodedata.normalize("NFKD", str(s or ""))
    return "".join(c for c in s if not unicodedata.combining(c)).upper()


def _alnum(s):
    return re.sub(r"[^A-Z0-9]", "", _n(s))


def _fecha(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v or "")[:10]
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def cargar_movimientos(rutas):
    movs = []
    for r in rutas:
        r = Path(r)
        suf = r.suffix.lower()
        if suf in (".n43", ".txt", ".aeb", ".q43", ".43"):
            movs += norma43.a_filas(norma43.leer(r), r.name)
        elif suf == ".csv" and "fecha_operacion" in r.read_text(encoding="utf-8-sig", errors="ignore")[:300]:
            for f in leer_tabla(r):  # CSV normalizado de lector_n43.py
                f["importe"] = parse_importe(f["importe"])
                f["fecha_operacion"] = _fecha(f["fecha_operacion"])
                movs.append(f)
        else:
            movs += excel_banco.leer_excel(r)
    return movs


def cargar_facturas(ruta, cliente=None):
    import revision as rev
    out = []
    for f in rev.leer_revision(ruta):
        if f.get("estado") == "ERROR" or "DUPLICADO_POSIBLE" in str(f.get("avisos", "")):
            continue
        fac = rev.fila_a_factura(f)
        if cliente and fac["cliente_nif"].upper() != cliente.upper():
            continue
        fac["fecha_d"] = _fecha(fac["fecha"])
        fac["validada"] = str(f.get("validado", "")).upper().startswith("S")
        if fac["tipo"] in ("recibida", "emitida") and fac["total"] and fac["fecha_d"]:
            out.append(fac)
    return out


def puntuar(m, f):
    imp = r2(m["importe"])
    if (imp < 0) != (f["tipo"] == "recibida"):
        return 0, ""
    if abs(abs(imp) - r2(f["total"])) > Decimal("0.01"):
        return 0, ""
    dias = (m["fecha_operacion"] - f["fecha_d"]).days
    if dias < -7 or dias > 120:
        return 0, ""
    motivos = ["importe exacto"]
    s = 50 + max(0, 20 - abs(dias) / 6)
    texto = _n(f"{m.get('concepto', '')} {m.get('referencia1', '')} {m.get('referencia2', '')}")
    texto_a = _alnum(texto)
    nif = f["nif_emisor"] if f["tipo"] == "recibida" else f["nif_receptor"]
    if nif and nif in texto_a:
        s += 25
        motivos.append("NIF en concepto")
    if f["numero"] and len(_alnum(f["numero"])) >= 3 and _alnum(f["numero"]) in texto_a:
        s += 20
        motivos.append("nº factura en concepto")
    nombre = f["nombre_emisor"] if f["tipo"] == "recibida" else f["nombre_receptor"]
    toks = [t for t in re.findall(r"[A-Z0-9]{4,}", _n(nombre)) if t not in GENERICAS]
    hits = [t for t in toks if t in texto]
    if hits:
        s += min(15, 5 * len(hits))
        motivos.append("nombre en concepto")
    return round(s), ", ".join(motivos) + f", {dias} días"


def conciliar(movs, facturas, plan, reglas, cuenta_banco=None):
    pares = []
    for i, m in enumerate(movs):
        for j, f in enumerate(facturas):
            s, motivo = puntuar(m, f)
            if s >= UMBRAL:
                pares.append((s, i, j, motivo))
    pares.sort(key=lambda x: -x[0])
    asign, usadas = {}, set()
    for s, i, j, motivo in pares:
        if i in asign or j in usadas:
            continue
        rivales = [p for p in pares if p[1] == i and p[2] != j and p[0] == s and p[2] not in usadas]
        asign[i] = (j, s, motivo + (" (AMBIGUO: otra factura con la misma puntuación)" if rivales else ""))
        usadas.add(j)
    filas, apuntes = [], []
    for i, m in enumerate(movs):
        imp = r2(m["importe"])
        signo = "cargo" if imp < 0 else "abono"
        fila = dict(fecha=m["fecha_operacion"], importe=imp, concepto=m.get("concepto", ""), cuenta_banco=m.get("cuenta", ""),
                    estado="PENDIENTE", cuenta_propuesta=plan.cuenta("partidas_pendientes"), confianza=0,
                    factura_numero="", factura_nif="", factura_archivo="", motivo="Sin factura ni regla")
        if i in asign:
            j, s, motivo = asign[i]
            f = facturas[j]
            nif = f["nif_emisor"] if f["tipo"] == "recibida" else f["nif_receptor"]
            fila.update(estado="FACTURA", confianza=min(100, s), factura_numero=f["numero"], factura_nif=nif,
                        factura_archivo=f["archivo"], motivo=motivo + ("" if f["validada"] else " (factura aún no validada)"),
                        cuenta_propuesta=plan.tercero(nif, "proveedores" if f["tipo"] == "recibida" else "clientes"))
        else:
            r = reglas.buscar(fila["concepto"], signo)
            if r:
                fila.update(estado="REGLA", confianza=70, cuenta_propuesta=plan.sub(r["cuenta"]),
                            motivo=f"Regla '{r['patron']}': {r.get('descripcion', '')}")
        n = len(filas) + 1
        concepto = (fila["factura_numero"] and f"Pago/cobro fra. {fila['factura_numero']}") or fila["concepto"][:60]
        apuntes += asiento_movimiento(n, fila["fecha"], imp, fila["cuenta_propuesta"], concepto,
                                      m.get("documento", "") or fila["factura_numero"], plan, cuenta_banco,
                                      origen=fila["estado"].lower(), confianza=fila["confianza"])
        fila["asiento"] = n
        filas.append(fila)
    assert cuadra(apuntes)
    return filas, apuntes


COLS = ["asiento", "fecha", "importe", "concepto", "estado", "cuenta_propuesta", "confianza", "factura_numero",
        "factura_nif", "factura_archivo", "motivo", "cuenta_banco"]


def ejecutar(bancos, facturas_xlsx, salida, cliente=None, cuenta_banco=None, perfil=None):
    plan, reglas = PlanCuentas(), Reglas()
    movs = cargar_movimientos(bancos)
    facs = cargar_facturas(facturas_xlsx, cliente) if facturas_xlsx and Path(facturas_xlsx).exists() else []
    filas, apuntes = conciliar(movs, facs, plan, reglas, cuenta_banco)
    salida = Path(salida)
    sello = datetime.now().strftime("%Y%m%d_%H%M%S")
    perfil = perfil or cargar_toml("sage_mapping.toml").get("perfil_por_defecto_asientos", "vf_importacion_asientos")
    res = dict(movimientos=len(movs), filas=filas,
               conciliacion=escribir_csv(salida / f"conciliacion_{sello}.csv", filas, COLS),
               asientos=exportar(apuntes, perfil, salida / f"asientos_banco_{sello}"),
               asientos_csv=exportar(apuntes, "asientos_csv", salida / f"asientos_banco_{sello}_revision.csv"))
    return res


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--banco", action="append", required=True, help="fichero .n43/.txt/.xlsx/.csv (repetible)")
    ap.add_argument("--facturas", help="hoja de revisión del extractor (revision.xlsx)")
    ap.add_argument("--salida", required=True)
    ap.add_argument("--cliente", help="NIF del cliente titular de la cuenta (filtra sus facturas)")
    ap.add_argument("--cuenta-banco", help="subcuenta 572 de esa cuenta bancaria en Sage")
    ap.add_argument("--perfil", help="perfil de config/sage_mapping.toml")
    a = ap.parse_args(argv)
    r = ejecutar(a.banco, a.facturas, a.salida, a.cliente, a.cuenta_banco, a.perfil)
    from collections import Counter
    c = Counter(f["estado"] for f in r["filas"])
    print(f"{r['movimientos']} movimientos: {c.get('FACTURA', 0)} con factura, {c.get('REGLA', 0)} por regla, "
          f"{c.get('PENDIENTE', 0)} pendientes (cuenta 555).")
    print(f"  Revisión: {r['conciliacion']}\n  Asientos Sage: {r['asientos']}\n  Asientos (CSV): {r['asientos_csv']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
