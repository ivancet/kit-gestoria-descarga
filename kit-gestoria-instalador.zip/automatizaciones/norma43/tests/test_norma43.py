import shutil
import sys
from datetime import date
from decimal import Decimal
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent))
sys.path.insert(0, str(AQUI.parent / "extractor-facturas"))

import lector_n43 as norma43  # noqa: E402
import excel_banco  # noqa: E402
import conciliar  # noqa: E402
import generar_n43_prueba as gen  # noqa: E402
import generar_datos_prueba as genf  # noqa: E402
import extractor  # noqa: E402
from comun.reglas import Reglas  # noqa: E402

# Ejemplo escrito a mano con las posiciones del Cuaderno 43 (registros de 80 caracteres)
N43_MANUAL = "\n".join([
    "11" + "1234" + "5678" + "0000012345" + "261101" + "261130" + "2" + "00000000100000" + "978" + "3"
    + "EMPRESA FICTICIA SL".ljust(26) + "   ",
    "22" + "    " + "5678" + "261103" + "261103" + "03" + "123" + "1" + "00000000012100" + "0000000001"
    + "REF1".ljust(12) + "REF2".ljust(16),
    "23" + "01" + "RECIBO IBERDROLA CLIENTES".ljust(38) + "FACTURA 21R0001".ljust(38),
    "22" + "    " + "5678" + "261115" + "261116" + "02" + "456" + "2" + "00000000050000" + "0000000002"
    + " " * 12 + " " * 16,
    "23" + "01" + "INGRESO CLIENTE".ljust(38) + " " * 38,
    "33" + "1234" + "5678" + "0000012345" + "00001" + "00000000012100" + "00001" + "00000000050000" + "2"
    + "00000000137900" + "978" + "    ",
    ("88" + "9" * 18 + "000006").ljust(80),
]) + "\n"


def test_lineas_de_80():
    for l in N43_MANUAL.splitlines():
        assert len(l) == 80, (len(l), l)


def test_leer_manual():
    [c] = norma43.leer(N43_MANUAL)
    assert c.id == "1234-5678-0000012345" and c.titular == "EMPRESA FICTICIA SL"
    assert c.saldo_inicial == Decimal("1000.00") and c.saldo_final == Decimal("1379.00")
    assert c.avisos == []
    m1, m2 = c.movimientos
    assert m1.importe == Decimal("-121.00") and m1.fecha_operacion == date(2026, 11, 3)
    assert m1.concepto == "RECIBO IBERDROLA CLIENTES FACTURA 21R0001" and m1.concepto_comun == "03"
    assert m2.importe == Decimal("500.00") and m2.fecha_valor == date(2026, 11, 16)
    filas = norma43.a_filas([c])
    assert filas[-1]["saldo"] == Decimal("1379.00")
    assert Reglas().buscar(m1.concepto, "cargo")["cuenta"] == "628"


def test_totales_incorrectos_avisan():
    malo = N43_MANUAL.replace("00000000137900", "00000000137800")
    [c] = norma43.leer(malo)
    assert any("saldo" in a.lower() for a in c.avisos)
    with pytest.raises(norma43.ErrorN43):
        norma43.leer(malo, estricto=True)


def test_ida_y_vuelta_y_latin1(tmp_path):
    d = gen.generar(tmp_path)
    [c] = norma43.leer(d / "extracto_ficticio.n43")
    assert len(c.movimientos) == 8 and c.avisos == []
    assert c.saldo_final == Decimal("5000.00") + sum(m.importe for m in gen.movimientos())


def test_excel_banco(tmp_path):
    d = gen.generar(tmp_path)
    filas = excel_banco.leer_excel(d / "extracto_ficticio.xlsx")
    assert len(filas) == 8
    assert filas[0]["importe"] == Decimal("-1210.00") and filas[0]["fecha_operacion"] == date(2026, 11, 10)
    # CSV con cargo/abono separados
    p = tmp_path / "b.csv"
    p.write_text("Fecha;Concepto;Cargo;Abono;Saldo\n03/11/2026;RECIBO X;121,00;;879,00\n04/11/2026;INGRESO;;50,00;929,00\n",
                 encoding="utf-8")
    f = excel_banco.leer_excel(p)
    assert [x["importe"] for x in f] == [Decimal("-121.00"), Decimal("50.00")]


@pytest.fixture
def revision(tmp_path):
    fx = tmp_path / "fx"
    genf.generar(fx)
    entrada = tmp_path / "entrada"
    entrada.mkdir()
    for n in ("F01_recibida_21.pdf", "F02_profesional_irpf.pdf", "F04_emitida_4.pdf", "F05_luz.pdf"):
        shutil.copy(fx / n, entrada / n)
    cl = tmp_path / "clientes.csv"
    cl.write_text("cliente;nif;tipo;modelos\nT;%s;sociedad;303\n" % genf.CLIENTE_SL[1], encoding="utf-8")
    x = tmp_path / "revision.xlsx"
    extractor.ejecutar(entrada, x, tmp_path / "p", tmp_path / "e", cl, mover=False)
    return x


@pytest.mark.parametrize("fichero", ["extracto_ficticio.n43", "extracto_ficticio.xlsx"])
def test_conciliacion(tmp_path, revision, fichero):
    d = gen.generar(tmp_path / "banco")
    r = conciliar.ejecutar([d / fichero], revision, tmp_path / "out", cliente=genf.CLIENTE_SL[1])
    est = {str(f["concepto"])[:20]: (f["estado"], f["cuenta_propuesta"], f["factura_numero"]) for f in r["filas"]}
    assert est["TRANSFERENCIA A SUMI"] == ("FACTURA", "40000000", "SF-2026/0457")
    assert est["TRANSF JORDI ASESOR "] == ("FACTURA", "40000000", "2026-031")
    assert est["RECIBO ELECTRA FICTI"][0] == "FACTURA"
    assert est["TRANSF DE COMERCIAL D"[:20]] == ("FACTURA", "43000000", "A-2026-0102")
    assert est["COMISION MANTENIMIEN"][:2] == ("REGLA", "62600000")
    assert est["TGSS COTIZACION 2026"][:2] == ("REGLA", "64200000")
    assert est["COMPRA TARJETA 4B ES"][:2] == ("PENDIENTE", "55500000")
    assert est["LIQUIDACION INTERESE"][:2] == ("REGLA", "76900000")
    assert r["asientos"].suffix == ".xlsx" and r["asientos_csv"].exists()
    from openpyxl import load_workbook
    filas = list(load_workbook(r["asientos"]).active.iter_rows(values_only=True))
    assert len(filas) == 1 + 16
    assert round(sum(x[5] or 0 for x in filas[1:]), 2) == round(sum(x[6] or 0 for x in filas[1:]), 2)


def test_no_casa_si_signo_o_fecha_no_encajan():
    f = dict(tipo="recibida", total=Decimal("100.00"), fecha_d=date(2026, 1, 1), nif_emisor="B12345674",
             nif_receptor="", numero="X1", nombre_emisor="Prov", nombre_receptor="")
    m = dict(importe=Decimal("100.00"), fecha_operacion=date(2026, 1, 5), concepto="")
    assert conciliar.puntuar(m, f)[0] == 0          # abono no paga una factura recibida
    m["importe"] = Decimal("-100.00")
    assert conciliar.puntuar(m, f)[0] >= 60
    m["fecha_operacion"] = date(2026, 9, 1)
    assert conciliar.puntuar(m, f)[0] == 0          # demasiado lejos en el tiempo
