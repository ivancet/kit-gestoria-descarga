#!/usr/bin/env python3
"""Genera un extracto Norma 43 y un Excel bancario SINTÉTICOS que casan con las facturas de prueba
de extractor-facturas/generar_datos_prueba.py (datos inventados)."""
import sys
from datetime import date
from decimal import Decimal as D
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "extractor-facturas"))
import lector_n43 as norma43  # noqa: E402
from generar_datos_prueba import PROV_SUMIN, CLI_FINAL  # noqa: E402

M = norma43.Movimiento


def movimientos():
    return [
        M(date(2026, 11, 10), date(2026, 11, 10), "04", "001", D("-1210.00"), "0000000001", "", "",
          ["TRANSFERENCIA A SUMINISTROS FICTICIOS", "FRA SF-2026/0457"]),
        M(date(2026, 11, 12), date(2026, 11, 12), "04", "001", D("-530.00"), "0000000002", "", "",
          ["TRANSF JORDI ASESOR FICTICIO", "HONORARIOS 2026-031"]),
        M(date(2026, 11, 5), date(2026, 11, 5), "03", "002", D("-100.00"), "0000000003", "", "",
          ["RECIBO ELECTRA FICTICIA COMERCIALIZAD", "EF26-998877"]),
        M(date(2026, 11, 13), date(2026, 11, 13), "02", "010", D("260.00"), "0000000004", "", "",
          [f"TRANSF DE {CLI_FINAL[0][:25].upper()}", f"NIF {CLI_FINAL[1]}"]),
        M(date(2026, 11, 14), date(2026, 11, 14), "17", "020", D("-12.50"), "0000000005", "", "",
          ["COMISION MANTENIMIENTO CUENTA"]),
        M(date(2026, 11, 2), date(2026, 11, 2), "15", "030", D("-287.40"), "0000000006", "", "",
          ["TGSS COTIZACION 202610"]),
        M(date(2026, 11, 8), date(2026, 11, 8), "12", "040", D("-99.99"), "0000000007", "", "",
          ["COMPRA TARJETA 4B ESTABLECIMIENTO X"]),
        M(date(2026, 11, 30), date(2026, 11, 30), "17", "050", D("0.35"), "0000000008", "", "",
          ["LIQUIDACION INTERESES"]),
    ]


def cuenta():
    c = norma43.Cuenta(banco="9999", oficina="0001", numero="0123456789", fecha_inicial=date(2026, 11, 1),
                       fecha_final=date(2026, 11, 30), saldo_inicial=D("5000.00"), divisa="978",
                       titular="TALLERES EJEMPLO FICTICIO")
    c.movimientos = movimientos()
    return c


def generar(destino):
    destino = Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    (destino / "extracto_ficticio.n43").write_bytes(norma43.escribir(cuenta()).encode("latin-1"))
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["Banco Ficticio - Movimientos de la cuenta ES00 9999 0001 ..."])
    ws.append([])
    ws.append(["Fecha", "Fecha valor", "Concepto", "Importe", "Saldo"])
    saldo = D("5000.00")
    for m in movimientos():
        saldo += m.importe
        ws.append([m.fecha_operacion.strftime("%d/%m/%Y"), m.fecha_valor, m.concepto, float(m.importe), float(saldo)])
    wb.save(destino / "extracto_ficticio.xlsx")
    return destino


if __name__ == "__main__":
    print(generar(sys.argv[1] if len(sys.argv) > 1 else AQUI / "datos_prueba"))
