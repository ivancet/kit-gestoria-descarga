"""Lectura de extractos bancarios en Excel/CSV 'sencillo' (los que descarga la banca online).

Detecta la fila de cabecera buscando columnas de fecha e importe (o cargo/abono) en las primeras
30 filas. Se pueden forzar nombres de columna con el parámetro `columnas`.
"""
import csv
import re
import unicodedata
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from comun.importes import parse_importe  # noqa: E402

SINONIMOS = {
    "fecha_operacion": ["fecha operacion", "f. operacion", "fecha", "fecha contable", "f. contable", "date"],
    "fecha_valor": ["fecha valor", "f. valor", "valor"],
    "concepto": ["concepto", "descripcion", "movimiento", "detalle", "concepto/descripcion", "observaciones",
                 "mas datos", "description"],
    "importe": ["importe", "importe eur", "importe (eur)", "cantidad", "amount", "importe euros"],
    "cargo": ["cargo", "cargos", "debe", "gastos", "salidas"],
    "abono": ["abono", "abonos", "haber", "ingresos", "entradas"],
    "saldo": ["saldo", "saldo eur", "saldo (eur)", "balance"],
}


def _n(s):
    s = unicodedata.normalize("NFKD", str(s or ""))
    return re.sub(r"\s+", " ", "".join(c for c in s if not unicodedata.combining(c)).lower()).strip(" :")


def _filas_crudas(ruta):
    ruta = Path(ruta)
    if ruta.suffix.lower() in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(ruta, data_only=True, read_only=True)
        ws = wb.worksheets[0]
        filas = [list(r) for r in ws.iter_rows(values_only=True)]
        wb.close()
        return filas
    if ruta.suffix.lower() == ".xls":
        raise ValueError("Formato .xls antiguo: abrir en Excel y 'Guardar como' .xlsx (o descargar Norma 43)")
    data = ruta.read_bytes()
    try:
        txt = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        txt = data.decode("cp1252")
    delim = ";" if txt.count(";") >= txt.count(",") else ","
    return [r for r in csv.reader(txt.splitlines(), delimiter=delim)]


def _fecha(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v or "").strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%d.%m.%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def detectar_cabecera(filas, maximo=30):
    for i, f in enumerate(filas[:maximo]):
        nombres = [_n(c) for c in f]
        mapa = {}
        for campo, sins in SINONIMOS.items():
            for j, nm in enumerate(nombres):
                if nm in sins and j not in mapa.values():
                    mapa[campo] = j
                    break
        if "fecha_operacion" in mapa and ("importe" in mapa or ("cargo" in mapa and "abono" in mapa)):
            return i, mapa
    raise ValueError("No encuentro la cabecera (columnas de fecha e importe) en el Excel del banco")


def leer_excel(ruta, cuenta="", columnas=None):
    filas = _filas_crudas(ruta)
    if columnas:
        i = 0
        nombres = [_n(c) for c in filas[0]]
        mapa = {k: nombres.index(_n(v)) for k, v in columnas.items()}
    else:
        i, mapa = detectar_cabecera(filas)
    out = []
    for f in filas[i + 1:]:
        def g(campo):
            j = mapa.get(campo)
            return f[j] if j is not None and j < len(f) else None
        fecha = _fecha(g("fecha_operacion"))
        if not fecha:
            continue
        if "importe" in mapa:
            imp = parse_importe(g("importe"))
        else:
            c, a = parse_importe(g("cargo")) or Decimal("0"), parse_importe(g("abono")) or Decimal("0")
            imp = a - abs(c)
        if imp is None:
            continue
        out.append(dict(cuenta=cuenta, titular="", fecha_operacion=fecha, fecha_valor=_fecha(g("fecha_valor")) or fecha,
                        importe=imp, signo="abono" if imp >= 0 else "cargo", concepto=str(g("concepto") or "").strip(),
                        concepto_comun="", concepto_comun_desc="", concepto_propio="", documento="",
                        referencia1="", referencia2="", saldo=parse_importe(g("saldo")) if "saldo" in mapa else "",
                        origen=Path(ruta).name))
    return out
