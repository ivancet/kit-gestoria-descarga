"""Carga de configuración TOML (Python 3.11+ trae tomllib)."""
import os
from pathlib import Path
import tomllib

RAIZ = Path(__file__).resolve().parent.parent
DIR_CONFIG = RAIZ / "config"


def cargar_toml(nombre_o_ruta):
    p = Path(nombre_o_ruta)
    if not p.is_absolute() and not p.exists():
        p = DIR_CONFIG / p
    with open(p, "rb") as f:
        return tomllib.load(f)


def rutas():
    """Rutas de trabajo (config/rutas.toml). Relativas a la carpeta raíz del toolkit.
    La variable de entorno GESTORIA_DATOS, si existe, sustituye a 'base'."""
    cfg = cargar_toml("rutas.toml")
    base = Path(os.environ.get("GESTORIA_DATOS") or cfg.get("base", "datos"))
    if not base.is_absolute():
        base = RAIZ / base
    out = {"base": base}
    for k, v in cfg.get("carpetas", {}).items():
        p = Path(v)
        out[k] = p if p.is_absolute() else base / p
    return out
