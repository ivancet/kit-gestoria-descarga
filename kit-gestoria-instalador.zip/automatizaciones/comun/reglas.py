"""Reglas texto -> cuenta contable (config/reglas_cuentas.toml)."""
import re
import unicodedata

from .config import cargar_toml


def _norm(s):
    s = unicodedata.normalize("NFKD", s or "")
    return "".join(c for c in s if not unicodedata.combining(c)).upper()


class Reglas:
    def __init__(self, ruta="reglas_cuentas.toml"):
        self.reglas = []
        for r in cargar_toml(ruta).get("regla", []):
            pat = _norm(r["patron"])
            rx = re.compile(pat if r.get("regex") else re.escape(pat))
            self.reglas.append(dict(r, _rx=rx))

    def buscar(self, texto, signo=None):
        """signo: 'cargo' | 'abono' | None. Devuelve dict regla o None."""
        t = _norm(texto)
        for r in self.reglas:
            if r.get("signo") and signo and r["signo"] != signo:
                continue
            if r["_rx"].search(t):
                return {k: v for k, v in r.items() if not k.startswith("_")}
        return None
