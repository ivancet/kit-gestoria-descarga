"""Capa de exportación a Sage Despachos Connected, dirigida por configuración.

Cada *perfil* de config/sage_mapping.toml define:
  - tipo: "asientos" | "facturas_recibidas" | "facturas_emitidas"
  - formato: "xlsx" | "csv"
  - columnas: lista ordenada de {columna, campo | valor, formato_fecha, decimales, ...}

Así, cuando Antonio nos dé su plantilla real (guía VF_Importacion_Asientos del Gestor
de Importaciones, o la del Plugin de Facturas), basta con editar el TOML: el código no cambia.
"""
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
import csv

from .config import cargar_toml


def cargar_perfil(nombre, ruta_mapping="sage_mapping.toml"):
    cfg = cargar_toml(ruta_mapping)
    perfiles = cfg.get("perfiles", {})
    if nombre not in perfiles:
        raise KeyError(f"Perfil Sage '{nombre}' no existe en {ruta_mapping}. Disponibles: {', '.join(perfiles)}")
    p = dict(perfiles[nombre])
    p["nombre"] = nombre
    return p


def _valor(fila, col, perfil):
    if "valor" in col:
        v = col["valor"]
    elif "plantilla" in col:
        v = col["plantilla"].format(**{k: ("" if x is None else x) for k, x in fila.items()})
    else:
        v = fila.get(col["campo"], "")
    if v is None:
        v = ""
    if isinstance(v, str) and v and col.get("tipo") in ("fecha", "importe"):
        if col.get("tipo") == "fecha":
            try:
                v = datetime.strptime(v[:10], "%Y-%m-%d").date()
            except ValueError:
                pass
        else:
            try:
                v = Decimal(v.replace(",", "."))
            except Exception:
                pass
    if isinstance(v, (date, datetime)):
        fmt = col.get("formato_fecha", perfil.get("formato_fecha", "%d/%m/%Y"))
        if perfil.get("formato") == "xlsx" and fmt == "excel":
            return v
        return v.strftime(fmt)
    if isinstance(v, (Decimal, float, int)) and not isinstance(v, bool):
        if col.get("vacio_si_cero") and Decimal(str(v)) == 0:
            return ""
        dec = col.get("decimales", perfil.get("decimales", 2))
        if perfil.get("formato") == "xlsx":
            return round(float(v), dec)
        s = f"{Decimal(str(v)):.{dec}f}"
        return s.replace(".", ",") if perfil.get("separador_decimal", ",") == "," else s
    v = str(v)
    if col.get("max"):
        v = v[: int(col["max"])]
    return v


def exportar(filas, perfil, ruta_salida):
    """Escribe `filas` (lista de dicts) según el perfil. Devuelve la ruta escrita."""
    if isinstance(perfil, str):
        perfil = cargar_perfil(perfil)
    cols = perfil["columnas"]
    ruta = Path(ruta_salida)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    cab = [c["columna"] for c in cols]
    datos = [[_valor(f, c, perfil) for c in cols] for f in filas]
    if perfil.get("formato", "csv") == "xlsx":
        from openpyxl import Workbook
        from openpyxl.styles import Font
        if ruta.suffix.lower() != ".xlsx":
            ruta = ruta.with_suffix(".xlsx")
        wb = Workbook()
        ws = wb.active
        ws.title = perfil.get("hoja", "Hoja1")
        fila_ini = int(perfil.get("fila_inicio", 1))
        for _ in range(fila_ini - 1):
            ws.append([])
        if perfil.get("cabecera", True):
            ws.append(cab)
            for c in ws[fila_ini]:
                c.font = Font(bold=True)
        for d in datos:
            ws.append(d)
        for i, c in enumerate(cols, start=1):
            if c.get("tipo") == "fecha" or c.get("formato_fecha") == "excel":
                for row in ws.iter_rows(min_row=fila_ini + 1, min_col=i, max_col=i):
                    row[0].number_format = "DD/MM/YYYY"
        wb.save(ruta)
    else:
        if ruta.suffix.lower() not in (".csv", ".txt"):
            ruta = ruta.with_suffix(".csv")
        with open(ruta, "w", newline="", encoding=perfil.get("codificacion", "utf-8-sig")) as f:
            w = csv.writer(f, delimiter=perfil.get("separador", ";"))
            if perfil.get("cabecera", True):
                w.writerow(cab)
            w.writerows(datos)
    return ruta
