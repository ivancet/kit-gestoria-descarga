"""Construcción de asientos contables (partida doble) a partir de facturas y movimientos."""
from decimal import Decimal

from .config import cargar_toml
from .importes import r2

D0 = Decimal("0.00")


class PlanCuentas:
    def __init__(self, ruta="plan_cuentas.toml"):
        cfg = cargar_toml(ruta)
        self.longitud = int(cfg.get("longitud_subcuenta", 8))
        self.c = cfg.get("cuentas", {})
        self.terceros = {k.upper(): v for k, v in cfg.get("terceros", {}).items()}

    def sub(self, cuenta, sufijo=""):
        cuenta = str(cuenta)
        if not self.longitud or len(cuenta) >= self.longitud:
            return cuenta
        return cuenta.ljust(self.longitud - len(sufijo), "0") + sufijo

    def cuenta(self, clave):
        return self.sub(self.c[clave])

    def tercero(self, nif, clave):
        if nif and nif.upper() in self.terceros:
            return self.terceros[nif.upper()]
        return self.sub(self.c[clave])


def _apunte(n, fecha, cuenta, concepto, doc, debe=D0, haber=D0, **extra):
    a = dict(asiento=n, fecha=fecha, cuenta=cuenta, concepto=concepto, documento=doc,
             debe=r2(debe), haber=r2(haber), contrapartida="", nif="", base_iva="", tipo_iva="",
             cuota_iva="", origen="", confianza="")
    a.update(extra)
    return a


def asiento_factura(n, fac, plan: PlanCuentas):
    """fac: dict con tipo, fecha, numero, nif_emisor, nombre_emisor, nif_receptor, nombre_receptor,
    lineas_iva [{tipo, base, cuota}], tipo_irpf, irpf, total, cuenta_gasto_ingreso (opcional)."""
    fecha, doc = fac["fecha"], fac.get("numero", "")
    lineas = fac.get("lineas_iva") or []
    irpf = r2(fac.get("irpf") or 0)
    total = r2(fac["total"])
    base_total = sum((r2(l["base"]) for l in lineas), D0)
    out = []
    if fac["tipo"] == "recibida":
        nif, nombre = fac.get("nif_emisor", ""), fac.get("nombre_emisor", "")
        tercero = plan.tercero(nif, "proveedores")
        gasto = plan.sub(fac.get("cuenta_gasto_ingreso") or plan.c["gasto_por_defecto"])
        concepto = f"Fra. {doc} {nombre}".strip()
        out.append(_apunte(n, fecha, gasto, concepto, doc, debe=base_total, contrapartida=tercero, nif=nif))
        for l in lineas:
            if r2(l["cuota"]) != 0:
                out.append(_apunte(n, fecha, plan.cuenta("iva_soportado"), concepto, doc, debe=l["cuota"],
                                   contrapartida=tercero, nif=nif, base_iva=r2(l["base"]),
                                   tipo_iva=l["tipo"], cuota_iva=r2(l["cuota"])))
        if irpf:
            out.append(_apunte(n, fecha, plan.cuenta("irpf_retenciones_practicadas"), concepto, doc, haber=irpf,
                               contrapartida=tercero, nif=nif))
        out.append(_apunte(n, fecha, tercero, concepto, doc, haber=total, contrapartida=gasto, nif=nif))
    else:
        nif, nombre = fac.get("nif_receptor", ""), fac.get("nombre_receptor", "")
        tercero = plan.tercero(nif, "clientes")
        ingreso = plan.sub(fac.get("cuenta_gasto_ingreso") or plan.c["ingreso_por_defecto"])
        concepto = f"Fra. {doc} {nombre}".strip()
        out.append(_apunte(n, fecha, tercero, concepto, doc, debe=total, contrapartida=ingreso, nif=nif))
        if irpf:
            out.append(_apunte(n, fecha, plan.cuenta("irpf_retenciones_soportadas"), concepto, doc, debe=irpf,
                               contrapartida=tercero, nif=nif))
        out.append(_apunte(n, fecha, ingreso, concepto, doc, haber=base_total, contrapartida=tercero, nif=nif))
        for l in lineas:
            if r2(l["cuota"]) != 0:
                out.append(_apunte(n, fecha, plan.cuenta("iva_repercutido"), concepto, doc, haber=l["cuota"],
                                   contrapartida=tercero, nif=nif, base_iva=r2(l["base"]),
                                   tipo_iva=l["tipo"], cuota_iva=r2(l["cuota"])))
    for a in out:
        a["origen"] = "factura"
        a["tipo_factura"] = fac["tipo"]
    return out


def asiento_movimiento(n, fecha, importe, cuenta_contra, concepto, doc, plan: PlanCuentas, cuenta_banco=None,
                       origen="banco", confianza=""):
    """Cobro (importe>0): Debe banco / Haber contrapartida. Pago (importe<0): al revés."""
    banco = cuenta_banco or plan.cuenta("banco")
    imp = abs(r2(importe))
    if importe >= 0:
        res = [_apunte(n, fecha, banco, concepto, doc, debe=imp, contrapartida=cuenta_contra),
               _apunte(n, fecha, cuenta_contra, concepto, doc, haber=imp, contrapartida=banco)]
    else:
        res = [_apunte(n, fecha, cuenta_contra, concepto, doc, debe=imp, contrapartida=banco),
               _apunte(n, fecha, banco, concepto, doc, haber=imp, contrapartida=cuenta_contra)]
    for a in res:
        a["origen"], a["confianza"] = origen, confianza
    return res


def cuadra(apuntes):
    from collections import defaultdict
    s = defaultdict(lambda: D0)
    for a in apuntes:
        s[a["asiento"]] += r2(a["debe"]) - r2(a["haber"])
    return all(v == 0 for v in s.values())
