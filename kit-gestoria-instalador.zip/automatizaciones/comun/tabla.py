"""Lectura/escritura de CSV (Excel español: ';' y UTF-8 con BOM) y XLSX."""
import csv
from datetime import date
from decimal import Decimal
from pathlib import Path


def _celda(v):
    if v is None:
        return ""
    if isinstance(v, Decimal):
        return f"{v:.2f}".replace(".", ",")
    if isinstance(v, date):
        return v.isoformat()[:10]
    return v


def leer_csv(ruta):
    ruta = Path(ruta)
    data = ruta.read_bytes()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            txt = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    primera = txt.splitlines()[0] if txt else ""
    delim = ";" if primera.count(";") >= primera.count(",") else ","
    filas = list(csv.DictReader(txt.splitlines(), delimiter=delim))
    return [{(k or "").strip(): (v or "").strip() for k, v in f.items()} for f in filas]


def escribir_csv(ruta, filas, columnas=None, delim=";", encoding="utf-8-sig"):
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    if columnas is None:
        columnas = list(filas[0].keys()) if filas else []
    with open(ruta, "w", newline="", encoding=encoding) as f:
        w = csv.DictWriter(f, fieldnames=columnas, delimiter=delim, extrasaction="ignore")
        w.writeheader()
        for fila in filas:
            w.writerow({k: _celda(fila.get(k)) for k in columnas})
    return ruta


def leer_tabla(ruta, hoja=None):
    """Lee CSV o XLSX como lista de dicts (primera fila = cabecera)."""
    ruta = Path(ruta)
    if ruta.suffix.lower() in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(ruta, data_only=True, read_only=True)
        ws = wb[hoja] if hoja else wb.worksheets[0]
        filas = list(ws.iter_rows(values_only=True))
        wb.close()
        if not filas:
            return []
        cab = [str(c).strip() if c is not None else "" for c in filas[0]]
        out = []
        for f in filas[1:]:
            if all(c is None or str(c).strip() == "" for c in f):
                continue
            out.append({cab[i]: ("" if c is None else c) for i, c in enumerate(f) if i < len(cab)})
        return out
    return leer_csv(ruta)
