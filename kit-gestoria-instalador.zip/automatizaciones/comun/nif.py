"""Validación de NIF/DNI, NIE y CIF españoles (dígito/letra de control)."""
import re

LETRAS_DNI = "TRWAGMYFPDXBNJZSQVHLCKE"
LETRAS_CIF_CONTROL = "JABCDEFGHI"
# Tipos de entidad cuyo control es siempre letra / siempre dígito
CIF_SOLO_LETRA = set("KLMNPQRSW")
CIF_SOLO_DIGITO = set("ABEH")
CIF_PRIMERAS = set("ABCDEFGHJKLMNPQRSUVW")

_PATRON = re.compile(r"(?<![A-Z0-9])(?:ES[ \-]?)?([A-Z]?[ \-.]?\d{2}[. ]?\d{3}[. ]?\d{2,3}[ \-]?[A-Z0-9]?)(?![A-Z0-9])", re.I)


def normalizar(nif: str) -> str:
    s = re.sub(r"[\s\-\.]", "", (nif or "").upper())
    if s.startswith("ES") and len(s) == 11:
        s = s[2:]
    return s


def letra_dni(numero: int) -> str:
    return LETRAS_DNI[numero % 23]


def control_cif(cuerpo7: str) -> int:
    pares = sum(int(cuerpo7[i]) for i in (1, 3, 5))
    impares = 0
    for i in (0, 2, 4, 6):
        d = int(cuerpo7[i]) * 2
        impares += d // 10 + d % 10
    return (10 - (pares + impares) % 10) % 10


def tipo_nif(nif: str) -> str:
    """Devuelve 'DNI', 'NIE', 'CIF' o '' si no es válido."""
    s = normalizar(nif)
    if len(s) != 9:
        return ""
    if re.fullmatch(r"\d{8}[A-Z]", s):
        return "DNI" if letra_dni(int(s[:8])) == s[8] else ""
    if re.fullmatch(r"[XYZ]\d{7}[A-Z]", s):
        num = int("XYZ".index(s[0]).__str__() + s[1:8])
        return "NIE" if letra_dni(num) == s[8] else ""
    if re.fullmatch(r"[A-Z]\d{7}[A-Z0-9]", s) and s[0] in CIF_PRIMERAS:
        c = control_cif(s[1:8])
        ctrl = s[8]
        ok_digito = ctrl == str(c)
        ok_letra = ctrl == LETRAS_CIF_CONTROL[c]
        if s[0] in CIF_SOLO_LETRA:
            ok = ok_letra
        elif s[0] in CIF_SOLO_DIGITO:
            ok = ok_digito
        else:
            ok = ok_digito or ok_letra
        return "CIF" if ok else ""
    return ""


def es_valido(nif: str) -> bool:
    return bool(tipo_nif(nif))


def buscar_nifs(texto: str):
    """Devuelve lista de (nif_normalizado, valido, posicion) en orden de aparición, sin duplicados."""
    vistos, out = set(), []
    for m in _PATRON.finditer(texto or ""):
        s = normalizar(m.group(1))
        if len(s) != 9 or s in vistos:
            continue
        # descartar números puros (teléfonos, importes, IBAN...)
        if s.isdigit():
            continue
        vistos.add(s)
        out.append((s, es_valido(s), m.start()))
    return out


def generar_dni(numero: int) -> str:
    return f"{numero:08d}{letra_dni(numero)}"


def generar_cif(letra: str, cuerpo7: str) -> str:
    c = control_cif(cuerpo7)
    ctrl = LETRAS_CIF_CONTROL[c] if letra in CIF_SOLO_LETRA else str(c)
    return f"{letra}{cuerpo7}{ctrl}"
