"""Utilidades comunes del toolkit de la gestoría (NIF, importes, CSV, exportación Sage)."""
