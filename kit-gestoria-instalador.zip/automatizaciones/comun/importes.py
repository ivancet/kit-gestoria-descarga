"""Parseo y formato de importes en formato español (1.234,56) o anglosajón (1,234.56)."""
import re
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation

PATRON_IMPORTE = re.compile(r"-?\(?\d{1,3}(?:[.\s]\d{3})*(?:,\d{1,2})\)?(?!\d)|-?\d{1,3}(?:,\d{3})*\.\d{2}(?!\d)|-?\d+[.,]\d{2}(?!\d)")
CENT = Decimal("0.01")


def parse_importe(txt) -> Decimal | None:
    if txt is None:
        return None
    if isinstance(txt, (int, float, Decimal)):
        return Decimal(str(txt)).quantize(CENT, ROUND_HALF_UP)
    s = str(txt).strip().replace("€", "").replace("EUR", "").replace("\u00a0", "").strip()
    if not s:
        return None
    neg = s.startswith("-") or (s.startswith("(") and s.endswith(")")) or s.endswith("-")
    s = s.strip("-()+ ").replace(" ", "")
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        partes = s.split(",")
        if len(partes) == 2 and len(partes[1]) in (1, 2):
            s = s.replace(",", ".")
        else:
            s = s.replace(",", "")
    elif s.count(".") > 1:
        s = s.replace(".", "")
    elif "." in s and len(s.split(".")[1]) == 3:
        s = s.replace(".", "")  # 1.234 -> miles
    try:
        v = Decimal(s).quantize(CENT, ROUND_HALF_UP)
    except InvalidOperation:
        return None
    return -v if neg else v


def importes_en(texto: str):
    out = []
    for m in PATRON_IMPORTE.finditer(texto or ""):
        v = parse_importe(m.group(0))
        if v is not None:
            out.append(v)
    return out


def fmt_es(v) -> str:
    """Decimal -> '1234,56' (sin separador de miles, para CSV en Excel español)."""
    if v is None or v == "":
        return ""
    return f"{Decimal(v).quantize(CENT, ROUND_HALF_UP):.2f}".replace(".", ",")


def r2(v) -> Decimal:
    return Decimal(v).quantize(CENT, ROUND_HALF_UP)
