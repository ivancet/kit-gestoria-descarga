"""Extracción heurística de campos de facturas españolas a partir de texto.

Campos: NIF emisor/receptor (con validación de control), nº factura, fecha, bases y cuotas por
tipo de IVA (21/10/5/4/2/0), retención IRPF, total, y comprobación base+IVA-IRPF=total.
Devuelve también una puntuación de confianza (0-100) y una lista de avisos.
"""
import re
import sys
import unicodedata
from datetime import date
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from comun.nif import buscar_nifs  # noqa: E402
from comun.importes import importes_en, parse_importe, r2  # noqa: E402

TIPOS_IVA = [21, 10, 5, 4, 2, 0]
TOL = Decimal("0.02")
MESES = {m: i for i, m in enumerate(["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
                                     "septiembre", "octubre", "noviembre", "diciembre"], 1)}
MESES["setiembre"] = 9
KW_RECEPTOR = ("cliente", "destinatario", "facturar a", "receptor", "comprador", "datos del cliente", "bill to",
               "enviar a", "titular")
KW_EMISOR = ("emisor", "proveedor", "vendedor", "datos fiscales del emisor")


def norm(s):
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s.lower()


def _sin_porcentajes(linea):
    return re.sub(r"\d+(?:[.,]\d+)?\s*%", " ", linea)


# ---------------------------------------------------------------- fechas
_F_NUM = re.compile(r"(?<!\d)(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4}|\d{2})(?!\d)")
_F_TXT = re.compile(r"(?<!\d)(\d{1,2})\s+de\s+([a-z]+)\s+(?:de\s+|del\s+)?(\d{4})")
_F_ISO = re.compile(r"(?<!\d)(20\d{2})-(\d{2})-(\d{2})(?!\d)")


def fechas_en(linea_norm):
    out = []
    for m in _F_NUM.finditer(linea_norm):
        d, mth, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        y = y + 2000 if y < 100 else y
        try:
            out.append((m.start(), date(y, mth, d)))
        except ValueError:
            pass
    for m in _F_TXT.finditer(linea_norm):
        if m.group(2) in MESES:
            try:
                out.append((m.start(), date(int(m.group(3)), MESES[m.group(2)], int(m.group(1)))))
            except ValueError:
                pass
    for m in _F_ISO.finditer(linea_norm):
        try:
            out.append((m.start(), date(int(m.group(1)), int(m.group(2)), int(m.group(3)))))
        except ValueError:
            pass
    return [f for _, f in sorted(out) if 2000 <= f.year <= 2100]


def extraer_fecha(lineas_n):
    for i, l in enumerate(lineas_n):
        if "fecha" in l and not re.search(r"venc|valor|entrega|pedido|alta|nacim|caduc", l):
            fs = fechas_en(l) or (fechas_en(lineas_n[i + 1]) if i + 1 < len(lineas_n) else [])
            if fs:
                return fs[0], 1.0
    for l in lineas_n:
        if re.search(r"venc", l):
            continue
        fs = fechas_en(l)
        if fs:
            return fs[0], 0.6
    return None, 0.0


# ---------------------------------------------------------------- número de factura
_NUM = re.compile(
    r"(?:n\.?[º°o]\.?\s*(?:de\s+)?(?:factura|fra\.?|ticket|documento)|(?:factura|fra\.?|ticket)\s*(?:simplificada\s*)?"
    r"(?:n\.?[º°o]\.?|num\.?|numero|nro\.?|#)|numero\s+(?:de\s+)?(?:factura|ticket)|invoice\s*(?:no\.?|number|#)|"
    r"(?:^|\s)factura\s*:)\s*[:.#]?\s*([a-z0-9][a-z0-9\-/_.]{0,24})", re.I)


def extraer_numero(lineas, lineas_n):
    for l, ln in zip(lineas, lineas_n):
        m = _NUM.search(ln)
        if m:
            ini, fin = m.span(1)
            val = l[ini:fin].strip(" .:")
            if re.search(r"\d", val):
                return val.upper(), 1.0
    return "", 0.0


# ---------------------------------------------------------------- NIF y nombres
def _nombre_cerca(lineas, idx_linea, pos_en_linea):
    l = lineas[idx_linea]
    antes = re.sub(r"(?i)\b(c\.?i\.?f\.?|n\.?i\.?f\.?|dni|nie|vat|n\.?i\.?f\.?/c\.?i\.?f\.?)\s*[:.]?\s*$", "",
                   l[:pos_en_linea]).strip(" :-,|")
    antes = re.sub(r"(?i)^(cliente|destinatario|facturar a|proveedor|emisor|datos del cliente)\s*[:.]?\s*", "", antes)
    if len(antes) >= 3 and not re.fullmatch(r"[\W_]*(?:(?:cif|nif|dni|nie|vat|cliente|proveedor|emisor|n\.?i\.?f|c\.?i\.?f)[\W_]*)+",
                                            norm(antes)):
        return antes[:80]
    for j in range(idx_linea - 1, max(-1, idx_linea - 3), -1):
        c = lineas[j].strip(" :-|")
        cn = norm(c)
        if len(c) >= 3 and not re.search(r"\d{5}", c) and not any(k == cn.strip(" :") for k in KW_RECEPTOR + KW_EMISOR):
            c = re.sub(r"(?i)^(cliente|destinatario|facturar a|proveedor|emisor)\s*[:.]\s*", "", c)
            if len(c) >= 3:
                return c[:80]
    return ""


def extraer_nifs(texto, lineas, nifs_clientes=()):
    """Devuelve dict con nif_emisor, nombre_emisor, nif_receptor, nombre_receptor y avisos."""
    res = dict(nif_emisor="", nombre_emisor="", nif_receptor="", nombre_receptor="", nifs_invalidos=[])
    offsets, acc = [], 0
    for l in lineas:
        offsets.append(acc)
        acc += len(l) + 1
    encontrados = []
    for nif, valido, pos in buscar_nifs(texto):
        if not valido:
            res["nifs_invalidos"].append(nif)
            continue
        il = max(i for i, o in enumerate(offsets) if o <= pos)
        contexto = norm(" ".join(lineas[max(0, il - 2): il + 1]))
        rol = ""
        if any(k in contexto for k in KW_RECEPTOR):
            rol = "receptor"
        elif any(k in contexto for k in KW_EMISOR):
            rol = "emisor"
        encontrados.append(dict(nif=nif, rol=rol, linea=il, pos=pos - offsets[il]))
    if not encontrados:
        return res
    emisor = next((e for e in encontrados if e["rol"] == "emisor"), None)
    receptor = next((e for e in encontrados if e["rol"] == "receptor"), None)
    resto = [e for e in encontrados if e is not emisor and e is not receptor]
    if emisor is None and resto:
        emisor = resto.pop(0)
    if receptor is None and resto:
        receptor = resto.pop(0)
    for rol, e in (("emisor", emisor), ("receptor", receptor)):
        if e:
            res[f"nif_{rol}"] = e["nif"]
            res[f"nombre_{rol}"] = _nombre_cerca(lineas, e["linea"], e["pos"])
    if not res["nombre_emisor"] and emisor:
        res["nombre_emisor"] = next((l.strip() for l in lineas if len(l.strip()) > 3), "")[:80]
    return res


# ---------------------------------------------------------------- importes
def _ultimo_importe(linea):
    v = importes_en(_sin_porcentajes(linea))
    return v[-1] if v else None


def extraer_total(lineas_n):
    prioridades = [r"total\s+(?:factura|a\s+pagar|documento|eur|€|importe)|importe\s+total|total\s+a\s+abonar",
                   r"(?<!sub)(?<!sub )\btotal\b(?!\s*(?:base|bases|iva|cuota|bruto|neto|imponible|dto|descuento|"
                   r"retenc|irpf|linea|unidades|articulos))"]
    for p in prioridades:
        cands = []
        for i, l in enumerate(lineas_n):
            if re.search(p, l):
                v = _ultimo_importe(l)
                if v is None and i + 1 < len(lineas_n):
                    v = _ultimo_importe(lineas_n[i + 1])
                if v is not None:
                    cands.append(abs(v))
        if cands:
            return max(cands)
    return None


def extraer_irpf(lineas_n, bases_total):
    for l in lineas_n:
        if re.search(r"irpf|retenci", l):
            m = re.search(r"(\d{1,2}(?:[.,]\d+)?)\s*%", l)
            tipo = Decimal(m.group(1).replace(",", ".")) if m else None
            vals = [abs(v) for v in importes_en(_sin_porcentajes(l))]
            if not vals:
                continue
            if tipo is not None and bases_total:
                esperado = r2(bases_total * tipo / 100)
                for v in vals:
                    if abs(v - esperado) <= TOL:
                        return tipo, v
            if tipo is not None and len(vals) >= 2:
                for b in vals:
                    for c in vals:
                        if b != c and abs(r2(b * tipo / 100) - c) <= TOL:
                            return tipo, c
            return tipo, vals[-1]
    return None, Decimal("0")


def extraer_lineas_iva(lineas_n):
    """Busca pares (base, cuota) por tipo de IVA. Devuelve dict tipo -> (base, cuota)."""
    res = {}
    for i, l in enumerate(lineas_n):
        if re.search(r"irpf|retenci|recargo", l):
            continue
        for t in TIPOS_IVA:
            if t == 0:
                continue
            if not re.search(rf"(?<![\d,.]){t}(?:[.,]0+)?\s*%", l):
                continue
            vals = [abs(v) for v in importes_en(_sin_porcentajes(l))]
            par = None
            for b in vals:
                for c in vals:
                    if b > c and abs(r2(b * t / 100) - c) <= TOL:
                        par = (b, c)
                        break
                if par:
                    break
            if par and t not in res:
                res[t] = par
            elif not par and t not in res and vals:
                # Cuota sola en la línea ("IVA 21%: 42,00"): buscar base en líneas de base imponible
                cuota = vals[-1]
                for l2 in lineas_n:
                    if re.search(r"base\s*imponible|subtotal|base\b|neto", l2):
                        for b in importes_en(_sin_porcentajes(l2)):
                            if abs(r2(abs(b) * t / 100) - cuota) <= TOL:
                                res[t] = (abs(b), cuota)
                                break
                    if t in res:
                        break
    if not res:
        # Formato sin % explícito: "Base imponible: X" + "IVA: Y" -> deducir tipo
        base = cuota = None
        for l in lineas_n:
            if base is None and re.search(r"base\s*imponible|subtotal", l):
                base = _ultimo_importe(l)
            if cuota is None and re.search(r"\b(?:iva|cuota)\b", l) and not re.search(r"incl|base|total|sin", l):
                cuota = _ultimo_importe(l)
        if base and cuota is not None:
            for t in TIPOS_IVA[:-1]:
                if abs(r2(abs(base) * t / 100) - abs(cuota)) <= TOL:
                    res[t] = (abs(base), abs(cuota))
                    break
    return res


def extraer_exento(lineas_n, faltante):
    if faltante <= TOL:
        return None
    for l in lineas_n:
        if re.search(r"exent|no sujet|suplido|0\s*%|tasas", l):
            for v in importes_en(_sin_porcentajes(l)):
                if abs(abs(v) - faltante) <= TOL:
                    return abs(v)
    return None


# ---------------------------------------------------------------- principal
def extraer_campos(texto, nifs_clientes=(), es_ocr=False):
    lineas = [l.rstrip() for l in (texto or "").splitlines()]
    lineas = [l for l in lineas if l.strip()]
    lineas_n = [norm(l) for l in lineas]
    avisos = []
    r = {}
    r.update(extraer_nifs(texto, lineas, nifs_clientes))
    r["numero"], conf_num = extraer_numero(lineas, lineas_n)
    fecha, conf_fecha = extraer_fecha(lineas_n)
    r["fecha"] = fecha.isoformat() if fecha else ""
    iva = extraer_lineas_iva(lineas_n)
    total = extraer_total(lineas_n)
    bases = sum((b for b, _ in iva.values()), Decimal("0"))
    tipo_irpf, irpf = extraer_irpf(lineas_n, bases)
    simplificada = bool(re.search(r"simplificada|ticket|iva incluido|i\.v\.a\. incluido", " ".join(lineas_n)))
    if not iva and total is not None and simplificada:
        # ticket con IVA incluido: probar tipos del texto
        for t in TIPOS_IVA[:-1]:
            if re.search(rf"(?<![\d,.]){t}(?:[.,]0+)?\s*%", " ".join(lineas_n)):
                base = r2(total / (1 + Decimal(t) / 100))
                iva[t] = (base, r2(total - base))
                avisos.append(f"BASE_DERIVADA: base calculada desde total con IVA {t}% incluido")
                break
    cuotas = sum((c for _, c in iva.values()), Decimal("0"))
    bases = sum((b for b, _ in iva.values()), Decimal("0"))
    if total is not None:
        exento = extraer_exento(lineas_n, total - (bases + cuotas - irpf))
        if exento:
            iva[0] = (exento, Decimal("0.00"))
            bases += exento
    r["lineas_iva"] = [dict(tipo=t, base=b, cuota=c) for t, (b, c) in sorted(iva.items(), reverse=True)]
    r["tipo_irpf"] = tipo_irpf if irpf else ""
    r["irpf"] = r2(irpf)
    r["total"] = total if total is not None else ""
    r["simplificada"] = simplificada
    diferencia = None
    if total is not None and iva:
        diferencia = r2(bases + cuotas - irpf - total)
    r["diferencia"] = diferencia if diferencia is not None else ""

    conf = 100
    if not r["nif_emisor"]:
        conf -= 30
        avisos.append("SIN_NIF_EMISOR")
    if r["nifs_invalidos"]:
        conf -= 20
        avisos.append("NIF_INVALIDO: " + ",".join(r["nifs_invalidos"]))
    if not r["nif_receptor"] and not simplificada:
        conf -= 10
        avisos.append("SIN_NIF_RECEPTOR")
    if not fecha:
        conf -= 25
        avisos.append("SIN_FECHA")
    elif conf_fecha < 1:
        conf -= 5
    if not r["numero"]:
        conf -= 15
        avisos.append("SIN_NUMERO")
    if total is None:
        conf -= 40
        avisos.append("SIN_TOTAL")
    if not iva:
        conf -= 30
        avisos.append("SIN_DESGLOSE_IVA")
    if diferencia is not None and abs(diferencia) > TOL:
        conf -= 40
        avisos.append(f"DESCUADRE: base+IVA-IRPF-total = {diferencia}")
    if es_ocr:
        conf -= 10
        avisos.append("OCR")
    if any(a.startswith("BASE_DERIVADA") for a in avisos):
        conf -= 10
    r["confianza"] = max(0, conf)
    r["avisos"] = avisos
    return r


def asignar_tipo(r, nifs_clientes, pista_ruta=""):
    """recibida/emitida según NIFs de clientes del despacho o el nombre de la carpeta."""
    pista = norm(pista_ruta)
    nifs = {n.upper() for n in nifs_clientes if n}
    if r.get("nif_receptor") in nifs and r.get("nif_emisor") not in nifs:
        return "recibida", r["nif_receptor"]
    if r.get("nif_emisor") in nifs and r.get("nif_receptor") not in nifs:
        return "emitida", r["nif_emisor"]
    if "emitid" in pista:
        return "emitida", r.get("nif_emisor", "")
    if "recibid" in pista or "gasto" in pista or "ticket" in pista:
        return "recibida", r.get("nif_receptor", "")
    if r.get("simplificada") and not r.get("nif_receptor") and r.get("nif_emisor") not in nifs:
        return "recibida", ""  # ticket de gasto: el cliente se deduce de la carpeta o se revisa
    return "", ""
