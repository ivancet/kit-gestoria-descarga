#!/usr/bin/env python3
"""Hoja de revisión validada -> ficheros de importación para Sage Despachos Connected.

Por defecto genera el Excel de asientos (perfil 'vf_importacion_asientos', columnas SUPUESTAS hasta
tener la plantilla real) y los libros de facturas recibidas/emitidas en CSV genérico.
Solo exporta filas con validado = SI (o con estado OK si se usa --incluir-ok).

  python exportar_sage.py [--revision revision.xlsx] [--salida carpeta] [--perfil vf_importacion_asientos]
                          [--cliente NIF] [--incluir-ok] [--primer-asiento 1]
"""
import argparse
import sys
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))
sys.path.insert(0, str(AQUI))

from comun.asientos import PlanCuentas, asiento_factura, cuadra  # noqa: E402
from comun.config import cargar_toml, rutas  # noqa: E402
from comun.sage_export import exportar  # noqa: E402
import revision as rev  # noqa: E402


def filas_libro(fac, plan):
    """Una fila por tipo de IVA (formato libro registro)."""
    out = []
    lineas = fac["lineas_iva"] or [dict(tipo="", base=0, cuota=0)]
    for i, l in enumerate(lineas):
        out.append(dict(fecha=fac["fecha"], numero=fac["numero"], nif_emisor=fac["nif_emisor"],
                        nombre_emisor=fac["nombre_emisor"], nif_receptor=fac["nif_receptor"],
                        nombre_receptor=fac["nombre_receptor"],
                        cuenta_tercero=plan.tercero(fac["nif_emisor"] if fac["tipo"] == "recibida"
                                                    else fac["nif_receptor"],
                                                    "proveedores" if fac["tipo"] == "recibida" else "clientes"),
                        cuenta_gasto_ingreso=plan.sub(fac["cuenta_gasto_ingreso"] or plan.c[
                            "gasto_por_defecto" if fac["tipo"] == "recibida" else "ingreso_por_defecto"]),
                        base=l["base"], tipo_iva=l["tipo"], cuota=l["cuota"],
                        tipo_irpf=fac["tipo_irpf"] if i == 0 else "", irpf=fac["irpf"] if i == 0 else "",
                        total=fac["total"] if i == 0 else "", archivo=fac["archivo"]))
    return out


def ejecutar(revision_xlsx, salida, perfil_asientos=None, cliente=None, incluir_ok=False, primer_asiento=1,
             reexportar=False):
    """Exporta las filas validadas que aún no se hayan exportado (columna 'exportado_el')."""
    mapping = cargar_toml("sage_mapping.toml")
    perfil_asientos = perfil_asientos or mapping.get("perfil_por_defecto_asientos", "vf_importacion_asientos")
    plan = PlanCuentas()
    filas = rev.leer_revision(revision_xlsx)
    sel = [f for f in filas if str(f.get("validado", "")).strip().upper() in ("SI", "SÍ", "S", "X")
           or (incluir_ok and f.get("estado") == "OK")]
    if not reexportar:
        sel = [f for f in sel if not str(f.get("exportado_el", "")).strip()]
    if cliente:
        sel = [f for f in sel if str(f.get("cliente_nif", "")).upper() == cliente.upper()]
    apuntes, recibidas, emitidas, descartadas = [], [], [], []
    n = primer_asiento
    for f in sel:
        fac = rev.fila_a_factura(f)
        if fac["tipo"] not in ("recibida", "emitida") or not fac["fecha"] or not fac["total"]:
            descartadas.append((f.get("archivo"), "falta tipo, fecha o total"))
            continue
        a = asiento_factura(n, fac, plan)
        if not cuadra(a):
            descartadas.append((f.get("archivo"), "el asiento no cuadra (revisar bases/IVA/IRPF/total)"))
            continue
        apuntes += a
        f["exportado_el"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        (recibidas if fac["tipo"] == "recibida" else emitidas).extend(filas_libro(fac, plan))
        n += 1
    salida = Path(salida)
    sello = datetime.now().strftime("%Y%m%d_%H%M%S")
    res = {"facturas": n - primer_asiento, "descartadas": descartadas}
    if apuntes:
        rev.guardar_revision(revision_xlsx, filas)  # marca 'exportado_el' para no duplicar
        res["asientos"] = exportar(apuntes, perfil_asientos, salida / f"asientos_facturas_{sello}")
    if recibidas:
        res["recibidas"] = exportar(recibidas, mapping["perfil_por_defecto_facturas_recibidas"],
                                    salida / f"facturas_recibidas_{sello}")
    if emitidas:
        res["emitidas"] = exportar(emitidas, mapping["perfil_por_defecto_facturas_emitidas"],
                                   salida / f"facturas_emitidas_{sello}")
    return res


def main(argv=None):
    R = rutas()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--revision", default=R["facturas_revision"] / "revision.xlsx")
    ap.add_argument("--salida", default=R["salida_sage"])
    ap.add_argument("--perfil", default=None, help="perfil de config/sage_mapping.toml para los asientos")
    ap.add_argument("--cliente", default=None, help="exportar solo un cliente (NIF)")
    ap.add_argument("--incluir-ok", action="store_true", help="exporta también las filas OK no validadas")
    ap.add_argument("--primer-asiento", type=int, default=1)
    ap.add_argument("--reexportar", action="store_true", help="incluye filas ya exportadas")
    a = ap.parse_args(argv)
    r = ejecutar(a.revision, a.salida, a.perfil, a.cliente, a.incluir_ok, a.primer_asiento, a.reexportar)
    print(f"{r['facturas']} facturas exportadas.")
    for k in ("asientos", "recibidas", "emitidas"):
        if k in r:
            print(f"  {k}: {r[k]}")
    for arch, motivo in r["descartadas"]:
        print(f"  DESCARTADA {arch}: {motivo}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
