"""Gancho opcional de extracción con LLM. Desactivado por defecto (config/extractor.toml [llm]).

No hace ninguna llamada de red por sí mismo: ejecuta el comando local configurado, le pasa el texto
por stdin y espera JSON por stdout. El resultado solo rellena campos vacíos y se marca con aviso 'LLM'.
"""
import json
import os
import shlex
import subprocess
from decimal import Decimal


def aplicar_llm(texto, campos, cfg_llm):
    if not cfg_llm or not cfg_llm.get("habilitado") or not cfg_llm.get("comando"):
        return campos
    if campos.get("confianza", 0) >= cfg_llm.get("usar_si_confianza_menor", 80):
        return campos
    try:
        r = subprocess.run([a.strip('"') for a in shlex.split(cfg_llm["comando"], posix=(os.name != "nt"))], input=texto.encode("utf-8"),
                           capture_output=True, timeout=cfg_llm.get("timeout_segundos", 120))
        datos = json.loads(r.stdout.decode("utf-8"))
    except Exception as e:  # el LLM nunca debe romper el flujo
        campos["avisos"].append(f"LLM_ERROR: {e}")
        return campos
    cambiado = []
    for k in ("nif_emisor", "nif_receptor", "numero", "fecha", "nombre_emisor", "nombre_receptor"):
        if not campos.get(k) and datos.get(k):
            campos[k] = str(datos[k])
            cambiado.append(k)
    for k in ("total", "irpf"):
        if (campos.get(k) in ("", None) or (k == "total" and campos.get(k) == "")) and datos.get(k) is not None:
            campos[k] = Decimal(str(datos[k]))
            cambiado.append(k)
    if not campos.get("lineas_iva") and datos.get("lineas_iva"):
        campos["lineas_iva"] = [dict(tipo=int(l["tipo"]), base=Decimal(str(l["base"])), cuota=Decimal(str(l["cuota"])))
                                for l in datos["lineas_iva"]]
        cambiado.append("lineas_iva")
    if cambiado:
        campos["avisos"].append("LLM: " + ",".join(cambiado) + " (revisar)")
    return campos
