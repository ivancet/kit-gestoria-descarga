#!/usr/bin/env python3
"""Extractor de facturas: carpeta de entrada -> texto/OCR -> campos -> hoja de revisión (XLSX).

Uso:
  python extractor.py                      # una pasada con las rutas de config/rutas.toml
  python extractor.py --vigilar 60         # vigila la carpeta cada 60 s (Ctrl+C para parar)
  python extractor.py --entrada X --revision Y.xlsx --procesados P --error E [--clientes clientes.csv]

Se pueden organizar subcarpetas por cliente: entrada/<NIF del cliente>/recibidas|emitidas/...
"""
import argparse
import hashlib
import logging
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))
sys.path.insert(0, str(AQUI))

from comun.config import cargar_toml, rutas  # noqa: E402
from comun.nif import es_valido, normalizar  # noqa: E402
from comun.reglas import Reglas  # noqa: E402
from comun.tabla import leer_csv, escribir_csv  # noqa: E402
from texto import extraer_texto, EXT_PDF, EXT_IMG, SinOCR  # noqa: E402
from campos import extraer_campos, asignar_tipo  # noqa: E402
from llm_hook import aplicar_llm  # noqa: E402
import revision as rev  # noqa: E402

log = logging.getLogger("extractor")


def sha1(ruta):
    h = hashlib.sha1()
    with open(ruta, "rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


def nifs_de_clientes(ruta):
    if not ruta or not Path(ruta).exists():
        return []
    return [normalizar(f.get("nif", "")) for f in leer_csv(ruta) if es_valido(f.get("nif", ""))]


def nif_en_ruta(ruta, base):
    try:
        partes = Path(ruta).relative_to(base).parts[:-1]
    except ValueError:
        partes = ()
    for p in partes:
        if es_valido(p):
            return normalizar(p)
    return ""


def clave_factura(f):
    """(NIF emisor, nº factura, total) para detectar la misma factura recibida dos veces."""
    num = re.sub(r"[^A-Z0-9]", "", str(f.get("numero") or "").upper())
    if not num or not f.get("nif_emisor"):
        return None
    try:
        total = f"{float(str(f.get('total')).replace(',', '.')):.2f}"
    except ValueError:
        total = ""
    return (str(f["nif_emisor"]).upper(), num, total)


def ficheros_listos(entrada, estabilidad=5):
    ahora = time.time()
    for p in sorted(Path(entrada).rglob("*")):
        if p.is_file() and p.suffix.lower() in EXT_PDF | EXT_IMG and not p.name.startswith(("~", ".")):
            if ahora - p.stat().st_mtime >= estabilidad:
                yield p


def procesar_fichero(p, base_entrada, cfg, nifs_clientes, reglas):
    texto, metodo = extraer_texto(p, cfg)
    c = extraer_campos(texto, nifs_clientes, es_ocr=metodo.startswith("ocr"))
    c = aplicar_llm(texto, c, cfg.get("llm"))
    nif_carpeta = nif_en_ruta(p, base_entrada)
    pista = str(p.relative_to(base_entrada)) if base_entrada in p.parents else p.name
    tipo, cliente = asignar_tipo(c, list(nifs_clientes) + ([nif_carpeta] if nif_carpeta else []), pista)
    c["tipo"] = tipo
    c["cliente_nif"] = cliente or nif_carpeta
    if not tipo:
        c["avisos"].append("TIPO_DESCONOCIDO (recibida/emitida)")
        c["confianza"] = max(0, c["confianza"] - 10)
    if tipo and not c["cliente_nif"]:
        c["avisos"].append("CLIENTE_DESCONOCIDO")
    tercero = c.get("nombre_emisor") if tipo != "emitida" else c.get("nombre_receptor")
    regla = reglas.buscar(f"{tercero} {texto[:300]}", "cargo" if tipo != "emitida" else "abono")
    if regla and tipo == "recibida":
        c["cuenta_gasto_ingreso"] = regla["cuenta"]
        c["regla_cuenta"] = regla.get("descripcion", "")
    c["metodo"] = metodo
    minimo = cfg.get("confianza_minima_ok", 80)
    criticos = ("DESCUADRE", "SIN_TOTAL", "NIF_INVALIDO", "SIN_DESGLOSE", "TIPO_DESCONOCIDO", "SIN_NIF_EMISOR",
                "CLIENTE_DESCONOCIDO")
    c["estado"] = "OK" if c["confianza"] >= minimo and not any(a.startswith(criticos) for a in c["avisos"]) \
        else "REVISAR"
    return c


def ejecutar(entrada, revision_xlsx, procesados, error, clientes_csv=None, cfg=None, mover=True, estabilidad=5):
    """estabilidad: segundos sin cambios antes de procesar un fichero (evita leerlo a medio copiar)."""
    cfg = cfg if cfg is not None else cargar_toml("extractor.toml")
    entrada, procesados, error = Path(entrada), Path(procesados), Path(error)
    for d in (entrada, procesados, error):
        d.mkdir(parents=True, exist_ok=True)
    filas = rev.leer_revision(revision_xlsx)
    hashes = {str(f.get("hash")) for f in filas}
    vistas = {clave_factura(f): f.get("archivo") for f in filas if clave_factura(f)}
    nifs = nifs_de_clientes(clientes_csv)
    reglas = Reglas()
    nuevas = []
    for p in ficheros_listos(entrada, estabilidad=0 if not mover else estabilidad):
        h = sha1(p)
        rel = p.relative_to(entrada)
        if h in hashes:
            log.info("Duplicado (ya procesado): %s", rel)
            if mover:
                destino = procesados / "duplicados" / rel
                destino.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(p), destino)
            continue
        ahora = datetime.now()
        try:
            c = procesar_fichero(p, entrada, cfg, nifs, reglas)
            fila = rev.campos_a_fila(c)
            dest_dir = procesados / ahora.strftime("%Y-%m")
        except (SinOCR, Exception) as e:  # noqa: B014
            log.exception("Error procesando %s", rel)
            fila = {k: "" for k in rev.COLUMNAS}
            fila.update(estado="ERROR", confianza=0, avisos=f"ERROR: {e}")
            dest_dir = error
        fila.update(archivo=str(rel), hash=h, procesado_el=ahora.strftime("%Y-%m-%d %H:%M"))
        k = clave_factura(fila)
        if k and k in vistas:
            # misma factura llegada por otra vía (p. ej. PDF por email y foto por WhatsApp)
            fila["avisos"] = (str(fila.get("avisos") or "") + f"; DUPLICADO_POSIBLE: igual que {vistas[k]}").strip("; ")
            fila["estado"] = "REVISAR"
        elif k:
            vistas[k] = str(rel)
        if mover:
            dest_dir.mkdir(parents=True, exist_ok=True)
            destino = dest_dir / f"{h[:8]}_{re.sub(r'[^\w.\-]+', '_', p.name)}"
            shutil.move(str(p), destino)
            fila["archivo_procesado"] = str(destino)
        filas.append(fila)
        nuevas.append(fila)
        hashes.add(h)
        log.info("%s -> %s (confianza %s) %s", rel, fila.get("estado"), fila.get("confianza"), fila.get("avisos"))
    if nuevas:
        rev.guardar_revision(revision_xlsx, filas)
        lote = Path(revision_xlsx).parent / "lotes" / f"lote_{datetime.now():%Y%m%d_%H%M%S}.csv"
        escribir_csv(lote, nuevas, rev.COLUMNAS)
    return nuevas


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    R = rutas()
    ap.add_argument("--entrada", default=R["facturas_entrada"])
    ap.add_argument("--revision", default=R["facturas_revision"] / "revision.xlsx")
    ap.add_argument("--procesados", default=R["facturas_procesadas"])
    ap.add_argument("--error", default=R["facturas_error"])
    ap.add_argument("--clientes", default=R["clientes"])
    ap.add_argument("--vigilar", type=int, default=0, help="segundos entre pasadas (0 = una sola pasada)")
    ap.add_argument("--no-mover", action="store_true", help="no mover los ficheros (pruebas)")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    while True:
        n = ejecutar(a.entrada, a.revision, a.procesados, a.error, a.clientes, mover=not a.no_mover)
        ok = sum(1 for f in n if f.get("estado") == "OK")
        print(f"{len(n)} documentos nuevos ({ok} OK, {len(n) - ok} a revisar/error). Hoja: {a.revision}")
        if not a.vigilar:
            return 0
        time.sleep(a.vigilar)


if __name__ == "__main__":
    sys.exit(main())
