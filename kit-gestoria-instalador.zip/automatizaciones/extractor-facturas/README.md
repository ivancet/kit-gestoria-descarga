# Extractor de facturas y tickets

El flujo es el siguiente: **carpeta de entrada** (PDF, fotos de WhatsApp o escaneos) → texto (o OCR) → datos de la factura →
**hoja de revisión en Excel** → Antonio valida → **fichero de importación para Sage Despachos Connected**.

Todo se hace en el PC del despacho. **No se envía nada a internet** (el gancho LLM opcional está desactivado).

## Cómo funciona

1. **Entrada**: se deja cada documento en `datos/facturas/entrada/`. Puede ir en subcarpetas por cliente:
   `entrada/<NIF del cliente>/recibidas/...` o `.../emitidas/...`. El NIF de la carpeta indica a qué cliente
   pertenece y la palabra `emitidas` o `recibidas` ayuda a clasificarla. Si no hay subcarpeta, se deduce
   con los NIF de `clientes.csv`.
2. **Texto**: si el PDF trae texto, se lee con `pdfplumber` (o `pdftotext`, si está instalado). Si es un PDF escaneado o una foto
   (JPG, PNG, TIFF o HEIC con `pillow-heif`), se pasa por **OCR con Tesseract en español** (`spa`).
3. **Datos que se extraen** (`campos.py`):
   - NIF/CIF/NIE del emisor y del receptor, **validando la letra o dígito de control**. Si un NIF no es válido, se marca `NIF_INVALIDO`.
   - Número de factura y fecha (`03/11/2026`, `10-11-26`, `7 de noviembre de 2026`...).
   - Base y cuota para cada tipo de IVA (21, 10, 5, 4, 2 y 0/exento). Retención de IRPF. Total.
   - **Cuadre**: base + IVA − IRPF = total (tolerancia de 2 céntimos). Si no cuadra, se marca `DESCUADRE`.
   - Tickets (factura simplificada con IVA incluido): la base se calcula desde el total y se marca `BASE_DERIVADA`.
4. **Confianza** de 0 a 100 y **avisos**. La fila queda en estado `OK` (≥ 80 y sin avisos graves), `REVISAR` o `ERROR`.
5. **Duplicados**: el mismo fichero no se procesa dos veces (control por hash). Si llega la misma factura
   por dos vías (PDF por email y foto por WhatsApp), se marca `DUPLICADO_POSIBLE`.
6. **Cuenta propuesta**: si el nombre del proveedor encaja con una regla de `config/reglas_cuentas.toml`
   (p. ej. ELECTRA o IBERDROLA → 628), se rellena `cuenta_gasto_ingreso`.
7. Los ficheros se mueven a `procesadas/AAAA-MM/` (o a `error/`) con un prefijo del hash.

## Hoja de revisión (`datos/facturas/revision/revision.xlsx`)

Es acumulativa: guarda los cambios de Antonio. Las filas salen en verde (OK), amarillo (revisar) o rojo (error).
Antonio corrige lo que haga falta y escribe **SI** en la columna `validado`. Cada lote también se guarda en
`revision/lotes/lote_*.csv` para que quede trazabilidad.

## Exportación a Sage (`exportar_sage.py`)

Solo exporta las filas con `validado = SI` que no se hayan exportado ya (columna `exportado_el`).

```bat
python exportar_sage.py                       (rutas de config\rutas.toml)
python exportar_sage.py --cliente B12345674   (solo un cliente)
python exportar_sage.py --perfil asientos_csv (otro formato)
```

Genera:
- `asientos_facturas_*.xlsx`: perfil **`vf_importacion_asientos`** (por defecto), un apunte por fila, pensado para
  el *Gestor de Importaciones* de Sage Despachos Connected (guía `VF_Importacion_Asientos`).
  - Recibida: Debe 6xx (base), Debe 472 (cuota de cada tipo), Haber 4751 (IRPF), Haber 400 (total).
  - Emitida: Debe 430 (total), Debe 473 (IRPF), Haber 7xx (base), Haber 477 (cuotas).
  - Comprueba que cada asiento cuadra antes de exportarlo.
- `facturas_recibidas_*.csv` y `facturas_emitidas_*.csv`: libros de facturas genéricos, una fila por tipo de IVA
  (base para el futuro *Plugin de Facturas*).

### SUPUESTOS (hay que confirmarlos con la plantilla real de Antonio)

- **El layout exacto de `VF_Importacion_Asientos` no es público** (ver `docs/opciones-automatizacion.md`).
  Las columnas actuales (`Asiento, Fecha, Cuenta, Concepto, Documento, Debe, Haber, Contrapartida, NIF,
  Base imponible, % IVA, Cuota IVA`) son una suposición razonable.
- Para cambiarlas **no hay que tocar código**: se edita `config/sage_mapping.toml` (nombres, orden,
  valores fijos, formatos de fecha, decimales, longitudes, CSV o XLSX, hoja y fila inicial).
- Para registrar el IVA en los libros de Sage (no solo el asiento), seguramente hará falta el
  *Plugin de Facturas*. Su formato tampoco es público.
- Las cuentas (`config/plan_cuentas.toml`) usan subcuentas de 8 dígitos (`472` → `47200000`). Los proveedores y
  clientes van a la genérica (`40000000` / `43000000`) salvo que se asigne una subcuenta por NIF en `[terceros]`.
- El número de asiento empieza en 1 en cada fichero (`--primer-asiento` para cambiarlo); Sage suele renumerar.

## LLM opcional (desactivado)

Está en `config/extractor.toml`, sección `[llm]`. Si se activa, ejecuta un **comando local** que recibe el texto y
devuelve JSON. Solo se usa cuando la confianza es baja y solo rellena campos vacíos (marcados con `LLM`).
**Atención a la protección de datos**: no hay que activarlo con un servicio externo sin un contrato de encargado del tratamiento.

## Datos de prueba

`python generar_datos_prueba.py carpeta` crea 9 facturas PDF sintéticas (21 %, IRPF, mixta 21+10, emitida al 4 %,
suministro, ticket, NIF inválido, descuadre y exenta+21 %), dos fotos tipo WhatsApp (una torcida), una foto de ticket
y un PDF escaneado. Todas las empresas y los NIF son inventados.

## Tests

`python -m pytest extractor-facturas/tests`. El OCR real se prueba con Tesseract 5.5 + `spa`. Si Tesseract no
está instalado, ese test se salta y se ejecuta una versión simulada.
