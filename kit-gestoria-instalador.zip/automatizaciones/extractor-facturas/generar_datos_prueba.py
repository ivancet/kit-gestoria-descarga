#!/usr/bin/env python3
"""Genera facturas y tickets SINTÉTICOS (datos inventados) para probar el extractor.

Todas las empresas y NIF son ficticios (NIF generados con dígito de control válido).
Salida: PDFs con texto, un PDF escaneado (solo imagen) y fotos PNG tipo WhatsApp.
Además escribe esperado.json con los valores correctos para los tests.
"""
import json
import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from comun.nif import generar_cif, generar_dni  # noqa: E402

# Clientes del despacho (ficticios)
CLIENTE_SL = ("Talleres Ejemplo Ficticio SL", generar_cif("B", "6543210"), "C/ Inventada 1, 08001 Barcelona")
CLIENTE_AUT = ("Marta Prueba Ficticia", generar_dni(12345678), "Av. Imaginaria 22, 46001 Valencia")
# Terceros ficticios
PROV_SUMIN = ("Suministros Ficticios del Mediterraneo SL", generar_cif("B", "1234567"), "Pol. Ind. Falso 3, 03001 Alicante")
PROV_LUZ = ("Electra Ficticia Comercializadora SA", generar_cif("A", "7654321"), "C/ Voltio 5, 28001 Madrid")
PROV_ABOG = ("Jordi Asesor Ficticio", generar_dni(23456789), "C/ Toga 9, 08002 Barcelona")
PROV_BAR = ("Bar Ficticio La Plaza", generar_cif("B", "2345678"), "Pl. Mayor 1, 46002 Valencia")
CLI_FINAL = ("Comercial Destino Ficticia SL", generar_cif("B", "3456789"), "C/ Llegada 7, 41001 Sevilla")
INSTITUCION = ("Asociacion Ficticia Cultural", generar_cif("G", "4567890"), "C/ Cultura 4, 50001 Zaragoza")

NIFS_CLIENTES = [CLIENTE_SL[1], CLIENTE_AUT[1]]


def eur(v):
    s = f"{Decimal(v):,.2f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".") + " €"


def facturas():
    """Lista de especificaciones (id, layout, datos, esperado)."""
    F = []
    F.append(dict(id="F01_recibida_21", layout="clasico", emisor=PROV_SUMIN, receptor=CLIENTE_SL,
                  numero="SF-2026/0457", fecha="03/11/2026",
                  lineas=[("Material de oficina", "1000.00")], iva={21: ("1000.00", "210.00")}, irpf=None,
                  total="1210.00", tipo="recibida"))
    F.append(dict(id="F02_profesional_irpf", layout="clasico", emisor=PROV_ABOG, receptor=CLIENTE_SL,
                  numero="2026-031", fecha="05/11/2026",
                  lineas=[("Honorarios asesoramiento octubre", "500.00")], iva={21: ("500.00", "105.00")},
                  irpf=(15, "75.00"), total="530.00", tipo="recibida"))
    F.append(dict(id="F03_mixta_21_10", layout="tabla", emisor=PROV_SUMIN, receptor=CLIENTE_AUT,
                  numero="SF-2026/0460", fecha="7 de noviembre de 2026",
                  lineas=[("Mantenimiento", "200.00"), ("Comidas evento", "100.00")],
                  iva={21: ("200.00", "42.00"), 10: ("100.00", "10.00")}, irpf=None, total="352.00", tipo="recibida"))
    F.append(dict(id="F04_emitida_4", layout="tabla", emisor=CLIENTE_SL, receptor=CLI_FINAL,
                  numero="A-2026-0102", fecha="10-11-2026",
                  lineas=[("Libros tecnicos", "250.00")], iva={4: ("250.00", "10.00")}, irpf=None,
                  total="260.00", tipo="emitida"))
    F.append(dict(id="F05_luz", layout="clasico", emisor=PROV_LUZ, receptor=CLIENTE_SL,
                  numero="EF26-998877", fecha="02/11/2026",
                  lineas=[("Consumo electricidad octubre", "82.64")], iva={21: ("82.64", "17.36")}, irpf=None,
                  total="100.00", tipo="recibida"))
    F.append(dict(id="F06_ticket", layout="ticket", emisor=PROV_BAR, receptor=None,
                  numero="T-000123", fecha="12/11/26", lineas=[("Menu del dia x1", "12.10")],
                  iva={10: ("11.00", "1.10")}, irpf=None, total="12.10", tipo="recibida"))
    F.append(dict(id="F07_nif_invalido", layout="clasico", emisor=("Proveedor Erroneo Ficticio SL", "B12345670",
                  "C/ Error 0, 28000 Madrid"), receptor=CLIENTE_SL, numero="ERR-1", fecha="04/11/2026",
                  lineas=[("Servicio", "100.00")], iva={21: ("100.00", "21.00")}, irpf=None, total="121.00",
                  tipo="recibida"))
    F.append(dict(id="F08_descuadre", layout="clasico", emisor=PROV_SUMIN, receptor=CLIENTE_SL,
                  numero="SF-2026/0470", fecha="09/11/2026", lineas=[("Material", "300.00")],
                  iva={21: ("300.00", "63.00")}, irpf=None, total="365.00", tipo="recibida"))
    F.append(dict(id="F09_exento_mixto", layout="tabla", emisor=CLIENTE_AUT, receptor=INSTITUCION,
                  numero="MP-26-015", fecha="11/11/2026", lineas=[("Formacion (exenta art. 20)", "400.00"),
                                                                  ("Material", "100.00")],
                  iva={21: ("100.00", "21.00"), 0: ("400.00", "0.00")}, irpf=None, total="521.00", tipo="emitida"))
    return F


def dibujar_pdf(f, ruta):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(ruta), pagesize=A4)
    W, H = A4
    y = H - 50

    def t(x, txt, size=10, bold=False):
        nonlocal y
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(x, y, txt)

    def nl(d=14):
        nonlocal y
        y -= d
    em, re_ = f["emisor"], f["receptor"]
    if f["layout"] == "ticket":
        t(200, em[0], 12, True); nl()
        t(200, f"CIF: {em[1]}"); nl()
        t(200, em[2]); nl(24)
        t(200, "FACTURA SIMPLIFICADA"); nl()
        t(200, f"Ticket n.º {f['numero']}   Fecha: {f['fecha']}"); nl(24)
        for d, imp in f["lineas"]:
            t(200, f"{d}   {eur(imp)}"); nl()
        nl(10)
        t(200, f"TOTAL {eur(f['total'])}", 12, True); nl()
        tipo = list(f["iva"])[0]
        t(200, f"IVA {tipo}% incluido"); nl()
        c.save(); return
    t(50, em[0], 14, True); nl()
    t(50, f"NIF: {em[1]}"); nl()
    t(50, em[2]); nl(30)
    t(50, "FACTURA", 16, True); nl(20)
    if f["layout"] == "clasico":
        t(50, f"Nº Factura: {f['numero']}"); nl()
        t(50, f"Fecha de factura: {f['fecha']}"); nl()
        t(50, "Fecha de vencimiento: 30/12/2026"); nl(24)
        t(50, "Datos del cliente:", bold=True); nl()
        t(50, re_[0]); nl()
        t(50, f"CIF/NIF: {re_[1]}"); nl()
        t(50, re_[2]); nl(30)
    else:
        t(50, f"Factura nº {f['numero']}"); t(300, f"Fecha: {f['fecha']}"); nl(24)
        t(50, f"Facturar a: {re_[0]}"); nl()
        t(50, f"NIF cliente: {re_[1]}"); nl()
        t(50, re_[2]); nl(30)
    t(50, "Concepto", bold=True); t(400, "Importe", bold=True); nl()
    for d, imp in f["lineas"]:
        t(50, d); t(400, eur(imp)); nl()
    nl(20)
    if f["layout"] == "clasico":
        for tipo, (b, q) in f["iva"].items():
            t(300, f"Base imponible: {eur(b)}"); nl()
            t(300, f"IVA {tipo}%: {eur(q)}"); nl()
        if f["irpf"]:
            t(300, f"Retención IRPF {f['irpf'][0]}%: -{eur(f['irpf'][1])}"); nl()
        t(300, f"TOTAL FACTURA: {eur(f['total'])}", 12, True); nl()
    else:
        t(50, "Base imponible", bold=True); t(200, "% IVA", bold=True); t(300, "Cuota", bold=True); nl()
        for tipo, (b, q) in f["iva"].items():
            if tipo == 0:
                t(50, eur(b)); t(200, "Exento"); t(300, eur(q)); nl()
            else:
                t(50, eur(b)); t(200, f"{tipo}%"); t(300, eur(q)); nl()
        nl(10)
        t(300, f"Total a pagar: {eur(f['total'])}", 12, True); nl()
    nl(30)
    t(50, "Forma de pago: transferencia a ES00 0000 0000 0000 0000 0000 (cuenta ficticia)", 8)
    c.save()


def pdf_a_imagen(ruta_pdf, ruta_png, rotar=0):
    import pdfplumber
    with pdfplumber.open(ruta_pdf) as pdf:
        img = pdf.pages[0].to_image(resolution=150).original.convert("RGB")
    if rotar:
        img = img.rotate(rotar, expand=True, fillcolor="white")
    img.save(ruta_png)
    return img


def esperado(f):
    return dict(nif_emisor=f["emisor"][1], nif_receptor=f["receptor"][1] if f["receptor"] else "",
                numero=f["numero"], total=f["total"], tipo=f["tipo"],
                iva={str(k): [v[0], v[1]] for k, v in f["iva"].items()},
                irpf=f["irpf"][1] if f["irpf"] else "0.00")


def generar(destino):
    destino = Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    esp = {}
    for f in facturas():
        p = destino / f"{f['id']}.pdf"
        dibujar_pdf(f, p)
        esp[p.name] = esperado(f)
    # Foto tipo WhatsApp (PNG) y PDF escaneado (solo imagen) -> requieren OCR
    img = pdf_a_imagen(destino / "F01_recibida_21.pdf", destino / "W01_whatsapp_foto.png")
    esp["W01_whatsapp_foto.png"] = esp["F01_recibida_21.pdf"]
    img.save(destino / "S01_escaneado.pdf", "PDF", resolution=150)
    esp["S01_escaneado.pdf"] = esp["F01_recibida_21.pdf"]
    # Foto algo torcida y comprimida (como una foto de móvil reenviada por WhatsApp)
    from PIL import ImageFilter
    torcida = pdf_a_imagen(destino / "F02_profesional_irpf.pdf", destino / "_tmp.png", rotar=1.5)
    torcida.filter(ImageFilter.GaussianBlur(0.6)).save(destino / "W02_foto_torcida.jpg", quality=70)
    (destino / "_tmp.png").unlink()
    esp["W02_foto_torcida.jpg"] = esp["F02_profesional_irpf.pdf"]
    pdf_a_imagen(destino / "F06_ticket.pdf", destino / "W03_ticket.jpg")
    esp["W03_ticket.jpg"] = esp["F06_ticket.pdf"]
    (destino / "esperado.json").write_text(json.dumps(esp, indent=2, ensure_ascii=False), encoding="utf-8")
    (destino / "nifs_clientes.txt").write_text("\n".join(NIFS_CLIENTES) + "\n", encoding="utf-8")
    return esp


if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parent / "datos_prueba")
    print(f"{len(generar(d))} documentos sintéticos en {d}")
