"""Obtención de texto de PDFs e imágenes (texto embebido -> pdftotext -> OCR Tesseract 'spa')."""
import shutil
import subprocess
from pathlib import Path

EXT_PDF = {".pdf"}
EXT_IMG = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp", ".heic"}
MIN_CHARS = 25  # menos texto que esto en un PDF => probablemente escaneado => OCR


class SinOCR(RuntimeError):
    pass


def _config_tesseract(cfg):
    import pytesseract
    cmd = (cfg or {}).get("tesseract_cmd") or ""
    if cmd and Path(cmd).exists():
        pytesseract.pytesseract.tesseract_cmd = cmd
    elif not shutil.which("tesseract") and not (cmd and Path(cmd).exists()):
        for c in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                  str(Path(__file__).resolve().parent.parent / "herramientas" / "Tesseract-OCR" / "tesseract.exe")):
            if Path(c).exists():
                pytesseract.pytesseract.tesseract_cmd = c
                break
        else:
            raise SinOCR("Tesseract no está instalado (ver INSTALAR_WINDOWS.md)")
    return pytesseract


def preparar_imagen(img):
    from PIL import ImageOps
    img = ImageOps.exif_transpose(img)
    img = img.convert("L")
    if img.width < 1500:
        f = 1500 / img.width
        img = img.resize((int(img.width * f), int(img.height * f)))
    return ImageOps.autocontrast(img)


def ocr_imagen(img, cfg=None):
    pt = _config_tesseract(cfg)
    lang = (cfg or {}).get("idioma_ocr", "spa")
    return pt.image_to_string(preparar_imagen(img), lang=lang, config="--psm 6")


def abrir_imagen(ruta):
    from PIL import Image
    if Path(ruta).suffix.lower() == ".heic":
        try:
            import pillow_heif  # opcional
            pillow_heif.register_heif_opener()
        except ImportError as e:
            raise RuntimeError("Fotos HEIC: instalar 'pillow-heif' o pedir al cliente JPG") from e
    return Image.open(ruta)


def texto_pdf(ruta):
    txt = ""
    try:
        import pdfplumber
        with pdfplumber.open(ruta) as pdf:
            txt = "\n".join((p.extract_text(layout=False) or "") for p in pdf.pages)
        if len(txt.strip()) >= MIN_CHARS:
            return txt, "pdf-texto"
    except Exception:
        pass
    if shutil.which("pdftotext"):
        try:
            r = subprocess.run(["pdftotext", "-layout", str(ruta), "-"], capture_output=True, timeout=60)
            t = r.stdout.decode("utf-8", "replace")
            if len(t.strip()) >= MIN_CHARS:
                return t, "pdftotext"
        except Exception:
            pass
    return txt, ""


def extraer_texto(ruta, cfg=None):
    """Devuelve (texto, metodo). metodo: pdf-texto | pdftotext | ocr-pdf | ocr-imagen."""
    ruta = Path(ruta)
    ext = ruta.suffix.lower()
    if ext in EXT_PDF:
        t, metodo = texto_pdf(ruta)
        if metodo:
            return t, metodo
        import pdfplumber
        partes = []
        with pdfplumber.open(ruta) as pdf:
            for p in pdf.pages:
                img = p.to_image(resolution=300).original
                partes.append(ocr_imagen(img, cfg))
        return "\n".join(partes), "ocr-pdf"
    if ext in EXT_IMG:
        return ocr_imagen(abrir_imagen(ruta), cfg), "ocr-imagen"
    raise ValueError(f"Tipo de fichero no soportado: {ext}")
