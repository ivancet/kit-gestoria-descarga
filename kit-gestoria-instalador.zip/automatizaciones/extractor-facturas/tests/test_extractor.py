import json
import shutil
import sys
from decimal import Decimal
from pathlib import Path

import pytest

AQUI = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent))

import generar_datos_prueba as gen  # noqa: E402
import texto  # noqa: E402
import extractor  # noqa: E402
import exportar_sage  # noqa: E402
import revision as rev  # noqa: E402
from campos import extraer_campos  # noqa: E402
from llm_hook import aplicar_llm  # noqa: E402


@pytest.fixture(scope="module")
def datos(tmp_path_factory):
    d = tmp_path_factory.mktemp("facturas")
    esp = gen.generar(d)
    return d, esp


def _clientes(tmp):
    p = tmp / "clientes.csv"
    p.write_text("cliente;nif;tipo;modelos;periodicidad;email;telefono\n"
                 + "\n".join(f"C{i};{n};sociedad;303;trimestral;;" for i, n in enumerate(gen.NIFS_CLIENTES)),
                 encoding="utf-8")
    return p


def _por_archivo(filas):
    return {Path(str(f["archivo"])).name: f for f in filas}


def test_pipeline_pdfs(datos, tmp_path):
    d, esp = datos
    entrada = tmp_path / "entrada"
    entrada.mkdir()
    for n in esp:
        if n.startswith("F"):
            shutil.copy(d / n, entrada / n)
    nuevas = extractor.ejecutar(entrada, tmp_path / "rev" / "revision.xlsx", tmp_path / "proc", tmp_path / "err",
                                _clientes(tmp_path), mover=False)
    f = _por_archivo(nuevas)
    assert len(f) == 9
    for n, e in esp.items():
        if not n.startswith("F"):
            continue
        r = f[n]
        assert str(r["total"]) == e["total"], n
        assert r["numero"] == e["numero"], n
        assert r["tipo"] == e["tipo"], n
        for t, (b, q) in e["iva"].items():
            assert Decimal(str(r[f"base_{t}"])) == Decimal(b), (n, t)
        if n != "F07_nif_invalido.pdf":
            assert r["nif_emisor"] == e["nif_emisor"], n
    assert f["F02_profesional_irpf.pdf"]["irpf"] == Decimal("75.00")
    assert f["F05_luz.pdf"]["cuenta_gasto_ingreso"] == "628"
    assert f["F01_recibida_21.pdf"]["estado"] == "OK"
    assert f["F07_nif_invalido.pdf"]["estado"] == "REVISAR" and "NIF_INVALIDO" in f["F07_nif_invalido.pdf"]["avisos"]
    assert f["F08_descuadre.pdf"]["estado"] == "REVISAR" and "DESCUADRE" in f["F08_descuadre.pdf"]["avisos"]
    assert "BASE_DERIVADA" in f["F06_ticket.pdf"]["avisos"]
    # segunda pasada: no duplica
    assert extractor.ejecutar(entrada, tmp_path / "rev" / "revision.xlsx", tmp_path / "proc", tmp_path / "err",
                              _clientes(tmp_path), mover=False) == []


def test_mover_y_exportar_solo_validadas(datos, tmp_path):
    d, esp = datos
    entrada = tmp_path / "entrada" / gen.CLIENTE_SL[1] / "recibidas"
    entrada.mkdir(parents=True)
    for n in ("F01_recibida_21.pdf", "F02_profesional_irpf.pdf", "F08_descuadre.pdf"):
        shutil.copy(d / n, entrada / n)
    xlsx = tmp_path / "revision.xlsx"
    extractor.ejecutar(tmp_path / "entrada", xlsx, tmp_path / "proc", tmp_path / "err", None, mover=False)
    filas = rev.leer_revision(xlsx)
    assert all(f["cliente_nif"] == gen.CLIENTE_SL[1] for f in filas)  # NIF tomado de la carpeta
    # Antonio valida F01 y F02 (no la descuadrada)
    for f in filas:
        if "descuadre" not in f["archivo"]:
            f["validado"] = "SI"
    rev.guardar_revision(xlsx, filas)
    r = exportar_sage.ejecutar(xlsx, tmp_path / "sage")
    assert r["facturas"] == 2 and r["asientos"].suffix == ".xlsx"
    from openpyxl import load_workbook
    ws = load_workbook(r["asientos"]).active
    filas_x = list(ws.iter_rows(values_only=True))
    assert filas_x[0][:7] == ("Asiento", "Fecha", "Cuenta", "Concepto", "Documento", "Debe", "Haber")
    debe = sum(x[5] or 0 for x in filas_x[1:])
    haber = sum(x[6] or 0 for x in filas_x[1:])
    assert round(debe, 2) == round(haber, 2) == 1210 + 530 + 75  # IRPF 4751 al haber
    assert r["recibidas"].read_text(encoding="utf-8-sig").count("\n") == 3
    # no se vuelve a exportar lo ya exportado
    assert exportar_sage.ejecutar(xlsx, tmp_path / "sage2")["facturas"] == 0
    assert all(f["exportado_el"] for f in rev.leer_revision(xlsx) if f["validado"] == "SI")


def test_detecta_duplicado_por_otra_via(datos, tmp_path, monkeypatch):
    d, _ = datos
    txt, _ = texto.texto_pdf(d / "F01_recibida_21.pdf")
    monkeypatch.setattr(texto, "ocr_imagen", lambda img, cfg=None: txt)
    entrada = tmp_path / "entrada"
    entrada.mkdir()
    shutil.copy(d / "F01_recibida_21.pdf", entrada / "a_email.pdf")
    shutil.copy(d / "W01_whatsapp_foto.png", entrada / "b_whatsapp.png")
    n = _por_archivo(extractor.ejecutar(entrada, tmp_path / "r.xlsx", tmp_path / "p", tmp_path / "e",
                                        _clientes(tmp_path), mover=False))
    assert n["a_email.pdf"]["estado"] == "OK"
    assert n["b_whatsapp.png"]["estado"] == "REVISAR" and "DUPLICADO_POSIBLE" in n["b_whatsapp.png"]["avisos"]


def test_ocr_con_tesseract_simulado(datos, tmp_path, monkeypatch):
    """Sin Tesseract en la máquina de pruebas: se simula el OCR devolviendo el texto de la factura."""
    d, esp = datos
    txt_real, _ = texto.texto_pdf(d / "F01_recibida_21.pdf")
    llamadas = []

    def falso_ocr(img, cfg=None):
        llamadas.append(img.size)
        return txt_real
    monkeypatch.setattr(texto, "ocr_imagen", falso_ocr)
    for n in ("W01_whatsapp_foto.png", "S01_escaneado.pdf"):
        t, metodo = texto.extraer_texto(d / n)
        assert metodo in ("ocr-imagen", "ocr-pdf")
        r = extraer_campos(t, gen.NIFS_CLIENTES, es_ocr=True)
        assert str(r["total"]) == "1210.00" and "OCR" in r["avisos"] and r["confianza"] == 90
    assert len(llamadas) == 2


@pytest.mark.skipif(not shutil.which("tesseract"), reason="Tesseract no instalado en esta máquina")
@pytest.mark.parametrize("nombre", ["W01_whatsapp_foto.png", "S01_escaneado.pdf", "W02_foto_torcida.jpg",
                                    "W03_ticket.jpg"])
def test_ocr_real(datos, nombre):
    d, esp = datos
    e = esp[nombre]
    t, metodo = texto.extraer_texto(d / nombre)
    assert metodo.startswith("ocr")
    r = extraer_campos(t, gen.NIFS_CLIENTES, es_ocr=True)
    assert r["nif_emisor"] == e["nif_emisor"]
    assert str(r["total"]) == e["total"]
    assert {str(l["tipo"]): [str(l["base"]), str(l["cuota"])] for l in r["lineas_iva"]} == e["iva"]


def test_sin_tesseract_va_a_error(datos, tmp_path, monkeypatch):
    d, _ = datos
    entrada = tmp_path / "entrada"
    entrada.mkdir()
    shutil.copy(d / "W01_whatsapp_foto.png", entrada)

    def sin(img, cfg=None):
        raise texto.SinOCR("Tesseract no está instalado")
    monkeypatch.setattr(texto, "ocr_imagen", sin)
    n = extractor.ejecutar(entrada, tmp_path / "r.xlsx", tmp_path / "p", tmp_path / "e", None, mover=True, estabilidad=0)
    assert n[0]["estado"] == "ERROR" and list((tmp_path / "e").iterdir())


def test_llm_desactivado_por_defecto():
    c = dict(confianza=10, avisos=[], total="")
    assert aplicar_llm("x", dict(c), {"habilitado": False, "comando": "no-existe"}) == c


def test_llm_hook_comando_local(tmp_path):
    script = tmp_path / "falso_llm.py"
    script.write_text("import sys,json; sys.stdin.read(); print(json.dumps({'numero':'L-1','total':'12.10',"
                      "'lineas_iva':[{'tipo':10,'base':'11.00','cuota':'1.10'}]}))", encoding="utf-8")
    c = dict(confianza=20, avisos=[], numero="", total="", lineas_iva=[])
    r = aplicar_llm("texto", c, {"habilitado": True, "comando": f'"{sys.executable}" "{script}"',
                                 "usar_si_confianza_menor": 80})
    assert r["numero"] == "L-1" and r["total"] == Decimal("12.10") and any("LLM" in a for a in r["avisos"])
