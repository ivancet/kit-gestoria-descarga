"""Hoja de revisión (XLSX) acumulativa: una fila por factura, editable por Antonio."""
from decimal import Decimal
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

TIPOS_IVA = [21, 10, 5, 4, 2, 0]
COLUMNAS = (["validado", "estado", "confianza", "avisos", "tipo", "cliente_nif", "fecha", "numero",
             "nif_emisor", "nombre_emisor", "nif_receptor", "nombre_receptor"]
            + [x for t in TIPOS_IVA for x in (f"base_{t}", f"cuota_{t}") if not (t == 0 and x == "cuota_0")]
            + ["tipo_irpf", "irpf", "total", "diferencia", "cuenta_gasto_ingreso", "regla_cuenta",
               "archivo", "archivo_procesado", "metodo", "hash", "procesado_el", "exportado_el"])
NUMERICAS = {c for c in COLUMNAS if c.startswith(("base_", "cuota_")) or c in ("irpf", "total", "diferencia")}
AMARILLO = PatternFill("solid", fgColor="FFF2CC")
ROJO = PatternFill("solid", fgColor="F8CBAD")
VERDE = PatternFill("solid", fgColor="E2EFDA")


def campos_a_fila(c):
    f = {k: c.get(k, "") for k in COLUMNAS}
    for l in c.get("lineas_iva", []):
        f[f"base_{l['tipo']}"] = l["base"]
        if l["tipo"] != 0:
            f[f"cuota_{l['tipo']}"] = l["cuota"]
    f["avisos"] = "; ".join(c.get("avisos", []))
    return f


def fila_a_factura(f):
    """Fila de la hoja (posiblemente corregida a mano) -> dict factura para asientos."""
    def dec(v):
        if v in (None, ""):
            return Decimal("0")
        return Decimal(str(v).replace(",", ".")) if not isinstance(v, Decimal) else v
    lineas = []
    for t in TIPOS_IVA:
        b = dec(f.get(f"base_{t}"))
        q = dec(f.get(f"cuota_{t}")) if t else Decimal("0")
        if b or q:
            lineas.append(dict(tipo=t, base=b, cuota=q))
    fecha = f.get("fecha")
    if hasattr(fecha, "isoformat"):
        fecha = fecha.isoformat()[:10]
    return dict(tipo=str(f.get("tipo", "")).strip().lower(), fecha=str(fecha or "")[:10],
                numero=str(f.get("numero") or ""), nif_emisor=str(f.get("nif_emisor") or ""),
                nombre_emisor=str(f.get("nombre_emisor") or ""), nif_receptor=str(f.get("nif_receptor") or ""),
                nombre_receptor=str(f.get("nombre_receptor") or ""), lineas_iva=lineas,
                tipo_irpf=f.get("tipo_irpf") or "", irpf=dec(f.get("irpf")), total=dec(f.get("total")),
                cuenta_gasto_ingreso=str(f.get("cuenta_gasto_ingreso") or ""), archivo=f.get("archivo", ""),
                cliente_nif=str(f.get("cliente_nif") or ""))


def leer_revision(ruta):
    ruta = Path(ruta)
    if not ruta.exists():
        return []
    wb = load_workbook(ruta, data_only=True)
    ws = wb["Revision"] if "Revision" in wb.sheetnames else wb.worksheets[0]
    filas = list(ws.iter_rows(values_only=True))
    if not filas:
        return []
    cab = [str(c or "") for c in filas[0]]
    return [{cab[i]: ("" if v is None else v) for i, v in enumerate(f) if i < len(cab)} for f in filas[1:]
            if any(v not in (None, "") for v in f)]


def guardar_revision(ruta, filas):
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Revision"
    ws.append(COLUMNAS)
    for c in ws[1]:
        c.font = Font(bold=True)
    for f in filas:
        fila = []
        for k in COLUMNAS:
            v = f.get(k, "")
            if k in NUMERICAS and v not in ("", None):
                try:
                    v = float(Decimal(str(v).replace(",", ".")))
                except Exception:
                    pass
            fila.append(v)
        ws.append(fila)
        estado = f.get("estado", "")
        fill = VERDE if estado == "OK" else ROJO if estado == "ERROR" else AMARILLO
        for cell in ws[ws.max_row][:4]:
            cell.fill = fill
    for i, k in enumerate(COLUMNAS, 1):
        if k in NUMERICAS:
            for row in ws.iter_rows(min_row=2, min_col=i, max_col=i):
                row[0].number_format = "#,##0.00"
    dv = DataValidation(type="list", formula1='"SI,NO"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add(f"A2:A{max(2, ws.max_row + 500)}")
    ws.freeze_panes = "E2"
    ws.auto_filter.ref = ws.dimensions
    anchos = {"avisos": 45, "nombre_emisor": 30, "nombre_receptor": 30, "archivo": 35, "archivo_procesado": 35}
    from openpyxl.utils import get_column_letter
    for i, k in enumerate(COLUMNAS, 1):
        ws.column_dimensions[get_column_letter(i)].width = anchos.get(k, 13)
    ayuda = wb.create_sheet("Ayuda")
    for linea in [
        "Hoja de revisión de facturas (generada automáticamente).",
        "1. Revisa las filas amarillas/rojas (avisos). Corrige directamente las celdas si hace falta.",
        "2. Escribe SI en la columna 'validado' de cada factura correcta.",
        "3. Ejecuta exportar_sage.py: solo las filas validadas pasan al fichero de importación de Sage.",
        "4. 'tipo' debe ser 'recibida' o 'emitida'. 'cuenta_gasto_ingreso' es opcional (por defecto 629/705).",
        "No borres la columna 'hash': evita procesar dos veces el mismo documento.",
    ]:
        ayuda.append([linea])
    wb.save(ruta)
    return ruta
