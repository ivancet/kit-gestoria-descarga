"""Fechas 2026 verificadas contra el Calendario del contribuyente 2026 de la AEAT (consultado 2026-11-14)."""
import sys
from datetime import date
from pathlib import Path

AQUI = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent))

import pytest  # noqa: E402
from calendario_fiscal import obligaciones_modelo, calendario, festivos_nacionales, pascua  # noqa: E402
import vencimientos  # noqa: E402


def fin(modelo, periodo, per="trimestral"):
    for o in obligaciones_modelo(modelo, per, (2025, 2026, 2027)):
        if o.periodo == periodo:
            return o.fin
    raise KeyError((modelo, periodo))


OFICIAL_2026 = [
    # (modelo, periodo, periodicidad, fecha AEAT 2026)
    ("111", "4T 2025", "trimestral", date(2026, 1, 20)),
    ("115", "4T 2025", "trimestral", date(2026, 1, 20)),
    ("123", "4T 2025", "trimestral", date(2026, 1, 20)),
    ("111", "2025-12", "mensual", date(2026, 1, 20)),
    ("303", "4T 2025", "trimestral", date(2026, 1, 30)),
    ("130", "4T 2025", "trimestral", date(2026, 1, 30)),
    ("131", "4T 2025", "trimestral", date(2026, 1, 30)),
    ("349", "4T 2025", "trimestral", date(2026, 1, 30)),
    ("349", "2025-12", "mensual", date(2026, 1, 30)),
    ("303", "2025-12", "mensual", date(2026, 1, 30)),
    ("390", "Anual 2025", "trimestral", date(2026, 1, 30)),
    ("180", "Anual 2025", "trimestral", date(2026, 2, 2)),
    ("190", "Anual 2025", "trimestral", date(2026, 2, 2)),
    ("193", "Anual 2025", "trimestral", date(2026, 2, 2)),
    ("347", "Anual 2025", "trimestral", date(2026, 3, 2)),
    ("303", "2026-01", "mensual", date(2026, 3, 2)),
    ("303", "1T 2026", "trimestral", date(2026, 4, 20)),
    ("130", "1T 2026", "trimestral", date(2026, 4, 20)),
    ("111", "1T 2026", "trimestral", date(2026, 4, 20)),
    ("202", "1P 2026", "trimestral", date(2026, 4, 20)),
    ("349", "2026-03", "mensual", date(2026, 4, 20)),
    ("100", "Renta 2025", "trimestral", date(2026, 6, 30)),
    ("303", "2T 2026", "trimestral", date(2026, 7, 20)),
    ("115", "2T 2026", "trimestral", date(2026, 7, 20)),
    ("200", "Ejercicio 2025", "trimestral", date(2026, 7, 27)),
    ("303", "2026-06", "mensual", date(2026, 7, 30)),
    ("111", "2026-07", "mensual", date(2026, 8, 20)),
    ("303", "2026-07", "mensual", date(2026, 8, 31)),
    ("349", "2026-07/08", "mensual", date(2026, 9, 21)),
    ("303", "3T 2026", "trimestral", date(2026, 10, 20)),
    ("202", "2P 2026", "trimestral", date(2026, 10, 20)),
    ("131", "3T 2026", "trimestral", date(2026, 10, 20)),
    ("303", "2026-10", "mensual", date(2026, 11, 30)),
    ("202", "3P 2026", "trimestral", date(2026, 12, 21)),
    ("111", "2026-11", "mensual", date(2026, 12, 21)),
    ("349", "2026-11", "mensual", date(2026, 12, 21)),
    ("303", "2026-11", "mensual", date(2026, 12, 30)),
]


@pytest.mark.parametrize("modelo,periodo,per,esperado", OFICIAL_2026)
def test_fechas_oficiales_2026(modelo, periodo, per, esperado):
    assert fin(modelo, periodo, per) == esperado


def test_renta_inicio_2026():
    o = [x for x in obligaciones_modelo("100", ejercicios=(2025,))][0]
    assert o.inicio == date(2026, 4, 8) and o.oficial


def test_2027_estimadas_y_traslado_fin_de_semana():
    # 30/01/2027 es sábado -> lunes 01/02/2027
    assert fin("303", "4T 2026") == date(2027, 2, 1)
    assert fin("190", "Anual 2026") == date(2027, 2, 1)   # 31/01/2027 domingo
    assert fin("347", "Anual 2026") == date(2027, 3, 1)   # 28/02/2027 domingo
    assert fin("200", "Ejercicio 2026") == date(2027, 7, 26)  # 25/07/2027 domingo
    assert fin("111", "4T 2026") == date(2027, 1, 20)
    o = [x for x in obligaciones_modelo("303", ejercicios=(2026,)) if x.periodo == "4T 2026"][0]
    assert not o.oficial and o.estado_fecha.startswith("estimada")


def test_festivos():
    assert pascua(2026) == date(2026, 4, 5)
    assert pascua(2027) == date(2027, 3, 28)
    assert date(2027, 3, 26) in festivos_nacionales(2027)


def test_calendario_completo_sin_intrastat():
    obs = calendario((2026, 2027))
    assert all(o.fin.year in (2026, 2027) for o in obs)
    assert {o.modelo for o in obs} == {"303", "130", "131", "111", "115", "123", "349", "180", "190", "193",
                                       "347", "390", "200", "202", "100"}


def test_cli_clientes(tmp_path):
    plantilla = AQUI / "clientes_plantilla.csv"
    rc = vencimientos.main(["--clientes", str(plantilla), "--salida", str(tmp_path), "--desde", "2027-01-18",
                            "--dias", "30"])
    assert rc == 0
    csv = (tmp_path / "vencimientos_por_cliente.csv").read_text(encoding="utf-8-sig")
    assert "Ejemplo Sociedad SL" in csv and "4T 2026" in csv
    ics = (tmp_path / "calendario_clientes.ics").read_bytes().decode("utf-8")
    assert ics.startswith("BEGIN:VCALENDAR\r\n") and ics.count("BEGIN:VEVENT") == csv.count("\n") - 1
    assert "DTSTART;VALUE=DATE:20270120" in ics
    assert all(len(l.encode()) <= 75 for l in ics.split("\r\n"))
    resumen = (tmp_path / "que_vence_esta_semana.md").read_text(encoding="utf-8")
    assert "miércoles 20/01/2027" in resumen and "Modelo 111" in resumen
    assert any((tmp_path / "ics_por_cliente").iterdir())


def test_aviso_modelo_incoherente(tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("cliente;tipo;modelos;periodicidad;email;telefono\nX;sociedad;303 130;trimestral;;\n",
                 encoding="utf-8")
    _, avisos = vencimientos.leer_clientes(p)
    assert any("130" in a for a in avisos)
