#!/usr/bin/env python3
"""Vencimientos por cliente: CSV + .ics (Outlook/Google) + resumen semanal "qué vence".

Uso:
  python vencimientos.py --clientes clientes.csv --salida salida/ [--desde 2026-11-16] [--dias 60]
  python vencimientos.py --general --salida salida/       # calendario AEAT 2026-2027 sin clientes
"""
import argparse
import re
import sys
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from comun.tabla import leer_csv, escribir_csv  # noqa: E402
from calendario_fiscal import MODELOS, calendario, obligaciones_modelo, FUENTE_2026  # noqa: E402
from ics import generar_ics  # noqa: E402

DIAS_SEMANA = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
COLS = ["cliente", "nif", "tipo", "modelo", "descripcion", "periodo", "inicio", "fin", "fin_domiciliacion_aprox",
        "dias_restantes", "estado_fecha", "email", "telefono", "aviso"]


def normaliza_tipo(t):
    t = (t or "").strip().lower()
    t = t.replace("ó", "o")
    if t.startswith("auto") or t in ("persona fisica", "pf"):
        return "autonomo"
    if t.startswith("soc") or t in ("sl", "sa", "pj"):
        return "sociedad"
    return t


def leer_clientes(ruta):
    clientes, avisos = [], []
    for f in leer_csv(ruta):
        f = {k.lower().replace("é", "e").replace("ó", "o"): v for k, v in f.items()}
        if not f.get("cliente"):
            continue
        tipo = normaliza_tipo(f.get("tipo"))
        modelos = [m for m in re.split(r"[\s,|/]+", f.get("modelos", "")) if m]
        per = (f.get("periodicidad") or "trimestral").strip().lower()
        validos = []
        for m in modelos:
            if m not in MODELOS:
                avisos.append(f"{f['cliente']}: modelo {m} no soportado (ignorado)")
                continue
            aplica = MODELOS[m][1]
            if aplica != "ambos" and aplica != tipo:
                avisos.append(f"{f['cliente']}: modelo {m} normalmente es para '{aplica}', el cliente es '{tipo}'")
            validos.append(m)
        clientes.append(dict(cliente=f["cliente"], nif=f.get("nif", ""), tipo=tipo, modelos=validos,
                             periodicidad=per if per in ("mensual", "trimestral") else "trimestral",
                             email=f.get("email", ""), telefono=f.get("telefono", ""), contacto=f.get("contacto", "")))
    return clientes, avisos


def vencimientos_clientes(clientes, desde, hasta, extra_festivos=()):
    filas = []
    ejercicios = range(desde.year - 1, hasta.year + 1)
    for c in clientes:
        for m in c["modelos"]:
            for o in obligaciones_modelo(m, c["periodicidad"], ejercicios, extra_festivos):
                if desde <= o.fin <= hasta:
                    filas.append(dict(cliente=c["cliente"], nif=c["nif"], tipo=c["tipo"], modelo=o.modelo,
                                      descripcion=o.descripcion, periodo=o.periodo, inicio=o.inicio, fin=o.fin,
                                      fin_domiciliacion_aprox=o.fin_domiciliacion or "",
                                      dias_restantes=(o.fin - desde).days, estado_fecha=o.estado_fecha,
                                      email=c["email"], telefono=c["telefono"], aviso=o.nota, _ob=o))
    return sorted(filas, key=lambda r: (r["fin"], r["cliente"], r["modelo"]))


def fecha_larga(d):
    return f"{DIAS_SEMANA[d.weekday()]} {d:%d/%m/%Y}"


def resumen_semanal(filas, desde, dias=7):
    fin_sem = desde + timedelta(days=dias - 1)
    lineas = [f"# Qué vence: del {fecha_larga(desde)} al {fecha_larga(fin_sem)}", ""]
    esta = [r for r in filas if desde <= r["fin"] <= fin_sem]
    if not esta:
        lineas.append("Nada vence esta semana.")
    por_dia = defaultdict(list)
    for r in esta:
        por_dia[r["fin"]].append(r)
    for d in sorted(por_dia):
        lineas.append(f"## {fecha_larga(d)}")
        por_modelo = defaultdict(list)
        for r in por_dia[d]:
            por_modelo[(r["modelo"], r["descripcion"], r["periodo"])].append(r["cliente"])
        for (m, desc, per), cls in sorted(por_modelo.items()):
            lineas.append(f"- **Modelo {m}** ({desc}, {per}): {len(cls)} cliente(s): {', '.join(sorted(cls))}")
        lineas.append("")
    dom = [r for r in filas if r["fin_domiciliacion_aprox"] and desde <= r["fin_domiciliacion_aprox"] <= fin_sem]
    if dom:
        lineas += ["## Fin aproximado de domiciliación esta semana (verificar en AEAT)", ""]
        for r in dom:
            lineas.append(f"- {r['fin_domiciliacion_aprox']:%d/%m}: {r['cliente']}, modelo {r['modelo']} {r['periodo']}")
        lineas.append("")
    prox = [r for r in filas if fin_sem < r["fin"] <= fin_sem + timedelta(days=30)]
    lineas.append("## Próximos 30 días después de esta semana")
    if not prox:
        lineas.append("Sin vencimientos.")
    agr = defaultdict(set)
    for r in prox:
        agr[(r["fin"], r["modelo"], r["periodo"])].add(r["cliente"])
    for (d, m, per), cls in sorted(agr.items()):
        lineas.append(f"- {d:%d/%m/%Y}: modelo {m} ({per}), {len(cls)} cliente(s)")
    est = sorted({r["fin"] for r in filas if r["estado_fecha"].startswith("estimada")})
    lineas += ["", "---", f"Fuente: {FUENTE_2026}."]
    if est:
        lineas.append("Las fechas de 2027 son ESTIMADAS por regla hasta que la AEAT publique su calendario 2027.")
    lineas.append("Generado automáticamente. Revisar siempre antes de presentar.")
    return "\n".join(lineas) + "\n"


def eventos_de(filas, agrupar_por_cliente=True):
    ev = []
    if agrupar_por_cliente:
        for r in filas:
            ev.append(dict(fecha=r["fin"], uid_base=f"{r['cliente']}|{r['modelo']}|{r['periodo']}",
                           titulo=f"Modelo {r['modelo']} {r['periodo']} - {r['cliente']}",
                           descripcion=(f"{r['descripcion']}. Plazo: {r['inicio']:%d/%m/%Y} a {r['fin']:%d/%m/%Y}"
                                        f" ({r['estado_fecha']}). Cliente: {r['cliente']} {r['nif']}")))
    return ev


def slug(t):
    t = re.sub(r"[^\w\-]+", "_", t, flags=re.U).strip("_")
    return t[:60] or "cliente"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--clientes", help="CSV de clientes (ver clientes_plantilla.csv)")
    ap.add_argument("--salida", required=True)
    ap.add_argument("--desde", help="AAAA-MM-DD (por defecto hoy)")
    ap.add_argument("--dias", type=int, default=90, help="horizonte de vencimientos (días)")
    ap.add_argument("--festivos", default="", help="festivos extra AAAA-MM-DD separados por coma (locales)")
    ap.add_argument("--general", action="store_true", help="exporta el calendario AEAT 2026-2027 completo")
    a = ap.parse_args(argv)
    salida = Path(a.salida)
    salida.mkdir(parents=True, exist_ok=True)
    extra = [date.fromisoformat(x.strip()) for x in a.festivos.split(",") if x.strip()]
    desde = date.fromisoformat(a.desde) if a.desde else date.today()

    if a.general or not a.clientes:
        obs = []
        for per in ("trimestral", "mensual"):
            mods = ["303", "111", "115", "123", "349"] if per == "mensual" else None
            for o in calendario((2026, 2027), per, mods, extra):
                obs.append(dict(modelo=o.modelo, descripcion=o.descripcion, periodicidad=per if o.modelo in
                                ("303", "111", "115", "123", "349") else "", periodo=o.periodo, inicio=o.inicio,
                                fin=o.fin, fin_domiciliacion_aprox=o.fin_domiciliacion or "",
                                estado_fecha=o.estado_fecha, nota=o.nota))
        obs.sort(key=lambda r: (r["fin"], r["modelo"], r["periodo"]))
        escribir_csv(salida / "calendario_aeat_2026_2027.csv", obs)
        ev = [dict(fecha=r["fin"], uid_base=f"general|{r['modelo']}|{r['periodo']}",
                   titulo=f"AEAT: modelo {r['modelo']} {r['periodo']}",
                   descripcion=f"{r['descripcion']} ({r['estado_fecha']})") for r in obs if r["periodicidad"] != "mensual"]
        (salida / "calendario_aeat_2026_2027.ics").write_text(generar_ics(ev, "Calendario AEAT 2026-2027"),
                                                               encoding="utf-8", newline="")
        print(f"Calendario general: {len(obs)} obligaciones -> {salida}")
        if not a.clientes:
            return 0

    clientes, avisos = leer_clientes(a.clientes)
    hasta = desde + timedelta(days=a.dias)
    filas = vencimientos_clientes(clientes, desde, hasta, extra)
    escribir_csv(salida / "vencimientos_por_cliente.csv", filas, COLS)
    (salida / "calendario_clientes.ics").write_text(generar_ics(eventos_de(filas), "Plazos fiscales clientes"),
                                                    encoding="utf-8", newline="")
    dir_ics = salida / "ics_por_cliente"
    dir_ics.mkdir(exist_ok=True)
    for c in clientes:
        fc = [r for r in filas if r["cliente"] == c["cliente"]]
        if fc:
            (dir_ics / f"{slug(c['cliente'])}.ics").write_text(
                generar_ics(eventos_de(fc), f"Plazos {c['cliente']}"), encoding="utf-8", newline="")
    resumen = resumen_semanal(filas, desde)
    (salida / "que_vence_esta_semana.md").write_text(resumen, encoding="utf-8")
    if avisos:
        (salida / "avisos_clientes.txt").write_text("\n".join(avisos) + "\n", encoding="utf-8")
        for x in avisos:
            print("AVISO:", x)
    print(f"{len(clientes)} clientes, {len(filas)} vencimientos entre {desde} y {hasta} -> {salida}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
