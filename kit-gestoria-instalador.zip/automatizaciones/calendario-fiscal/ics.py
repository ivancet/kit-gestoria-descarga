"""Generador mínimo de ficheros iCalendar (.ics, RFC 5545) importables en Outlook y Google Calendar."""
from datetime import datetime, timedelta, timezone
import hashlib


def _esc(t):
    return str(t).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def _fold(linea):
    b = linea.encode("utf-8")
    if len(b) <= 75:
        return linea
    partes, actual = [], ""
    for ch in linea:
        lim = 75 if not partes else 74
        if len((actual + ch).encode("utf-8")) > lim:
            partes.append(actual)
            actual = ch
        else:
            actual += ch
    partes.append(actual)
    return "\r\n ".join(partes)


def generar_ics(eventos, nombre_calendario="Plazos fiscales", aviso_dias=3):
    """eventos: dicts con fecha (date), titulo, descripcion, uid_base."""
    ahora = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lineas = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Gestoria Antonio//Calendario fiscal//ES",
              "CALSCALE:GREGORIAN", "METHOD:PUBLISH", f"X-WR-CALNAME:{_esc(nombre_calendario)}",
              "X-WR-TIMEZONE:Europe/Madrid"]
    for e in eventos:
        uid = hashlib.sha1(e["uid_base"].encode("utf-8")).hexdigest()[:20] + "@gestoria-antonio"
        d = e["fecha"]
        lineas += ["BEGIN:VEVENT", f"UID:{uid}", f"DTSTAMP:{ahora}",
                   f"DTSTART;VALUE=DATE:{d:%Y%m%d}", f"DTEND;VALUE=DATE:{(d + timedelta(days=1)):%Y%m%d}",
                   f"SUMMARY:{_esc(e['titulo'])}", f"DESCRIPTION:{_esc(e.get('descripcion', ''))}",
                   "TRANSP:TRANSPARENT", "CATEGORIES:Fiscal"]
        if aviso_dias:
            lineas += ["BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{_esc(e['titulo'])}",
                       f"TRIGGER:-P{int(aviso_dias)}D", "END:VALARM"]
        lineas.append("END:VEVENT")
    lineas.append("END:VCALENDAR")
    return "\r\n".join(_fold(l) for l in lineas) + "\r\n"
