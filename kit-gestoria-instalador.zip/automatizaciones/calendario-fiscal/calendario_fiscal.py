"""Calendario fiscal AEAT 2026-2027 (modelos habituales de una gestoría).

Fuente de verificación: Agencia Tributaria, Calendario del contribuyente 2026
https://sede.agenciatributaria.gob.es/Sede/ayuda/calendario-contribuyente/calendario-contribuyente-2026/calendario-anual.html
(consultado 2026-11-14). Las fechas con vencimiento en 2026 coinciden con ese calendario
(ver tests/test_calendario.py). El calendario AEAT 2027 aún no está publicado (14/11/2026):
las fechas de 2027 se calculan con las mismas reglas (día nominal y traslado al siguiente
día hábil si cae en sábado, domingo o festivo nacional, art. 30.5 Ley 39/2015) y se marcan
como "estimada" hasta que la AEAT publique su calendario.
"""
from dataclasses import dataclass, field
from datetime import date, timedelta
import calendar

FUENTE_2026 = ("AEAT, Calendario del contribuyente 2026: https://sede.agenciatributaria.gob.es/Sede/ayuda/"
               "calendario-contribuyente/calendario-contribuyente-2026/calendario-anual.html")

MODELOS = {
    "303": ("IVA. Autoliquidación", "ambos", ("trimestral", "mensual")),
    "130": ("IRPF. Pago fraccionado estimación directa", "autonomo", ("trimestral",)),
    "131": ("IRPF. Pago fraccionado estimación objetiva (módulos)", "autonomo", ("trimestral",)),
    "111": ("Retenciones trabajo y profesionales", "ambos", ("trimestral", "mensual")),
    "115": ("Retenciones alquiler de inmuebles urbanos", "ambos", ("trimestral", "mensual")),
    "123": ("Retenciones capital mobiliario", "ambos", ("trimestral", "mensual")),
    "349": ("Declaración recapitulativa operaciones intracomunitarias", "ambos", ("trimestral", "mensual")),
    "180": ("Resumen anual retenciones alquileres (115)", "ambos", ("anual",)),
    "190": ("Resumen anual retenciones trabajo y profesionales (111)", "ambos", ("anual",)),
    "193": ("Resumen anual retenciones capital mobiliario (123)", "ambos", ("anual",)),
    "347": ("Declaración anual operaciones con terceros", "ambos", ("anual",)),
    "390": ("IVA. Resumen anual", "ambos", ("anual",)),
    "200": ("Impuesto sobre Sociedades. Declaración anual", "sociedad", ("anual",)),
    "202": ("Impuesto sobre Sociedades. Pago fraccionado", "sociedad", ("anual",)),
    "100": ("IRPF. Declaración de la Renta", "autonomo", ("anual",)),
}
# Intrastat: excluido a propósito (lo gestiona el Dpto. de Aduanas; no lo presenta la gestoría).

# Inicio de la campaña de Renta (año de presentación). 2026 oficial; 2027 estimado.
INICIO_RENTA = {2026: (date(2026, 4, 8), True), 2027: (date(2027, 4, 7), False)}

# Modelos con domiciliación posible (fin de domiciliación aproximado: 5 días naturales antes)
DOMICILIABLES = {"303", "130", "131", "111", "115", "123", "200", "202", "100"}

ANIO_VERIFICADO = {2026}


def pascua(y):
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    dia = ((h + l - 7 * m + 114) % 31) + 1
    return date(y, mes, dia)


def festivos_nacionales(y):
    fijos = [(1, 1), (1, 6), (5, 1), (8, 15), (10, 12), (11, 1), (12, 6), (12, 8), (12, 25)]
    s = {date(y, m, d) for m, d in fijos}
    s.add(pascua(y) - timedelta(days=2))  # Viernes Santo
    return s


def habil(d, extra=frozenset()):
    """Traslada al siguiente día hábil (sábados, domingos y festivos nacionales + extra)."""
    fest = festivos_nacionales(d.year) | festivos_nacionales(d.year + 1) | set(extra)
    while d.weekday() >= 5 or d in fest:
        d += timedelta(days=1)
    return d


def ultimo_dia(y, m):
    return calendar.monthrange(y, m)[1]


@dataclass
class Obligacion:
    modelo: str
    descripcion: str
    periodo: str
    ejercicio: int
    inicio: date
    fin: date
    fin_domiciliacion: date | None = None
    oficial: bool = False
    nota: str = ""
    extra: dict = field(default_factory=dict)

    @property
    def estado_fecha(self):
        return "oficial AEAT" if self.oficial else "estimada (regla)"


def _ob(modelo, periodo, ejercicio, inicio, fin_nominal, extra_fest=(), nota=""):
    fin = habil(fin_nominal, extra_fest)
    dom = fin - timedelta(days=5) if modelo in DOMICILIABLES else None
    return Obligacion(modelo, MODELOS[modelo][0], periodo, ejercicio, inicio, fin, dom,
                      fin.year in ANIO_VERIFICADO, nota)


def _trimestrales(modelo, y, extra):
    out = []
    for q in range(1, 5):
        if q < 4:
            mes = 3 * q + 1
            out.append(_ob(modelo, f"{q}T {y}", y, date(y, mes, 1), date(y, mes, 20), extra))
        else:
            dia = 20 if modelo in ("111", "115", "123") else 30
            out.append(_ob(modelo, f"4T {y}", y, date(y + 1, 1, 1), date(y + 1, 1, dia), extra))
    return out


def _mensuales(modelo, y, extra):
    out = []
    for m in range(1, 13):
        ny, nm = (y, m + 1) if m < 12 else (y + 1, 1)
        if modelo == "349" and m == 7:
            continue  # 349 mensual: julio y agosto se declaran juntos (hasta el 20 de septiembre)
        periodo = f"{y}-07/08" if (modelo == "349" and m == 8) else f"{y}-{m:02d}"
        if modelo == "303":
            dia = 30 if m == 12 else min(30, ultimo_dia(ny, nm))
        elif modelo == "349":
            dia = 30 if m == 12 else 20
        else:  # 111, 115, 123 grandes empresas
            dia = 20
        out.append(_ob(modelo, periodo, y, date(ny, nm, 1), date(ny, nm, dia), extra))
    return out


def obligaciones_modelo(modelo, periodicidad="trimestral", ejercicios=(2025, 2026, 2027), extra_festivos=()):
    modelo = str(modelo).strip()
    if modelo not in MODELOS:
        raise ValueError(f"Modelo no soportado: {modelo}")
    extra = frozenset(extra_festivos)
    out = []
    for y in ejercicios:
        if modelo in ("303", "111", "115", "123", "349"):
            out += _mensuales(modelo, y, extra) if periodicidad == "mensual" else _trimestrales(modelo, y, extra)
        elif modelo in ("130", "131"):
            out += _trimestrales(modelo, y, extra)
        elif modelo == "390":
            out.append(_ob(modelo, f"Anual {y}", y, date(y + 1, 1, 1), date(y + 1, 1, 30), extra))
        elif modelo in ("180", "190", "193"):
            out.append(_ob(modelo, f"Anual {y}", y, date(y + 1, 1, 1), date(y + 1, 1, 31), extra))
        elif modelo == "347":
            out.append(_ob(modelo, f"Anual {y}", y, date(y + 1, 2, 1), date(y + 1, 2, ultimo_dia(y + 1, 2)), extra))
        elif modelo == "100":
            ini, ok = INICIO_RENTA.get(y + 1, (date(y + 1, 4, 7), False))
            o = _ob(modelo, f"Renta {y}", y, ini, date(y + 1, 6, 30), extra,
                    nota="" if ok else "Inicio de campaña estimado")
            out.append(o)
        elif modelo == "200":
            out.append(_ob(modelo, f"Ejercicio {y}", y, date(y + 1, 7, 1), date(y + 1, 7, 25), extra,
                           nota="Ejercicio coincidente con año natural"))
        elif modelo == "202":
            for p, mes in ((1, 4), (2, 10), (3, 12)):
                out.append(_ob(modelo, f"{p}P {y}", y, date(y, mes, 1), date(y, mes, 20), extra))
    return out


def calendario(anios_venc=(2026, 2027), periodicidad="trimestral", modelos=None, extra_festivos=()):
    """Todas las obligaciones cuyo fin de plazo cae en `anios_venc`."""
    modelos = modelos or list(MODELOS)
    ejercicios = range(min(anios_venc) - 1, max(anios_venc) + 1)
    out = []
    for m in modelos:
        for o in obligaciones_modelo(m, periodicidad, ejercicios, extra_festivos):
            if o.fin.year in anios_venc:
                out.append(o)
    return sorted(out, key=lambda o: (o.fin, o.modelo, o.periodo))
