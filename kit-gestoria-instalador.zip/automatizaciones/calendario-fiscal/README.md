# Calendario fiscal (AEAT 2026-2027)

Genera los plazos de presentación de los modelos que lleva la gestoría y, a partir de la lista de
clientes, sus vencimientos personales en CSV, en calendario `.ics` (Outlook / Google Calendar) y un
resumen semanal **"qué vence"**.

## Modelos incluidos

303, 130, 131, 111, 115, 123, 180, 190, 193, 347, 349, 390, 200, 202 y 100 (Renta).
Intrastat **no** se incluye (lo gestiona Aduanas, no la gestoría).

| Modelo | Periodo | Fin de plazo (regla) |
|---|---|---|
| 303, 130, 131, 349 trimestral | 1T/2T/3T | día 20 de abril, julio y octubre |
| 303, 130, 131, 349 trimestral | 4T | 30 de enero |
| 111, 115, 123 trimestral | 1T-4T | día 20 de abril, julio, octubre y enero |
| 303 mensual (SII/REDEME/gran empresa) | mes | día 30 del mes siguiente (enero: último día de febrero; diciembre: 30 de enero) |
| 111, 115, 123 mensual (gran empresa) | mes | día 20 del mes siguiente |
| 349 mensual | mes | día 20 del mes siguiente (julio y agosto juntos hasta el 20 de septiembre; diciembre: 30 de enero) |
| 390 | anual | 30 de enero |
| 180, 190, 193 | anual | 31 de enero |
| 347 | anual | último día de febrero |
| 100 Renta | anual | desde principios de abril hasta el 30 de junio |
| 200 Sociedades (año natural) | anual | 25 de julio |
| 202 | 1P/2P/3P | día 20 de abril, octubre y diciembre |

Si el último día cae en sábado, domingo o festivo nacional, pasa al siguiente día hábil
(art. 30.5 de la Ley 39/2015). Los festivos locales o autonómicos se pueden añadir con `--festivos`.

## Fuente y verificación

- **2026: fechas oficiales.** Se han comprobado contra el
  [Calendario del contribuyente 2026 de la AEAT](https://sede.agenciatributaria.gob.es/Sede/ayuda/calendario-contribuyente/calendario-contribuyente-2026/calendario-anual.html)
  (consultado el 14/11/2026). Algunos ejemplos: 190/180/193 el 2 de febrero, 347 el 2 de marzo,
  Renta del 8 de abril al 30 de junio, IS 200 el 27 de julio, 303 de julio el 31 de agosto
  y 202 3P el 21 de diciembre. Los 37 casos están en `tests/test_calendario.py`.
- **2027: fechas estimadas.** A 14/11/2026 la AEAT todavía no ha publicado su calendario 2027.
  Las fechas se calculan con las mismas reglas y salen marcadas como `estimada (regla)`.
  El inicio de la campaña de Renta 2026 (7/4/2027) es una suposición.
  Cuando se publique el calendario, hay que revisarlo y, si hace falta, ajustar `INICIO_RENTA`
  en `calendario_fiscal.py`.
- El **fin de domiciliación** sale como "aprox." (5 días antes del fin de plazo). Hay que verificarlo en la AEAT.

## Uso

```bat
python vencimientos.py --general --salida calendario_generado
python vencimientos.py --clientes ..\datos\clientes\clientes.csv --salida ..\datos\salida\calendario --dias 90
python vencimientos.py --clientes clientes.csv --salida salida --desde 2027-01-18 --festivos 2027-01-22
```

Salidas:
- `vencimientos_por_cliente.csv`: cliente, modelo, periodo, inicio, fin, días restantes y si la fecha es oficial o estimada. Se abre directamente con Excel.
- `calendario_clientes.ics`: todos los vencimientos con un aviso 3 días antes. Para importarlo en Outlook: Archivo > Abrir y exportar > Importar/Exportar > archivo iCalendar. En Google Calendar: Configuración > Importar.
- `ics_por_cliente/*.ics`: un calendario por cliente.
- `que_vence_esta_semana.md`: resumen semanal agrupado por día y modelo, con los próximos 30 días.
- `calendario_generado/`: el calendario general 2026-2027 en CSV e `.ics`, ya generado.

## Lista de clientes (`clientes_plantilla.csv`)

Separador `;` (el de Excel en español), en UTF-8.

| columna | ejemplo | notas |
|---|---|---|
| cliente | Talleres Pérez SL | |
| nif | B12345674 | opcional, pero hace falta para cruzarlo con facturas |
| tipo | autonomo / sociedad | si un modelo no encaja (p. ej. 130 en una sociedad), avisa |
| modelos | `303 130 111 115 390 347 100` | separados por espacios, comas o `|` |
| periodicidad | trimestral / mensual | mensual aplica a 303, 111, 115, 123 y 349 |
| email, telefono, contacto | | se usan en las solicitudes de documentos |

`documentos_recibidos_plantilla.csv` es la plantilla del control de documentos recibidos (la usa `solicitud-documentos`).

## Tests

`python -m pytest calendario-fiscal/tests` (desde la carpeta `automatizaciones`).
