#!/usr/bin/env python3
"""Borradores para pedir documentación a los clientes (email .eml y WhatsApp). NUNCA envía nada.

Cruza el calendario fiscal de cada cliente (calendario-fiscal) con lo ya recibido
(clientes/documentos_recibidos.csv y, opcionalmente, la hoja de revisión del extractor) y genera,
por cliente, un borrador de email (.eml que Outlook abre como borrador) y un texto de WhatsApp
con enlace wa.me (que solo rellena el mensaje: hay que pulsar Enviar a mano).

Uso:
  python solicitar.py --clientes clientes.csv --salida borradores/ [--recibidos documentos_recibidos.csv]
                      [--revision revision.xlsx] [--desde 2026-12-20] [--dias 45]
"""
import argparse
import re
import sys
import urllib.parse
from collections import defaultdict
from datetime import date, datetime, timedelta
from email.message import EmailMessage
from email.policy import SMTP
from pathlib import Path
from string import Template

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "calendario-fiscal"))
sys.path.insert(0, str(RAIZ / "extractor-facturas"))

from comun.config import cargar_toml  # noqa: E402
from comun.tabla import leer_csv, escribir_csv  # noqa: E402
from vencimientos import leer_clientes, vencimientos_clientes, slug  # noqa: E402

PLANTILLAS = AQUI / "plantillas"


def rango_periodo(periodo):
    """'4T 2026' -> (2026-10-01, 2026-12-31); '2026-11' -> mes; 'Anual 2026'/'Renta 2026'/'Ejercicio 2026' -> año."""
    m = re.fullmatch(r"([1-4])T (\d{4})", periodo)
    if m:
        q, y = int(m.group(1)), int(m.group(2))
        ini = date(y, 3 * q - 2, 1)
        fin = date(y + (q == 4), (3 * q) % 12 + 1, 1) - timedelta(days=1)
        return ini, fin
    m = re.fullmatch(r"(\d{4})-(\d{2})(?:/(\d{2}))?", periodo)
    if m:
        y, mi = int(m.group(1)), int(m.group(2))
        mf = int(m.group(3) or mi)
        fin = (date(y + (mf == 12), mf % 12 + 1, 1) - timedelta(days=1))
        return date(y, mi, 1), fin
    m = re.search(r"(\d{4})", periodo)
    y = int(m.group(1))
    return date(y, 1, 1), date(y, 12, 31)


def leer_recibidos(ruta):
    rec = set()
    if ruta and Path(ruta).exists():
        for f in leer_csv(ruta):
            if (f.get("estado") or "recibido").lower() in ("recibido", "no_aplica", "no aplica", "si", "sí", "ok"):
                rec.add((f.get("cliente", "").strip().upper(), f.get("periodo", "").strip().upper(),
                         f.get("documento", "").strip()))
    return rec


def recibidos_de_revision(ruta, clientes, vencs):
    """Si en la hoja de revisión hay facturas del cliente dentro del periodo, cuenta como recibidas."""
    rec, detalle = set(), {}
    if not ruta or not Path(ruta).exists():
        return rec, detalle
    import revision as rev
    filas = [f for f in rev.leer_revision(ruta) if f.get("estado") != "ERROR"]
    nif_a_nombre = {c["nif"].upper(): c["cliente"].upper() for c in clientes if c["nif"]}
    for v in vencs:
        ini, fin = rango_periodo(v["periodo"])
        for f in filas:
            nombre = nif_a_nombre.get(str(f.get("cliente_nif", "")).upper())
            fecha = f.get("fecha")
            fecha = fecha.date() if isinstance(fecha, datetime) else (
                date.fromisoformat(str(fecha)[:10]) if fecha else None)
            if nombre == v["cliente"].upper() and fecha and ini <= fecha <= fin:
                clave = "facturas_emitidas" if f.get("tipo") == "emitida" else "facturas_recibidas"
                k = (nombre, v["periodo"].upper(), clave)
                rec.add(k)
                detalle[k] = detalle.get(k, 0) + 1
    return rec, detalle


def nivel(dias):
    return "urgente" if dias < 7 else "recordatorio" if dias <= 15 else "primer_aviso"


def lista_y(items):
    items = list(items)
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " y " + items[-1]


def generar(clientes_csv, salida, recibidos_csv=None, revision_xlsx=None, desde=None, dias=45):
    cfg = cargar_toml("documentos_requeridos.toml")
    despacho, docs, req = cfg["despacho"], cfg["documentos"], cfg["modelos"]
    desde = desde or date.today()
    clientes, _ = leer_clientes(clientes_csv)
    vencs = vencimientos_clientes(clientes, desde, desde + timedelta(days=dias))
    recibidos = leer_recibidos(recibidos_csv)
    rec_rev, detalle_rev = recibidos_de_revision(revision_xlsx, clientes, vencs)
    recibidos |= rec_rev
    por_cliente = defaultdict(list)
    for v in vencs:
        por_cliente[v["cliente"]].append(v)
    info = {c["cliente"]: c for c in clientes}
    salida = Path(salida) / desde.isoformat()
    salida.mkdir(parents=True, exist_ok=True)
    resumen = []
    for nombre, vs in por_cliente.items():
        c = info[nombre]
        faltan = defaultdict(set)  # documento -> periodos
        modelos, fines = set(), []
        for v in vs:
            for d in req.get(v["modelo"], []):
                claves = {(nombre.upper(), v["periodo"].upper(), d), (c["nif"].upper(), v["periodo"].upper(), d)}
                if not claves & recibidos:
                    faltan[d].add(v["periodo"])
                    modelos.add(v["modelo"])
                    fines.append(v["fin"])
        if not faltan:
            resumen.append(dict(cliente=nombre, estado="completo", documentos_faltantes="", nivel="", email=c["email"],
                                telefono=c["telefono"]))
            continue
        fin_plazo = min(fines)
        dias_rest = (fin_plazo - desde).days
        niv = nivel(dias_rest)
        limite = max(desde + timedelta(days=1), fin_plazo - timedelta(days=int(despacho.get("margen_dias", 7))))
        periodos = sorted({p for ps in faltan.values() for p in ps})
        lineas = [f"- {docs.get(d, d)}" + (f" ({', '.join(sorted(ps))})" if len(periodos) > 1 else "")
                  for d, ps in sorted(faltan.items())]
        vars_ = dict(contacto=c["contacto"] or nombre, cliente=nombre, despacho=despacho["nombre"],
                     firma=despacho["firma"], modelos=("los modelos " if len(modelos) > 1 else "el modelo ")
                     + lista_y(sorted(modelos)), periodos=lista_y(periodos),
                     lista_documentos="\n".join(lineas), lista_documentos_corta="\n".join(lineas),
                     fecha_limite_envio=limite.strftime("%d/%m/%Y"), fecha_fin_plazo=fin_plazo.strftime("%d/%m/%Y"))
        email_txt = Template((PLANTILLAS / f"email_{niv}.txt").read_text(encoding="utf-8")).safe_substitute(vars_)
        asunto, cuerpo = email_txt.split("\n", 1)
        asunto = asunto.replace("Asunto:", "").strip()
        msg = EmailMessage(policy=SMTP)
        msg["To"] = c["email"] or ""
        if despacho.get("email"):
            msg["From"] = despacho["email"]
        msg["Subject"] = asunto
        msg["X-Unsent"] = "1"  # Outlook lo abre como borrador para revisar y enviar a mano
        msg.set_content(cuerpo.strip() + "\n", charset="utf-8", cte="8bit")
        base = slug(nombre)
        (salida / f"{base}_email.eml").write_bytes(bytes(msg))
        wa = Template((PLANTILLAS / f"whatsapp_{niv}.txt").read_text(encoding="utf-8")).safe_substitute(vars_).strip()
        tel = re.sub(r"\D", "", c["telefono"] or "")
        if tel and len(tel) == 9:
            tel = despacho.get("prefijo_telefono", "34") + tel
        enlace = f"https://wa.me/{tel}?text={urllib.parse.quote(wa)}" if tel else ""
        (salida / f"{base}_whatsapp.txt").write_text(
            wa + "\n\n---\nBORRADOR: revisar antes de enviar. Enlace para abrir WhatsApp con el texto ya escrito "
            "(no se envía solo):\n" + (enlace or "(cliente sin teléfono)") + "\n", encoding="utf-8")
        notas = [f"{docs.get(k[2], k[2])} {k[1]}: {n} factura(s) ya en la hoja de revisión"
                 for k, n in detalle_rev.items() if k[0] == nombre.upper()]
        resumen.append(dict(cliente=nombre, estado="faltan documentos", nivel=niv, fin_plazo=fin_plazo,
                            fecha_limite_envio=limite, periodos=", ".join(periodos), modelos=" ".join(sorted(modelos)),
                            documentos_faltantes=" | ".join(docs.get(d, d) for d in sorted(faltan)),
                            email=c["email"], telefono=c["telefono"], borrador_email=f"{base}_email.eml",
                            borrador_whatsapp=f"{base}_whatsapp.txt", notas="; ".join(notas)))
    escribir_csv(salida / "resumen_solicitudes.csv", resumen,
                 ["cliente", "estado", "nivel", "fin_plazo", "fecha_limite_envio", "periodos", "modelos",
                  "documentos_faltantes", "email", "telefono", "borrador_email", "borrador_whatsapp", "notas"])
    return salida, resumen


def main(argv=None):
    from comun.config import rutas
    R = rutas()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--clientes", default=R["clientes"])
    ap.add_argument("--salida", default=R["borradores"])
    ap.add_argument("--recibidos", default=R["documentos_recibidos"])
    ap.add_argument("--revision", default=R["facturas_revision"] / "revision.xlsx")
    ap.add_argument("--desde")
    ap.add_argument("--dias", type=int, default=45)
    a = ap.parse_args(argv)
    d = date.fromisoformat(a.desde) if a.desde else None
    carpeta, res = generar(a.clientes, a.salida, a.recibidos, a.revision, d, a.dias)
    n = sum(1 for r in res if r["estado"] != "completo")
    print(f"{n} borradores de solicitud (email + WhatsApp) en {carpeta}. NO se ha enviado nada.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
