import email
import shutil
import sys
from datetime import date
from email import policy
from pathlib import Path

AQUI = Path(__file__).resolve().parent.parent
RAIZ = AQUI.parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "extractor-facturas"))

import solicitar  # noqa: E402
import generar_datos_prueba as genf  # noqa: E402
import extractor  # noqa: E402

PLANTILLA = RAIZ / "calendario-fiscal" / "clientes_plantilla.csv"
RECIBIDOS = RAIZ / "calendario-fiscal" / "documentos_recibidos_plantilla.csv"


def test_rango_periodo():
    assert solicitar.rango_periodo("4T 2026") == (date(2026, 10, 1), date(2026, 12, 31))
    assert solicitar.rango_periodo("1T 2027") == (date(2027, 1, 1), date(2027, 3, 31))
    assert solicitar.rango_periodo("2026-02") == (date(2026, 2, 1), date(2026, 2, 28))
    assert solicitar.rango_periodo("2026-07/08") == (date(2026, 7, 1), date(2026, 8, 31))
    assert solicitar.rango_periodo("Anual 2026") == (date(2026, 1, 1), date(2026, 12, 31))


def test_niveles():
    assert solicitar.nivel(3) == "urgente" and solicitar.nivel(10) == "recordatorio"
    assert solicitar.nivel(30) == "primer_aviso"


def test_borradores(tmp_path):
    carpeta, res = solicitar.generar(PLANTILLA, tmp_path, RECIBIDOS, None, date(2027, 1, 5), 30)
    soc = next(r for r in res if r["cliente"].startswith("Ejemplo Sociedad"))
    assert soc["nivel"] == "recordatorio" and soc["fin_plazo"] == date(2027, 1, 20)
    assert "Nóminas" not in soc["documentos_faltantes"]          # marcado como recibido
    assert "dividendos" not in soc["documentos_faltantes"]       # marcado como no aplica
    assert "Facturas emitidas" in soc["documentos_faltantes"]
    msg = email.message_from_bytes((carpeta / soc["borrador_email"]).read_bytes(), policy=policy.default)
    assert msg["X-Unsent"] == "1" and msg["To"] == "admin@sociedad-ejemplo.example"
    assert "4T 2026" in msg["Subject"]
    cuerpo = msg.get_content()
    assert "Hola Jordi" in cuerpo and "20/01/2027" in cuerpo and "$" not in cuerpo
    wa = (carpeta / soc["borrador_whatsapp"]).read_text(encoding="utf-8")
    assert "https://wa.me/34600000002?text=" in wa and "BORRADOR" in wa
    assert (carpeta / "resumen_solicitudes.csv").exists()


def test_urgente(tmp_path):
    _, res = solicitar.generar(PLANTILLA, tmp_path, None, None, date(2027, 1, 18), 10)
    assert all(r["nivel"] == "urgente" for r in res if r["estado"] != "completo")


def test_detecta_facturas_ya_recibidas(tmp_path):
    fx = tmp_path / "fx"
    genf.generar(fx)
    entrada = tmp_path / "entrada"
    entrada.mkdir()
    for n in ("F01_recibida_21.pdf", "F04_emitida_4.pdf"):
        shutil.copy(fx / n, entrada / n)
    cl = tmp_path / "clientes.csv"
    cl.write_text("cliente;nif;tipo;modelos;periodicidad;email;telefono;contacto\n"
                  f"Talleres;{genf.CLIENTE_SL[1]};sociedad;303;trimestral;t@example.com;600000009;Ana\n",
                  encoding="utf-8")
    x = tmp_path / "revision.xlsx"
    extractor.ejecutar(entrada, x, tmp_path / "p", tmp_path / "e", cl, mover=False)
    _, res = solicitar.generar(cl, tmp_path / "b", None, x, date(2027, 1, 10), 30)
    [r] = res
    assert "Facturas emitidas" not in r["documentos_faltantes"]
    assert "Facturas recibidas" not in r["documentos_faltantes"]
    assert "Extracto bancario" in r["documentos_faltantes"]


def test_nunca_envia():
    src = (AQUI / "solicitar.py").read_text(encoding="utf-8")
    for prohibido in ("smtplib", "requests", "urlopen", "http.client", "send_message"):
        assert prohibido not in src
