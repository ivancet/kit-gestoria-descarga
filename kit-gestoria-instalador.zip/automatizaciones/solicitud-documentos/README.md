# Solicitud de documentos a clientes

Genera **borradores** para pedir a cada cliente la documentación que falta según sus próximos vencimientos.
**Nunca envía nada**: el código no tiene ninguna función de envío (hay un test que lo comprueba).

## Cómo decide qué pedir

1. Calcula los vencimientos de cada cliente en los próximos N días (45 por defecto) con `calendario-fiscal`.
2. Para cada modelo, mira qué documentos hacen falta según `config/documentos_requeridos.toml`. Por ejemplo,
   303 → facturas emitidas, facturas recibidas y extracto bancario; 111 → nóminas y profesionales; 115 → alquiler.
3. Descuenta lo ya recibido:
   - `datos/clientes/documentos_recibidos.csv` (`cliente;periodo;documento;estado;fecha_recepcion`, con
     estado `recibido` o `no_aplica`). La plantilla está en `calendario-fiscal/documentos_recibidos_plantilla.csv`.
   - La **hoja de revisión del extractor**: si ya hay facturas emitidas o recibidas del cliente en ese periodo,
     se dan por recibidas y se anota cuántas hay.
4. El tono depende de los días que quedan: **primer aviso** (más de 15), **recordatorio** (de 7 a 15) o **urgente** (menos de 7).
   La fecha que se pide para el envío es el fin del plazo menos `margen_dias` (7 por defecto).

## Uso

```bat
python solicitar.py                                    (rutas de config\rutas.toml)
python solicitar.py --clientes clientes.csv --salida borradores --desde 2027-01-05 --dias 30
```

Salidas en `datos/salida/borradores/AAAA-MM-DD/`:
- `<cliente>_email.eml`: con doble clic se abre en **Outlook como borrador** (cabecera `X-Unsent: 1`).
  Se revisa y se envía a mano.
- `<cliente>_whatsapp.txt`: el texto y un enlace `https://wa.me/34…?text=…` que abre WhatsApp con el mensaje ya escrito.
  Aun así, hay que pulsar Enviar.
- `resumen_solicitudes.csv`: quién tiene documentación pendiente, de qué y para cuándo.

## Personalizar

- Textos: `plantillas/email_*.txt` y `plantillas/whatsapp_*.txt` (variables `$contacto`, `$cliente`, `$modelos`,
  `$periodos`, `$lista_documentos`, `$fecha_limite_envio`, `$fecha_fin_plazo`, `$firma`, `$despacho`).
  La primera línea del email es `Asunto: ...`.
- Nombre del despacho, firma, margen de días y documentos por modelo: `config/documentos_requeridos.toml`.

## Tests

`python -m pytest solicitud-documentos/tests`.
