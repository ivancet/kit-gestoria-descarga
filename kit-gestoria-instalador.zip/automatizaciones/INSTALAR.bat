@echo off
REM Instalador del kit de automatizacion de la gestoria (Windows 10/11).
REM Doble clic. Instala Python y Tesseract con winget si faltan, crea el entorno y las carpetas.
setlocal
cd /d "%~dp0"
echo === 1/4 Python ===
where py >nul 2>nul || (
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
)
echo === 2/4 Tesseract OCR ===
if not exist "C:\Program Files\Tesseract-OCR\tesseract.exe" (
  winget install -e --id UB-Mannheim.TesseractOCR --accept-package-agreements --accept-source-agreements
)
echo === 3/4 Entorno Python ===
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
echo === 4/4 Carpetas ===
call run_all.bat --inicializar
echo.
echo Listo. Prueba con datos inventados:  run_all.bat --demo
echo Si Tesseract no tiene espanol, mira INSTALAR_WINDOWS.md paso 2.
pause
