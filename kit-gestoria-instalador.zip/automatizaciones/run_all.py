#!/usr/bin/env python3
"""Ejecuta toda la cadena del toolkit (pensado para el Programador de tareas de Windows).

Pasos (por defecto todos, en este orden):
  calendario   -> vencimientos por cliente (CSV + .ics) y resumen "qué vence esta semana"
  facturas     -> procesa la carpeta de entrada de facturas y actualiza la hoja de revisión
  sage         -> exporta a ficheros de importación de Sage las facturas VALIDADAS (validado = SI)
  banco        -> lee extractos (Norma 43 / Excel) y propone conciliación y asientos
  solicitudes  -> borradores de email/WhatsApp para pedir documentación (NO se envía nada)

Uso:
  python run_all.py                       # todo
  python run_all.py --pasos facturas,sage
  python run_all.py --inicializar         # crea la estructura de carpetas y plantillas
  python run_all.py --demo                # genera datos SINTÉTICOS y ejecuta todo sobre ellos
"""
import argparse
import logging
import shutil
import sys
import traceback
from datetime import date, datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
for sub in ("", "calendario-fiscal", "extractor-facturas", "norma43", "solicitud-documentos"):
    sys.path.insert(0, str(RAIZ / sub))

from comun.config import rutas  # noqa: E402

DEMO = False
PASOS = ["calendario", "facturas", "sage", "banco", "solicitudes"]
log = logging.getLogger("run_all")


def inicializar(R):
    for k, p in R.items():
        if k == "base":
            continue
        (p.parent if p.suffix else p).mkdir(parents=True, exist_ok=True)
    if not R["clientes"].exists():
        shutil.copy(RAIZ / "calendario-fiscal" / "clientes_plantilla.csv", R["clientes"])
    if not R["documentos_recibidos"].exists():
        R["documentos_recibidos"].write_text("cliente;periodo;documento;estado;fecha_recepcion\n", encoding="utf-8-sig")
    log.info("Estructura creada en %s", R["base"])


def paso_calendario(R, hoy):
    import vencimientos
    vencimientos.main(["--clientes", str(R["clientes"]), "--salida", str(R["salida_calendario"]),
                       "--desde", hoy.isoformat(), "--dias", "90"])
    return f"resumen: {R['salida_calendario'] / 'que_vence_esta_semana.md'}"


def paso_facturas(R, hoy):
    import extractor
    n = extractor.ejecutar(R["facturas_entrada"], R["facturas_revision"] / "revision.xlsx",
                           R["facturas_procesadas"], R["facturas_error"], R["clientes"],
                           estabilidad=0 if DEMO else 5)
    ok = sum(1 for f in n if f.get("estado") == "OK")
    return f"{len(n)} documentos nuevos ({ok} OK, {len(n) - ok} a revisar/error)"


def paso_sage(R, hoy):
    import exportar_sage
    # En modo demo se exportan también las filas OK sin validar; en real, solo validado = SI
    r = exportar_sage.ejecutar(R["facturas_revision"] / "revision.xlsx", R["salida_sage"], incluir_ok=DEMO)
    return f"{r['facturas']} facturas validadas exportadas" + (f" -> {r['asientos']}" if "asientos" in r else "")


def paso_banco(R, hoy):
    import conciliar
    ficheros = [p for p in sorted(R["banco_entrada"].glob("*")) if p.is_file() and p.suffix.lower() in
                (".n43", ".txt", ".aeb", ".q43", ".43", ".xlsx", ".csv")]
    if not ficheros:
        return "sin extractos nuevos"
    res = []
    for f in ficheros:
        r = conciliar.ejecutar([f], R["facturas_revision"] / "revision.xlsx", R["salida_banco"] / f.stem)
        dest = R["banco_procesados"] / f"{datetime.now():%Y%m%d_%H%M%S}_{f.name}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(f), dest)
        res.append(f"{f.name}: {r['movimientos']} movimientos")
    return "; ".join(res)


def paso_solicitudes(R, hoy):
    import solicitar
    carpeta, res = solicitar.generar(R["clientes"], R["borradores"], R["documentos_recibidos"],
                                     R["facturas_revision"] / "revision.xlsx", hoy, 45)
    n = sum(1 for r in res if r["estado"] != "completo")
    return f"{n} borradores en {carpeta} (no se envía nada)"


def demo(R):
    """Rellena las carpetas de entrada con datos SINTÉTICOS (nunca datos reales)."""
    import generar_datos_prueba as gf
    import generar_n43_prueba as gb
    tmp = R["base"] / "_demo_tmp"
    gf.generar(tmp)
    destino = R["facturas_entrada"] / gf.CLIENTE_SL[1]
    destino.mkdir(parents=True, exist_ok=True)
    for p in tmp.glob("*.pdf"):
        shutil.copy(p, destino / p.name)
    for p in list(tmp.glob("*.png")) + list(tmp.glob("*.jpg")):
        shutil.copy(p, destino / p.name)
    gb.generar(tmp)
    shutil.copy(tmp / "extracto_ficticio.n43", R["banco_entrada"] / "extracto_ficticio.n43")
    R["clientes"].write_text(
        "cliente;nif;tipo;modelos;periodicidad;email;telefono;contacto\n"
        f"{gf.CLIENTE_SL[0]};{gf.CLIENTE_SL[1]};sociedad;303 111 115 347 390 200 202;trimestral;"
        "talleres@example.com;600000001;Jordi\n"
        f"{gf.CLIENTE_AUT[0]};{gf.CLIENTE_AUT[1]};autonomo;303 130 100;trimestral;marta@example.com;600000002;Marta\n",
        encoding="utf-8-sig")
    shutil.rmtree(tmp)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pasos", default=",".join(PASOS))
    ap.add_argument("--fecha", help="fecha de referencia AAAA-MM-DD (por defecto hoy)")
    ap.add_argument("--inicializar", action="store_true")
    ap.add_argument("--demo", action="store_true", help="usa datos sintéticos de prueba")
    a = ap.parse_args(argv)
    R = rutas()
    R["logs"].mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        handlers=[logging.StreamHandler(),
                                  logging.FileHandler(R["logs"] / f"run_all_{date.today():%Y%m}.log",
                                                      encoding="utf-8")])
    inicializar(R)
    if a.inicializar:
        return 0
    if a.demo:
        global DEMO
        DEMO = True
        demo(R)
    hoy = date.fromisoformat(a.fecha) if a.fecha else date.today()
    fallos = 0
    for paso in [p.strip() for p in a.pasos.split(",") if p.strip()]:
        try:
            log.info("== %s: %s", paso, globals()[f"paso_{paso}"](R, hoy))
        except Exception as e:  # un paso que falla no detiene los demás
            fallos += 1
            log.error("== %s: ERROR %s\n%s", paso, e, traceback.format_exc())
    log.info("Terminado con %d error(es). Log: %s", fallos, R["logs"])
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main())
