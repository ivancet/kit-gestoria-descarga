# Instalación en un PC con Windows 10/11 del despacho

Objetivo: dejar un PC (mejor uno que esté siempre encendido) como **puesto de automatización**. En él estarán la
carpeta de entrada de facturas, los scripts y las tareas programadas. **No hace falta ser administrador** para nada de
lo que sigue, salvo, según el caso, para instalar Tesseract (ver paso 2).

## 1. Python (3.12 o posterior)

**Opción A (recomendada): instalador oficial para el usuario actual.**
1. Descarga el instalador de Windows (64 bits) desde https://www.python.org/downloads/windows/
2. Al ejecutarlo, marca **"Add python.exe to PATH"**, desmarca "Use admin privileges when installing py.exe"
   y elige *Install Now*. Se instala en `%LOCALAPPDATA%\Programs\Python` sin permisos de administrador.
3. Abre una consola (`cmd`) en la carpeta del toolkit y crea su entorno:
   ```bat
   cd C:\Gestoria\automatizaciones
   py -3 -m venv .venv
   .venv\Scripts\python -m pip install -r requirements.txt
   ```

**Opción B: Python portable (zip "embeddable", sin instalar nada).**
1. Descarga `python-3.12.x-embed-amd64.zip` de python.org y descomprímelo en `C:\Gestoria\automatizaciones\python\`.
2. Abre `python\python312._pth` con el Bloc de notas y quita la `#` de la línea `#import site`.
3. Descarga https://bootstrap.pypa.io/get-pip.py en esa carpeta y ejecuta:
   ```bat
   python\python.exe python\get-pip.py
   python\python.exe -m pip install -r requirements.txt
   ```

`run_all.bat` busca primero `.venv\`, después `python\` y por último el `py` del sistema.

## 2. Tesseract OCR (para fotos y PDF escaneados)

1. Instalador de Windows de UB Mannheim: https://github.com/UB-Mannheim/tesseract/wiki (versión 5.x, 64 bits).
   - En *Additional language data* marca **Spanish** (y Catalan, si hace falta).
   - Si no hay permisos de administrador, elige una carpeta del usuario, por ejemplo
     `C:\Gestoria\automatizaciones\herramientas\Tesseract-OCR`. Si el instalador pide administrador igualmente,
     pídeselo una vez a quien lleve la informática.
2. Si el idioma español no quedó instalado, descarga `spa.traineddata` de
   https://github.com/tesseract-ocr/tessdata_fast y cópialo en la carpeta `tessdata` de Tesseract.
3. El toolkit busca Tesseract en el PATH, en `C:\Program Files\Tesseract-OCR\` y en
   `automatizaciones\herramientas\Tesseract-OCR\`. Si está en otro sitio, indícalo en `config\extractor.toml`:
   ```toml
   tesseract_cmd = 'D:\Programas\Tesseract-OCR\tesseract.exe'
   ```
4. Comprobación: `tesseract --list-langs` tiene que mostrar `spa`.

Fotos de iPhone en `.HEIC`: `.venv\Scripts\python -m pip install pillow-heif` (o pide al cliente que mande JPG).

## 3. Carpetas

```
C:\Gestoria\
  automatizaciones\          <- este toolkit (código y config\)
    config\                  <- rutas, mapeo Sage, plan de cuentas, reglas, documentos
    datos\                   <- DATOS DE CLIENTES (se puede mover; ver config\rutas.toml)
      clientes\clientes.csv              lista de clientes y modelos
      clientes\documentos_recibidos.csv  control de documentos recibidos
      facturas\entrada\<NIF cliente>\recibidas|emitidas\   aquí se dejan PDF y fotos
      facturas\procesadas\AAAA-MM\  facturas\error\
      facturas\revision\revision.xlsx    HOJA DE REVISIÓN (Antonio valida aquí)
      banco\entrada\  banco\procesados\  extractos Norma 43 / Excel
      salida\calendario\  salida\sage\  salida\banco\  salida\borradores\
      logs\
```

Para crear la estructura: `run_all.bat --inicializar`. Para probarlo todo con datos inventados:
`run_all.bat --demo` (conviene hacerlo en una copia o con `set GESTORIA_DATOS=C:\Gestoria\prueba`).

Si los datos tienen que estar en el servidor, pon en `config\rutas.toml` la ruta UNC
(`base = '\\SERVIDOR\Gestoria\datos'`) y no una unidad mapeada: las tareas programadas no ven las unidades mapeadas.

**Cómo llegan los documentos a `facturas\entrada`:**
- Email: una regla de Outlook que guarde los adjuntos de un buzón dedicado (p. ej. facturas@...) en esa carpeta
  (con Power Automate Desktop o una macro), o arrastrarlos a mano.
- WhatsApp: desde WhatsApp Web/Desktop, *Descargar* las fotos a la carpeta del cliente.
- Papel: escanear a PDF con el escáner del despacho, o con la app del móvil (Office Lens, Adobe Scan), en esa carpeta.

## 4. Tareas programadas (Programador de tareas)

Con `schtasks` (no necesita administrador para tareas del propio usuario). Cambia la ruta si hace falta:

```bat
REM Facturas cada 15 minutos en horario de oficina
schtasks /Create /TN "Gestoria\Facturas" /SC DAILY /ST 08:00 /RI 15 /DU 12:00 ^
  /TR "\"C:\Gestoria\automatizaciones\run_all.bat\" --pasos facturas"

REM Cadena completa cada día a las 08:00 (calendario, facturas, Sage, banco y borradores)
schtasks /Create /TN "Gestoria\Diario" /SC DAILY /ST 08:00 ^
  /TR "\"C:\Gestoria\automatizaciones\run_all.bat\""

REM Resumen "qué vence" y borradores de solicitud los lunes a las 07:30
schtasks /Create /TN "Gestoria\Lunes" /SC WEEKLY /D MON /ST 07:30 ^
  /TR "\"C:\Gestoria\automatizaciones\run_all.bat\" --pasos calendario,solicitudes"
```

Desde la interfaz: *Programador de tareas* → *Crear tarea básica* → Programa: `run_all.bat`,
*Iniciar en*: `C:\Gestoria\automatizaciones`, argumentos como los de arriba. Marca "Ejecutar tanto si el usuario
inició sesión como si no" solo si el PC tiene que trabajar sin sesión abierta (pedirá la contraseña del usuario).

El registro de cada ejecución queda en `datos\logs\run_all_AAAAMM.log`.

## 5. Flujo diario de Antonio

1. Abrir `datos\salida\calendario\que_vence_esta_semana.md` (o importar `calendario_clientes.ics` en Outlook una vez).
2. Abrir `datos\facturas\revision\revision.xlsx`, revisar las filas amarillas y rojas y escribir **SI** en `validado`.
3. En la siguiente ejecución (o con `run_all.bat --pasos sage`), los ficheros salen en `datos\salida\sage\`.
   Se importan en Sage con *Configuración → Importación/Exportación → Gestor de Importaciones*. Conviene probarlo
   antes en una **empresa de prueba**.
4. Bancos: el `.n43` se importa en Sage como siempre. `datos\salida\banco\...\conciliacion_*.csv` propone qué es cada movimiento.
5. Solicitudes: abrir los `.eml` de `datos\salida\borradores\FECHA\` (se abren como borrador de Outlook), revisarlos y
   enviarlos. En WhatsApp, abrir el enlace del `.txt` y pulsar Enviar.

## 6. Comprobar la instalación

```bat
.venv\Scripts\python -m pytest
```
Tienen que pasar todos los tests. El de OCR real se salta si Tesseract no está instalado.

## 7. Seguridad y protección de datos

- Los datos de clientes quedan **solo en este PC o en el servidor del despacho**. El toolkit no se conecta a internet.
- Disco cifrado (BitLocker) y copias de seguridad de `datos\`. No sincronizar `datos\` con nubes personales.
- El LLM opcional (`config\extractor.toml`) está desactivado. Si se activara con un servicio externo, los datos saldrían del despacho.
- Nunca presentar modelos en la AEAT de forma automática: la presentación la hace siempre una persona, después de revisar.

## 8. Grok Bot en este PC (opcional)

Si se instala la app de Grok Bot en este PC con la cuenta de Ivan y se activa la ejecución local, el asistente puede
lanzar estos scripts y leer los resultados, **pidiendo aprobación** en cada acción. El trabajo del asistente corre en la nube;
los scripts y los datos siguen en este PC.
