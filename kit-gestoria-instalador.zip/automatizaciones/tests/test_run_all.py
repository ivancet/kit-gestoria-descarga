import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))


def test_demo_completa(tmp_path, monkeypatch):
    monkeypatch.setenv("GESTORIA_DATOS", str(tmp_path))
    import run_all
    assert run_all.main(["--demo", "--fecha", "2027-01-05"]) == 0
    salida = tmp_path / "salida"
    assert (salida / "calendario" / "que_vence_esta_semana.md").exists()
    assert list((salida / "sage").glob("asientos_facturas_*.xlsx"))
    assert list((salida / "banco" / "extracto_ficticio").glob("conciliacion_*.csv"))
    assert list((salida / "borradores" / "2027-01-05").glob("*_email.eml"))
    assert (tmp_path / "facturas" / "revision" / "revision.xlsx").exists()
    assert not list((tmp_path / "facturas" / "entrada").rglob("*.pdf"))  # todo procesado
