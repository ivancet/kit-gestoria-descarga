from decimal import Decimal

from comun.nif import es_valido, tipo_nif, buscar_nifs, generar_cif, generar_dni
from comun.importes import parse_importe, importes_en
from comun.asientos import PlanCuentas, asiento_factura, cuadra
from comun.sage_export import exportar, cargar_perfil


def test_nif_dni_nie_cif():
    assert tipo_nif("12345678Z") == "DNI"
    assert tipo_nif("12345678A") == ""
    assert tipo_nif("X1234567L") == "NIE"
    assert tipo_nif("B12345674") == "CIF"
    assert tipo_nif("B12345670") == ""
    assert tipo_nif("ESB12345674") == "CIF"
    assert tipo_nif("Q2826000H") == "CIF"   # organismo público: control letra
    assert es_valido(generar_cif("P", "1234567")) and es_valido(generar_dni(1))


def test_buscar_nifs_no_confunde_lineas():
    t = "NIF: B12345674\nC/ Falsa 1\nCliente NIF 12345678Z\nTel 600123456\nCP 28001"
    assert [n for n, ok, _ in buscar_nifs(t) if ok] == ["B12345674", "12345678Z"]


def test_importes():
    assert parse_importe("1.234,56 €") == Decimal("1234.56")
    assert parse_importe("1,234.56") == Decimal("1234.56")
    assert parse_importe("-75,00") == Decimal("-75.00")
    assert parse_importe("(12,30)") == Decimal("-12.30")
    assert parse_importe("1.000") == Decimal("1000.00")
    assert importes_en("Base 100,00 IVA 21,00 Total 121,00") == [Decimal("100.00"), Decimal("21.00"),
                                                                 Decimal("121.00")]


def _fac(tipo="recibida"):
    return dict(tipo=tipo, fecha="2026-11-03", numero="F1", nif_emisor="B12345674", nombre_emisor="Prov",
                nif_receptor="12345678Z", nombre_receptor="Cli", irpf=Decimal("75"), total=Decimal("530"),
                lineas_iva=[dict(tipo=21, base=Decimal("500"), cuota=Decimal("105"))])


def test_asientos_cuadran():
    plan = PlanCuentas()
    a = asiento_factura(1, _fac(), plan)
    assert cuadra(a) and {x["cuenta"] for x in a} == {"62900000", "47200000", "47510000", "40000000"}
    b = asiento_factura(2, _fac("emitida"), plan)
    assert cuadra(b) and {x["cuenta"] for x in b} == {"43000000", "47300000", "70500000", "47700000"}


def test_exportacion_pluggable(tmp_path):
    plan = PlanCuentas()
    a = asiento_factura(1, _fac(), plan)
    perfil = dict(tipo="asientos", formato="csv", separador="|", separador_decimal=".", formato_fecha="%Y%m%d",
                  cabecera=False, columnas=[dict(columna="F", campo="fecha", tipo="fecha"),
                                            dict(columna="C", campo="cuenta"), dict(columna="D", campo="debe"),
                                            dict(columna="X", valor="FIJO"),
                                            dict(columna="P", plantilla="{documento}-{nif}")])
    p = exportar(a, perfil, tmp_path / "x.csv")
    lineas = p.read_text(encoding="utf-8-sig").splitlines()
    assert lineas[0] == "20261103|62900000|500.00|FIJO|F1-B12345674"
    vf = exportar(a, "vf_importacion_asientos", tmp_path / "vf")
    assert vf.suffix == ".xlsx" and cargar_perfil("vf_importacion_asientos")["formato"] == "xlsx"
