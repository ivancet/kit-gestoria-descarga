@echo off
REM Lanza el toolkit completo. Pensado para el Programador de tareas de Windows.
REM Orden de busqueda de Python: .venv\ (entorno virtual), python\ (portable), lanzador "py", "python".
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
if exist "%~dp0.venv\Scripts\python.exe" (
    set PY="%~dp0.venv\Scripts\python.exe"
) else if exist "%~dp0python\python.exe" (
    set PY="%~dp0python\python.exe"
) else (
    where py >nul 2>nul && (set PY=py -3) || (set PY=python)
)
%PY% run_all.py %*
exit /b %ERRORLEVEL%
